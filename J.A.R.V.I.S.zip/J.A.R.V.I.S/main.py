"""
J.A.R.V.I.S — Advanced Personal AI Assistant for Windows
Main Application Entry Point.
"""

import sys
import os
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

# Suppress DPI awareness warning on restricted Windows accounts
os.environ["QT_AUTO_SCREEN_SCALE_FACTOR"] = "1"

from PySide6.QtWidgets import QApplication
from app.config import Config
from app.utils.logger import get_logger
from app.ui.main_window import JarvisMainWindow

logger = get_logger("Main")


def main():
    """Initializes and runs the JARVIS Desktop Assistant application."""
    logger.info("=" * 60)
    logger.info(f"Initializing {Config.APP_NAME} v{Config.APP_VERSION}...")
    logger.info("=" * 60)

    app = QApplication(sys.argv)
    app.setApplicationName(Config.APP_NAME)
    app.setOrganizationName("JARVIS AI")

    try:
        window = JarvisMainWindow()
        window.show()
        logger.info("JARVIS Main Window successfully rendered.")
        sys.exit(app.exec())
    except Exception as e:
        logger.critical(f"Unhandled fatal exception in JARVIS main loop: {e}", exc_info=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
