"""
AI Brain Subsystem for JARVIS.
Provides provider abstraction (Ollama, OpenAI-compatible, Smart Local Fallback),
multi-turn conversation management, prompt construction with memory injection,
and controlled tool execution cycles.
"""

import json
import re
import requests
from typing import List, Dict, Any, Optional, Generator, Callable, Tuple
from app.config import Config
from app.core.tool_manager import ToolManager
from app.core.memory import MemoryManager
from app.core.conversation import ConversationManager
from app.utils.logger import get_logger
from app.utils.helpers import get_current_timestamp

logger = get_logger("AIEngine")


class AIEngine:
    """Core AI processing coordinator with multi-provider and tool calling support."""

    SYSTEM_PROMPT_TEMPLATE = """You are JARVIS (Just A Rather Very Intelligent System), a sophisticated, ultra-helpful, highly competent personal AI desktop assistant running natively on Windows.

Key Directives:
1. Speak in a polite, confident, slightly sophisticated yet concise tone. Address the user naturally.
2. You have access to native Windows tools and automations. Whenever the user requests an action (e.g., launching an app, checking the weather, calculating, searching files, controlling media/volume, reading clipboard, creating files, searching the web, remembering facts), USE the provided tools.
3. Be direct and helpful. When reporting results from tools, summarize clearly without unnecessary fluff.
4. If a tool is executed, acknowledge its outcome accurately. Never claim you performed an action if the tool failed or was denied.
5. Safety: Destructive actions (deleting files, system shutdown) require user confirmation which the system handles.
6. Current System Context:
   - Operating System: Windows
   - Current Date & Time: {current_time}

{memory_context}
"""

    def __init__(
        self,
        tool_manager: Optional[ToolManager] = None,
        memory_manager: Optional[MemoryManager] = None,
        conversation_manager: Optional[ConversationManager] = None,
    ):
        self.tool_manager = tool_manager or ToolManager()
        self.memory_manager = memory_manager or MemoryManager()
        self.conversation_manager = conversation_manager or ConversationManager()

        self.provider = Config.DEFAULT_AI_PROVIDER
        self.ollama_url = Config.OLLAMA_BASE_URL
        self.ollama_model = Config.DEFAULT_OLLAMA_MODEL
        self.openai_api_key = Config.OPENAI_API_KEY
        self.openai_base_url = Config.OPENAI_BASE_URL
        self.openai_model = Config.DEFAULT_OPENAI_MODEL
        self.temperature = Config.AI_TEMPERATURE

    def get_available_ollama_models(self) -> List[str]:
        """Queries local Ollama instance for installed models."""
        try:
            url = f"{self.ollama_url.rstrip('/')}/api/tags"
            resp = requests.get(url, timeout=3.0)
            if resp.status_code == 200:
                data = resp.json()
                models = [m.get("name") for m in data.get("models", []) if m.get("name")]
                return models
        except Exception as e:
            logger.debug(f"Ollama not reachable at {self.ollama_url}: {e}")
        return []

    def check_connection(self) -> Dict[str, Any]:
        """Checks connectivity status of active AI provider."""
        if self.provider == "ollama":
            models = self.get_available_ollama_models()
            if models:
                return {
                    "online": True,
                    "provider": "ollama",
                    "models": models,
                    "message": f"Connected to Ollama. {len(models)} model(s) detected.",
                }
            return {
                "online": False,
                "provider": "ollama",
                "models": [],
                "message": f"Ollama not responding at {self.ollama_url}. Is Ollama running?",
            }
        elif self.provider == "openai":
            if not self.openai_api_key:
                return {
                    "online": False,
                    "provider": "openai",
                    "models": [],
                    "message": "OpenAI API Key is not configured.",
                }
            return {
                "online": True,
                "provider": "openai",
                "models": [self.openai_model],
                "message": f"Configured for OpenAI-compatible API ({self.openai_model}).",
            }
        return {"online": False, "provider": "none", "models": [], "message": "Unknown AI Provider"}

    def _build_system_prompt(self, user_prompt: str) -> str:
        """Constructs the system prompt with live time and retrieved user memory context."""
        memory_ctx = self.memory_manager.get_relevant_context(user_prompt)
        return self.SYSTEM_PROMPT_TEMPLATE.format(
            current_time=get_current_timestamp(),
            memory_context=memory_ctx,
        )

    def process_query(
        self,
        user_prompt: str,
        on_status_change: Optional[Callable[[str], None]] = None,
        on_tool_execute: Optional[Callable[[str, Dict[str, Any]], None]] = None,
        on_response_chunk: Optional[Callable[[str], None]] = None,
    ) -> Dict[str, Any]:
        """
        Main query pipeline:
        1. Formulates context (system prompt, memory, history)
        2. Queries LLM with tool schemas
        3. Executes tool calls if selected
        4. Queries LLM again with tool outputs for final natural answer
        5. Logs turn in SQLite conversation history
        """
        if on_status_change:
            on_status_change("THINKING")

        system_prompt = self._build_system_prompt(user_prompt)
        chat_history = self.conversation_manager.get_recent_chat_context(max_turns=4)

        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(chat_history)
        messages.append({"role": "user", "content": user_prompt})

        tools_schema = self.tool_manager.get_tool_schemas()
        executed_tool_calls = []
        executed_tool_results = []

        response_text = ""
        used_provider = self.provider

        try:
            # 1. Attempt Primary Provider Call
            if self.provider == "ollama":
                ai_response, tool_calls = self._call_ollama(
                    messages, tools_schema,
                    on_chunk=self._make_sentence_emitter(on_response_chunk),
                )
            elif self.provider == "openai" and self.openai_api_key:
                ai_response, tool_calls = self._call_openai(messages, tools_schema)
            else:
                # Local Rule-based fallback if no online provider
                ai_response, tool_calls = self._call_rule_fallback(user_prompt)
                used_provider = "fallback"

            # 2. Tool Calling Execution Loop
            if tool_calls:
                if on_status_change:
                    on_status_change("EXECUTING")

                for tc in tool_calls:
                    fn_name = tc.get("name")
                    fn_args = tc.get("arguments", {})
                    if on_tool_execute:
                        on_tool_execute(fn_name, fn_args)

                    tool_res = self.tool_manager.execute_tool(fn_name, fn_args)
                    executed_tool_calls.append({"name": fn_name, "arguments": fn_args})
                    executed_tool_results.append(tool_res)

                # Feed results back to model if available
                if used_provider in ("ollama", "openai"):
                    if on_status_change:
                        on_status_change("THINKING")

                    messages.append({
                        "role": "assistant",
                        "content": ai_response or "",
                        "tool_calls": [
                            {"type": "function", "function": {"name": tc["name"], "arguments": json.dumps(tc["arguments"])}}
                            for tc in tool_calls
                        ]
                    })

                    for tc, tr in zip(tool_calls, executed_tool_results):
                        res_str = json.dumps(tr.get("result") if tr.get("success") else {"error": tr.get("error")})
                        messages.append({
                            "role": "tool",
                            "name": tc["name"],
                            "content": res_str,
                        })

                    # Second turn for final summarized speech
                    if used_provider == "ollama":
                        final_resp, _ = self._call_ollama(messages, tools=None)
                    else:
                        final_resp, _ = self._call_openai(messages, tools=None)

                    response_text = final_resp or self._format_tool_results_fallback(executed_tool_results)
                else:
                    response_text = self._format_tool_results_fallback(executed_tool_results)
            else:
                response_text = ai_response

        except Exception as e:
            logger.error(f"Error during AI brain query processing: {e}", exc_info=True)
            # Fallback to local rule processor on error
            fb_resp, fb_tools = self._call_rule_fallback(user_prompt)
            if fb_tools:
                for tc in fb_tools:
                    tool_res = self.tool_manager.execute_tool(tc["name"], tc.get("arguments", {}))
                    executed_tool_calls.append(tc)
                    executed_tool_results.append(tool_res)
                response_text = self._format_tool_results_fallback(executed_tool_results)
            else:
                response_text = fb_resp or f"I encountered an error communicating with the AI brain: {e}"

        # Clean up response
        response_text = response_text.strip() if response_text else "I have completed your request, sir."

        # Log conversation turn
        self.conversation_manager.log_turn(
            user_message=user_prompt,
            assistant_response=response_text,
            tool_calls=executed_tool_calls,
            tool_results=executed_tool_results,
        )

        return {
            "response": response_text,
            "tool_calls": executed_tool_calls,
            "tool_results": executed_tool_results,
            "provider": used_provider,
        }

    def _call_ollama(self, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]], on_chunk: Optional[Callable[[str], None]] = None) -> Tuple[str, List[Dict[str, Any]]]:
        """Sends chat request to local Ollama API.

        When ``on_chunk`` is provided, the call uses Ollama's NDJSON streaming mode
        and invokes the callback with each newly-received piece of assistant content.
        The callback fires on sentence boundaries so the UI can start TTS immediately.
        """
        url = f"{self.ollama_url.rstrip('/')}/api/chat"
        payload = {
            "model": self.ollama_model,
            "messages": messages,
            "stream": bool(on_chunk),
            "options": {
                "temperature": self.temperature,
                "num_predict": Config.AI_MAX_TOKENS,
            },
        }
        if tools:
            payload["tools"] = tools

        if not on_chunk:
            resp = requests.post(url, json=payload, timeout=20.0)
            if resp.status_code != 200:
                raise RuntimeError(f"Ollama returned HTTP {resp.status_code}: {resp.text}")
            data = resp.json()
            msg = data.get("message", {})
            content = msg.get("content", "")
            tool_calls = self._parse_ollama_tool_calls(msg, content)
            return content, tool_calls

        # ---- Streaming path ----
        content = ""
        tool_calls: List[Dict[str, Any]] = []
        pending_msg: Dict[str, Any] = {}

        with requests.post(url, json=payload, timeout=20.0, stream=True) as resp:
            if resp.status_code != 200:
                raise RuntimeError(f"Ollama returned HTTP {resp.status_code}: {resp.text}")
            for line in resp.iter_lines(decode_unicode=True):
                if not line:
                    continue
                try:
                    data = json.loads(line)
                except Exception:
                    continue
                msg = data.get("message") or {}
                pending_msg = msg
                piece = msg.get("content", "")
                if piece:
                    content += piece
                if data.get("done"):
                    break

        tool_calls = self._parse_ollama_tool_calls(pending_msg, content)
        return content, tool_calls

    def _parse_ollama_tool_calls(self, msg: Dict[str, Any], content: str) -> List[Dict[str, Any]]:
        """Extracts native + markdown-JSON tool calls from an Ollama response message."""
        tool_calls: List[Dict[str, Any]] = []
        if msg.get("tool_calls"):
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                tool_calls.append({
                    "name": fn.get("name"),
                    "arguments": fn.get("arguments", {}),
                })
        if not tool_calls and content:
            tool_calls = self._extract_json_tool_calls(content)
        return tool_calls

    def _emit_chunk(self, chunk: str, on_response_chunk: Optional[Callable[[str], None]]):
        """Forwards an LLM response chunk to the UI's streaming hook (fire-and-forget)."""
        if on_response_chunk and chunk:
            try:
                on_response_chunk(chunk)
            except Exception:
                pass

    def _make_sentence_emitter(self, on_response_chunk: Optional[Callable[[str], None]]) -> Optional[Callable[[str], None]]:
        """
        Returns a streaming callback that buffers token chunks and emits them to the
        UI in sentence-sized pieces. This lets TTS start speaking within ~1 second
        of the first token instead of waiting for the full answer.
        """
        if not on_response_chunk:
            return None
        buffer = {"text": ""}

        def emit(chunk: str):
            buffer["text"] += chunk
            # Flush on sentence terminators or when buffer gets large enough.
            parts = re.split(r"(?<=[.!?])\s+", buffer["text"])
            if len(parts) > 1:
                for sentence in parts[:-1]:
                    sentence = sentence.strip()
                    if sentence:
                        try:
                            on_response_chunk(sentence)
                        except Exception:
                            pass
                buffer["text"] = parts[-1]
            elif len(buffer["text"]) > 180:
                # Long single sentence — flush a chunk to bound latency.
                try:
                    on_response_chunk(buffer["text"].strip())
                except Exception:
                    pass
                buffer["text"] = ""

        return emit

    def _call_openai(self, messages: List[Dict[str, Any]], tools: Optional[List[Dict[str, Any]]]) -> Tuple[str, List[Dict[str, Any]]]:
        """Sends chat request to OpenAI-compatible completions API."""
        url = f"{self.openai_base_url.rstrip('/')}/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openai_api_key}",
            "Content-Type": "application/json",
        }
        payload = {
            "model": self.openai_model,
            "messages": messages,
            "temperature": self.temperature,
        }
        if tools:
            payload["tools"] = tools
            payload["tool_choice"] = "auto"

        resp = requests.post(url, headers=headers, json=payload, timeout=20.0)
        if resp.status_code != 200:
            raise RuntimeError(f"OpenAI API returned HTTP {resp.status_code}: {resp.text}")

        data = resp.json()
        choice = data["choices"][0]
        msg = choice.get("message", {})
        content = msg.get("content", "") or ""
        tool_calls = []

        if "tool_calls" in msg and msg["tool_calls"]:
            for tc in msg["tool_calls"]:
                fn = tc.get("function", {})
                args = fn.get("arguments", "{}")
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except Exception:
                        args = {}
                tool_calls.append({
                    "name": fn.get("name"),
                    "arguments": args
                })

        return content, tool_calls

    def _extract_json_tool_calls(self, text: str) -> List[Dict[str, Any]]:
        """Extracts JSON tool calls from markdown code blocks if model formatted them as text."""
        tool_calls = []
        pattern = r"```(?:json)?\s*(\{\s*\"tool\"|\{\s*\"name\".*?\})\s*```"
        matches = re.findall(pattern, text, re.DOTALL)
        for m in matches:
            try:
                parsed = json.loads(m)
                name = parsed.get("name") or parsed.get("tool")
                args = parsed.get("arguments") or parsed.get("parameters", {})
                if name and name in self.tool_manager.tools:
                    tool_calls.append({"name": name, "arguments": args})
            except Exception:
                pass
        return tool_calls

    def _call_rule_fallback(self, query: str) -> Tuple[str, List[Dict[str, Any]]]:
        """
        Smart offline intent mapper.
        Ensures common natural language commands work smoothly even if Ollama/OpenAI is offline.
        """
        q = query.lower().strip()
        tool_calls = []

        # 1. System Info & Resource queries
        if any(w in q for w in ["cpu", "ram", "memory usage", "battery", "system info", "system status", "specs"]):
            if "cpu" in q:
                tool_calls.append({"name": "get_cpu_usage", "arguments": {}})
            elif "ram" in q or "memory usage" in q:
                tool_calls.append({"name": "get_ram_usage", "arguments": {}})
            elif "battery" in q:
                tool_calls.append({"name": "get_battery_status", "arguments": {}})
            else:
                tool_calls.append({"name": "get_system_information", "arguments": {}})
            return "Checking system metrics...", tool_calls

        # 2. Date & Time queries
        if any(w in q for w in ["what time", "current time", "what's the time", "tell me the time", "time now"]):
            tool_calls.append({"name": "get_current_time", "arguments": {}})
            return "Checking current time...", tool_calls

        if any(w in q for w in ["what date", "today's date", "what is the date", "tell me today's date", "day today"]):
            tool_calls.append({"name": "get_current_date", "arguments": {}})
            return "Checking current date...", tool_calls

        # 3. Weather queries
        if "weather" in q:
            match = re.search(r"weather (?:in|for|at)?\s*([a-zA-Z\s]+)", query, re.IGNORECASE)
            location = match.group(1).strip().rstrip("?") if match else Config.DEFAULT_LOCATION
            tool_calls.append({"name": "get_weather", "arguments": {"location": location}})
            return f"Checking weather for {location}...", tool_calls

        # 4. Math & Calculations
        if any(w in q for w in ["calculate", "what is", "how much is"]) and any(c in q for c in "+-*/%^0123456789"):
            calc_expr = re.sub(r"(?:calculate|what is|how much is|tell me)\s*", "", q).strip().rstrip("?")
            tool_calls.append({"name": "calculate", "arguments": {"expression": calc_expr}})
            return f"Calculating {calc_expr}...", tool_calls

        # 5. Application Launching
        if q.startswith("open ") or q.startswith("launch ") or q.startswith("start "):
            app_name = re.sub(r"^(open|launch|start)\s+", "", q).strip()
            # If it's a URL
            if app_name.startswith("http") or ".com" in app_name or ".org" in app_name:
                tool_calls.append({"name": "launch_url", "arguments": {"url": app_name}})
            elif "folder" in app_name or "directory" in app_name:
                folder_target = app_name.replace("folder", "").replace("directory", "").strip()
                tool_calls.append({"name": "open_folder", "arguments": {"folder_path": folder_target}})
            else:
                tool_calls.append({"name": "open_application", "arguments": {"app_name": app_name}})
            return f"Opening {app_name}...", tool_calls

        # 6. Application Closing
        if q.startswith("close ") or q.startswith("kill ") or q.startswith("exit "):
            app_name = re.sub(r"^(close|kill|exit)\s+", "", q).strip()
            tool_calls.append({"name": "close_application", "arguments": {"app_name": app_name}})
            return f"Closing {app_name}...", tool_calls

        # 7. Web & YouTube Search
        if "search youtube for" in q or "youtube search" in q:
            term = re.sub(r".*search youtube for\s*", "", q).strip()
            tool_calls.append({"name": "search_youtube", "arguments": {"query": term}})
            return f"Searching YouTube for '{term}'...", tool_calls

        if q.startswith("search the web for") or q.startswith("search for") or q.startswith("google ") or q.startswith("search web "):
            term = re.sub(r"^(search the web for|search for|google|search web|search)\s+", "", q).strip()
            tool_calls.append({"name": "search_web", "arguments": {"query": term}})
            return f"Searching the web for '{term}'...", tool_calls

        # 8. Memory: Remember & Retrieve
        if q.startswith("remember that ") or q.startswith("remember "):
            fact = re.sub(r"^remember (that )?", "", q).strip()
            key_match = re.match(r"(?:my )?([a-zA-Z\s]+?)\s+(?:is|are)\s+(.+)", fact)
            if key_match:
                key_fact = key_match.group(1).strip()
                val = key_match.group(2).strip()
            else:
                key_fact = fact[:30]
                val = fact
            tool_calls.append({"name": "remember_information", "arguments": {"key_fact": key_fact, "content": val}})
            return f"Remembering: {key_fact} -> {val}", tool_calls

        if any(w in q for w in ["what did i tell you", "what is my", "what are my", "do you remember", "recall"]):
            search_term = re.sub(r"^(what did i tell you about|what is my|what are my|do you remember|recall)\s*", "", q).strip().rstrip("?")
            tool_calls.append({"name": "retrieve_memory", "arguments": {"query": search_term}})
            return f"Recalling memories related to '{search_term}'...", tool_calls

        # 9. Volume & Media Control
        if "volume" in q or "mute" in q or "unmute" in q:
            if "mute" in q:
                tool_calls.append({"name": "mute_volume", "arguments": {}})
            elif "unmute" in q:
                tool_calls.append({"name": "unmute_volume", "arguments": {}})
            elif "up" in q or "increase" in q:
                tool_calls.append({"name": "volume_up", "arguments": {}})
            elif "down" in q or "decrease" in q or "lower" in q:
                tool_calls.append({"name": "volume_down", "arguments": {}})
            return "Adjusting volume...", tool_calls

        if any(w in q for w in ["play", "pause", "next track", "previous track"]):
            if "play" in q or "pause" in q:
                tool_calls.append({"name": "media_play_pause", "arguments": {}})
            elif "next" in q:
                tool_calls.append({"name": "media_next", "arguments": {}})
            elif "previous" in q or "prev" in q:
                tool_calls.append({"name": "media_previous", "arguments": {}})
            return "Controlling media playback...", tool_calls

        # 10. Screenshot
        if "screenshot" in q or "capture screen" in q:
            tool_calls.append({"name": "take_screenshot", "arguments": {}})
            return "Taking a screenshot...", tool_calls

        # 11. Clipboard
        if "read clipboard" in q or "what is in clipboard" in q or "get clipboard" in q:
            tool_calls.append({"name": "clipboard_read", "arguments": {}})
            return "Reading clipboard...", tool_calls

        # 12. File operations
        if "find" in q and ("file" in q or "pdf" in q or "python" in q):
            pattern = "*"
            if "pdf" in q:
                pattern = "*.pdf"
            elif "python" in q or "py" in q:
                pattern = "*.py"
            else:
                m = re.search(r"find (?:my )?([a-zA-Z0-9_\-\.\*]+) files?", q)
                if m:
                    pattern = f"*{m.group(1)}*"
            tool_calls.append({"name": "search_files", "arguments": {"pattern": pattern}})
            return f"Searching for files matching '{pattern}'...", tool_calls

        # Default conversational greeting / assistance prompt
        if any(w in q for w in ["hello", "hi", "hey", "jarvis", "good morning", "good evening", "who are you"]):
            return "Good day, sir. JARVIS is online and standing by. How may I assist you today?", []

        return (
            "I heard your request. To provide deep conversational answers, please ensure Ollama is running (`ollama run llama3.2`) or configure an OpenAI API key in Settings. I can execute all Windows automations, apps, files, weather, and tools directly.",
            []
        )

    def _format_tool_results_fallback(self, results: List[Dict[str, Any]]) -> str:
        """Constructs a clean summary of executed tool results."""
        if not results:
            return "Action completed successfully, sir."

        lines = []
        for r in results:
            tool_name = r.get("tool", "")
            if r.get("success"):
                res = r.get("result")
                if isinstance(res, dict):
                    # Format dict nicely
                    summary_parts = [f"{k.replace('_', ' ').title()}: {v}" for k, v in res.items() if not isinstance(v, (dict, list))]
                    lines.append(", ".join(summary_parts) if summary_parts else str(res))
                elif isinstance(res, str):
                    lines.append(res)
                elif isinstance(res, list):
                    lines.append("\n".join([f"• {item}" for item in res[:10]]))
                else:
                    lines.append(f"{tool_name}: {res}")
            else:
                err = r.get("error", "Unknown error")
                lines.append(f"Could not complete {tool_name}: {err}")

        return "\n\n".join(lines)
