"""
Tool Registry and Execution Manager for JARVIS.
Handles registration of built-in tools and dynamic plugins, generates JSON Schema
for LLM function calling, and executes validated tools with security interceptors.
"""

import importlib
import inspect
import json
import sys
from pathlib import Path
from typing import Dict, Any, List, Optional, Callable, Tuple
from app.core.security import SecurityManager, PermissionLevel
from app.core.plugin_base import BasePlugin, PluginTool
from app.config import PLUGINS_DIR
from app.utils.logger import get_logger

logger = get_logger("ToolManager")


class ToolDefinition:
    """Represents a validated tool available to the AI Engine."""

    def __init__(
        self,
        name: str,
        description: str,
        parameters: Dict[str, Any],
        handler: Callable[..., Any],
        permission_level: PermissionLevel = PermissionLevel.SAFE,
        category: str = "general",
    ):
        self.name = name
        self.description = description
        self.parameters = parameters
        self.handler = handler
        self.permission_level = permission_level
        self.category = category

    def to_openai_schema(self) -> Dict[str, Any]:
        """Formats the tool into standard OpenAI/Ollama function calling schema."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }

    def to_doc_string(self) -> str:
        """Generates concise text specification for prompt fallback parsing."""
        props = self.parameters.get("properties", {})
        required = self.parameters.get("required", [])
        params_str = ", ".join([f"{k}: {v.get('type', 'any')}{' (required)' if k in required else ''}" for k, v in props.items()])
        return f"- {self.name}({params_str}): {self.description}"


class ToolManager:
    """Central registry and execution dispatcher for all JARVIS tools and plugins."""

    def __init__(self, security_manager: Optional[SecurityManager] = None):
        self.tools: Dict[str, ToolDefinition] = {}
        self.plugins: Dict[str, BasePlugin] = {}
        self.security_manager = security_manager or SecurityManager()

    def register_tool(
        self,
        name: str,
        description: str,
        parameters: Dict[str, Any],
        handler: Callable[..., Any],
        permission_level: PermissionLevel = PermissionLevel.SAFE,
        category: str = "general",
    ) -> ToolDefinition:
        """Registers a callable tool into the registry."""
        tool_def = ToolDefinition(
            name=name,
            description=description,
            parameters=parameters,
            handler=handler,
            permission_level=permission_level,
            category=category,
        )
        self.tools[name] = tool_def
        logger.debug(f"Registered tool: {name} (Category: {category}, Permission: {permission_level.value})")
        return tool_def

    def register_plugin(self, plugin: BasePlugin):
        """Registers an instance of BasePlugin and all its exposed tools."""
        self.plugins[plugin.name] = plugin
        for ptool in plugin.get_tools():
            self.register_tool(
                name=ptool.name,
                description=ptool.description,
                parameters=ptool.parameters_schema,
                handler=ptool.handler,
                permission_level=ptool.permission_level,
                category=f"plugin:{plugin.name}",
            )
        logger.info(f"Loaded plugin: {plugin.name} v{plugin.version} with {len(plugin.get_tools())} tools")

    def load_plugins_from_directory(self, directory: Optional[Path] = None):
        """Discovers and hot-loads all BasePlugin subclasses found in the plugins directory."""
        dir_path = directory or PLUGINS_DIR
        if not dir_path.exists():
            return

        for py_file in dir_path.glob("*.py"):
            if py_file.name.startswith("__"):
                continue
            module_name = f"app.plugins.{py_file.stem}"
            try:
                if module_name in sys.modules:
                    module = importlib.reload(sys.modules[module_name])
                else:
                    module = importlib.import_module(module_name)

                for _, obj in inspect.getmembers(module, inspect.isclass):
                    if issubclass(obj, BasePlugin) and obj is not BasePlugin:
                        plugin_instance = obj()
                        self.register_plugin(plugin_instance)
            except Exception as e:
                logger.error(f"Failed to load plugin module {py_file.name}: {e}")

    def get_tool_schemas(self) -> List[Dict[str, Any]]:
        """Returns OpenAI/Ollama compatible tool schemas list."""
        return [tool.to_openai_schema() for tool in self.tools.values()]

    def get_tools_prompt_description(self) -> str:
        """Returns concise markdown formatted tool descriptions for system prompt injection."""
        lines = []
        for tool in self.tools.values():
            lines.append(tool.to_doc_string())
        return "\n".join(lines)

    def execute_tool(self, name: str, arguments: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Validates, applies security checks, and safely executes a tool.
        Returns a structured result dictionary:
        {"success": bool, "tool": str, "result": Any, "error": Optional[str]}
        """
        args = arguments or {}

        if name not in self.tools:
            error_msg = f"Tool '{name}' is not registered."
            logger.warning(error_msg)
            return {"success": False, "tool": name, "result": None, "error": error_msg}

        tool = self.tools[name]

        # Security permission check
        allowed = self.security_manager.check_permission(
            tool_name=name,
            tool_level=tool.permission_level,
            arguments=args,
            description=tool.description,
        )

        if not allowed:
            denied_msg = f"Execution of dangerous tool '{name}' was cancelled or denied by user."
            logger.info(denied_msg)
            return {"success": False, "tool": name, "result": None, "error": denied_msg, "permission_denied": True}

        # Execution with robust exception trapping
        try:
            logger.info(f"Executing tool '{name}' with args: {args}")
            result = tool.handler(**args)
            return {"success": True, "tool": name, "result": result, "error": None}
        except TypeError as te:
            error_msg = f"Argument validation error executing '{name}': {te}"
            logger.error(error_msg)
            return {"success": False, "tool": name, "result": None, "error": error_msg}
        except Exception as e:
            error_msg = f"Error executing tool '{name}': {e}"
            logger.error(error_msg, exc_info=True)
            return {"success": False, "tool": name, "result": None, "error": error_msg}
