"""
Abstract Plugin Base for JARVIS.
Plugins dynamically register custom tools and functionality into the ToolManager.
"""

from abc import ABC, abstractmethod
from typing import List, Dict, Any, Callable
from app.core.security import PermissionLevel


class PluginTool:
    """Represents an individual callable tool registered by a plugin."""

    def __init__(
        self,
        name: str,
        description: str,
        parameters_schema: Dict[str, Any],
        handler: Callable[..., Any],
        permission_level: PermissionLevel = PermissionLevel.SAFE,
    ):
        self.name = name
        self.description = description
        self.parameters_schema = parameters_schema
        self.handler = handler
        self.permission_level = permission_level

    def execute(self, **kwargs) -> Any:
        """Executes tool handler with validated keyword arguments."""
        return self.handler(**kwargs)


class BasePlugin(ABC):
    """Base interface for all JARVIS plugins."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Name of the plugin."""
        pass

    @property
    @abstractmethod
    def description(self) -> str:
        """Brief description of the plugin."""
        pass

    @property
    def version(self) -> str:
        """Plugin version string."""
        return "1.0.0"

    @abstractmethod
    def get_tools(self) -> List[PluginTool]:
        """Returns the list of callable tools provided by this plugin."""
        pass
