"""
Persistent Long-Term Memory Subsystem for JARVIS.
Stores, searches, updates, and deletes structured memories using SQLite.
Integrates context retrieval into the AI system prompt.
"""

from typing import List, Dict, Any, Optional
from app.core.database import Database
from app.utils.logger import get_logger
from app.utils.helpers import get_current_timestamp

logger = get_logger("Memory")


class MemoryManager:
    """Manages persistent structured memories across sessions."""

    VALID_CATEGORIES = ["preferences", "projects", "facts", "instructions", "summaries"]

    def __init__(self, db: Optional[Database] = None):
        self.db = db or Database()

    def remember(self, key_fact: str, content: str, category: str = "facts") -> Dict[str, Any]:
        """
        Stores or updates a memory.
        If key_fact already exists, updates content; otherwise creates a new record.
        """
        cat = category.lower().strip()
        if cat not in self.VALID_CATEGORIES:
            cat = "facts"

        key = key_fact.strip()
        val = content.strip()
        now = get_current_timestamp()

        conn = self.db._get_connection()
        cursor = conn.cursor()

        # Check existing
        cursor.execute("SELECT id FROM memories WHERE key_fact = ? COLLATE NOCASE", (key,))
        existing = cursor.fetchone()

        if existing:
            mem_id = existing["id"]
            cursor.execute("""
                UPDATE memories
                SET category = ?, content = ?, updated_at = ?
                WHERE id = ?
            """, (cat, val, now, mem_id))
            conn.commit()
            logger.info(f"Updated memory [{mem_id}] '{key}': '{val}' in category '{cat}'")
            return {"id": mem_id, "category": cat, "key_fact": key, "content": val, "status": "updated"}
        else:
            cursor.execute("""
                INSERT INTO memories (category, key_fact, content, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?)
            """, (cat, key, val, now, now))
            conn.commit()
            mem_id = cursor.lastrowid
            logger.info(f"Created new memory [{mem_id}] '{key}': '{val}' in category '{cat}'")
            return {"id": mem_id, "category": cat, "key_fact": key, "content": val, "status": "created"}

    def retrieve(self, query: str, category: Optional[str] = None, limit: int = 5) -> List[Dict[str, Any]]:
        """
        Searches memories matching the query terms or key facts.
        """
        conn = self.db._get_connection()
        cursor = conn.cursor()
        query_pattern = f"%{query.strip()}%"

        if category and category.lower() in self.VALID_CATEGORIES:
            cursor.execute("""
                SELECT id, category, key_fact, content, created_at, updated_at
                FROM memories
                WHERE category = ? AND (key_fact LIKE ? OR content LIKE ?)
                ORDER BY updated_at DESC
                LIMIT ?
            """, (category.lower(), query_pattern, query_pattern, limit))
        else:
            cursor.execute("""
                SELECT id, category, key_fact, content, created_at, updated_at
                FROM memories
                WHERE key_fact LIKE ? OR content LIKE ?
                ORDER BY updated_at DESC
                LIMIT ?
            """, (query_pattern, query_pattern, limit))

        rows = cursor.fetchall()
        return [dict(row) for row in rows]

    def list_memories(self, category: Optional[str] = None) -> List[Dict[str, Any]]:
        """Lists all stored memories, optionally filtered by category."""
        conn = self.db._get_connection()
        cursor = conn.cursor()
        if category and category.lower() in self.VALID_CATEGORIES:
            cursor.execute("""
                SELECT id, category, key_fact, content, created_at, updated_at
                FROM memories
                WHERE category = ?
                ORDER BY updated_at DESC
            """, (category.lower(),))
        else:
            cursor.execute("""
                SELECT id, category, key_fact, content, created_at, updated_at
                FROM memories
                ORDER BY category ASC, updated_at DESC
            """)
        return [dict(row) for row in cursor.fetchall()]

    def update(self, memory_id: int, content: str, category: Optional[str] = None) -> bool:
        """Updates the content or category of a specific memory by ID."""
        try:
            conn = self.db._get_connection()
            cursor = conn.cursor()
            now = get_current_timestamp()
            if category and category.lower() in self.VALID_CATEGORIES:
                cursor.execute("""
                    UPDATE memories
                    SET content = ?, category = ?, updated_at = ?
                    WHERE id = ?
                """, (content.strip(), category.lower().strip(), now, memory_id))
            else:
                cursor.execute("""
                    UPDATE memories
                    SET content = ?, updated_at = ?
                    WHERE id = ?
                """, (content.strip(), now, memory_id))
            conn.commit()
            return cursor.rowcount > 0
        except Exception as e:
            logger.error(f"Failed to update memory [{memory_id}]: {e}")
            return False

    def forget(self, identifier: str) -> bool:
        """
        Deletes a memory by numeric ID or by key_fact string.
        """
        conn = self.db._get_connection()
        cursor = conn.cursor()
        try:
            if str(identifier).isdigit():
                cursor.execute("DELETE FROM memories WHERE id = ?", (int(identifier),))
            else:
                cursor.execute("DELETE FROM memories WHERE key_fact = ? COLLATE NOCASE", (identifier.strip(),))
            conn.commit()
            deleted = cursor.rowcount > 0
            if deleted:
                logger.info(f"Deleted memory identified by '{identifier}'")
            return deleted
        except Exception as e:
            logger.error(f"Failed to delete memory '{identifier}': {e}")
            return False

    def clear_all(self) -> int:
        """Clears all stored memories from the database."""
        conn = self.db._get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM memories")
        count = cursor.rowcount
        conn.commit()
        logger.warning(f"Cleared all memories ({count} records deleted)")
        return count

    def get_relevant_context(self, user_prompt: str, max_items: int = 6) -> str:
        """
        Extracts relevant facts or all active memories to inject into the system prompt context.
        """
        # Get all memories or matching memories
        all_mems = self.list_memories()
        if not all_mems:
            return ""

        words = set(user_prompt.lower().split())
        scored_mems = []

        for m in all_mems:
            score = 0
            key_words = set(m["key_fact"].lower().split())
            content_words = set(m["content"].lower().split())
            overlap = (key_words | content_words) & words
            score += len(overlap) * 2
            if m["category"] in ("preferences", "instructions"):
                score += 1  # Always slightly bias instructions/preferences
            scored_mems.append((score, m))

        scored_mems.sort(key=lambda x: (x[0], x[1]["updated_at"]), reverse=True)
        selected = [m for _, m in scored_mems[:max_items]]

        if not selected:
            return ""

        lines = ["[Persistent User Memories & Facts]"]
        for m in selected:
            lines.append(f"- ({m['category'].upper()}) {m['key_fact']}: {m['content']}")
        return "\n".join(lines)
