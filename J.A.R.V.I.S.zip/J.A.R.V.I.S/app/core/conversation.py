"""
Conversation session and message history management for JARVIS.
Stores user queries, AI responses, tool call traces, and tool results into SQLite.
Provides session creation, retrieval, search, and export.
"""

import json
import uuid
from typing import List, Dict, Any, Optional
from app.core.database import Database
from app.utils.logger import get_logger
from app.utils.helpers import get_current_timestamp

logger = get_logger("Conversation")


class ConversationManager:
    """Manages multi-session conversation history and message logs."""

    def __init__(self, db: Optional[Database] = None):
        self.db = db or Database()
        self._current_session_id = self._generate_session_id()

    @staticmethod
    def _generate_session_id() -> str:
        """Generates a unique session identifier."""
        return f"session_{uuid.uuid4().hex[:12]}"

    @property
    def current_session_id(self) -> str:
        return self._current_session_id

    def start_new_session(self) -> str:
        """Starts a new conversation session and returns its ID."""
        self._current_session_id = self._generate_session_id()
        logger.info(f"Started new conversation session: {self._current_session_id}")
        return self._current_session_id

    def switch_session(self, session_id: str):
        """Switches the active conversation session."""
        self._current_session_id = session_id
        logger.info(f"Switched active session to: {session_id}")

    def log_turn(
        self,
        user_message: str,
        assistant_response: str,
        tool_calls: Optional[List[Dict[str, Any]]] = None,
        tool_results: Optional[List[Dict[str, Any]]] = None,
        session_id: Optional[str] = None,
    ) -> int:
        """
        Logs a completed interaction turn into the conversation history.
        """
        sess_id = session_id or self._current_session_id
        tool_calls_json = json.dumps(tool_calls or [])
        tool_results_json = json.dumps(tool_results or [])
        now = get_current_timestamp()

        conn = self.db._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO conversations (
                session_id, timestamp, user_message, assistant_response,
                tool_calls_json, tool_results_json
            )
            VALUES (?, ?, ?, ?, ?, ?)
        """, (sess_id, now, user_message, assistant_response, tool_calls_json, tool_results_json))
        conn.commit()
        turn_id = cursor.lastrowid
        logger.debug(f"Logged conversation turn [{turn_id}] in session {sess_id}")
        return turn_id

    def get_session_history(self, session_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Returns all messages in the specified or current session."""
        sess_id = session_id or self._current_session_id
        conn = self.db._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, session_id, timestamp, user_message, assistant_response,
                   tool_calls_json, tool_results_json
            FROM conversations
            WHERE session_id = ?
            ORDER BY id ASC
        """, (sess_id,))
        rows = cursor.fetchall()
        history = []
        for r in rows:
            history.append({
                "id": r["id"],
                "session_id": r["session_id"],
                "timestamp": r["timestamp"],
                "user_message": r["user_message"],
                "assistant_response": r["assistant_response"],
                "tool_calls": json.loads(r["tool_calls_json"]),
                "tool_results": json.loads(r["tool_results_json"]),
            })
        return history

    def get_recent_chat_context(self, session_id: Optional[str] = None, max_turns: int = 5) -> List[Dict[str, str]]:
        """
        Returns recent messages formatted as standard LLM message turns (role: user/assistant).
        """
        history = self.get_session_history(session_id)
        recent = history[-max_turns:]
        messages = []
        for turn in recent:
            messages.append({"role": "user", "content": turn["user_message"]})
            messages.append({"role": "assistant", "content": turn["assistant_response"]})
        return messages

    def list_all_sessions(self) -> List[Dict[str, Any]]:
        """Returns summary list of all unique conversation sessions with timestamps and previews."""
        conn = self.db._get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT session_id,
                   MIN(timestamp) as started_at,
                   MAX(timestamp) as last_activity,
                   COUNT(id) as turn_count,
                   (SELECT user_message FROM conversations c2 WHERE c2.session_id = c1.session_id ORDER BY id ASC LIMIT 1) as first_query
            FROM conversations c1
            GROUP BY session_id
            ORDER BY last_activity DESC
        """)
        rows = cursor.fetchall()
        return [dict(r) for r in rows]

    def search_conversations(self, query: str) -> List[Dict[str, Any]]:
        """Searches past conversations matching query string."""
        conn = self.db._get_connection()
        cursor = conn.cursor()
        query_pattern = f"%{query.strip()}%"
        cursor.execute("""
            SELECT id, session_id, timestamp, user_message, assistant_response
            FROM conversations
            WHERE user_message LIKE ? OR assistant_response LIKE ?
            ORDER BY timestamp DESC
            LIMIT 50
        """, (query_pattern, query_pattern))
        return [dict(r) for r in cursor.fetchall()]

    def delete_session(self, session_id: str) -> bool:
        """Deletes all messages in a specific session."""
        try:
            conn = self.db._get_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM conversations WHERE session_id = ?", (session_id,))
            conn.commit()
            deleted = cursor.rowcount > 0
            if session_id == self._current_session_id:
                self.start_new_session()
            return deleted
        except Exception as e:
            logger.error(f"Failed to delete session {session_id}: {e}")
            return False

    def clear_all_history(self) -> int:
        """Clears all conversation history."""
        conn = self.db._get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM conversations")
        count = cursor.rowcount
        conn.commit()
        self.start_new_session()
        logger.info(f"Cleared all conversation history ({count} turns)")
        return count
