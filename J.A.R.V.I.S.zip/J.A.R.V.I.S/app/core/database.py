"""
SQLite Database manager for JARVIS.
Handles connection lifecycle, schemas, indexing, settings persistence, and transactions.
"""

import sqlite3
import json
import threading
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from app.config import DB_PATH, DATA_DIR
from app.utils.logger import get_logger
from app.utils.helpers import get_current_timestamp

logger = get_logger("Database")


class Database:
    """Thread-safe SQLite database manager."""

    _default_instance: Optional["Database"] = None
    _lock = threading.Lock()

    def __new__(cls, db_path: Optional[str] = None):
        if db_path is not None:
            inst = super(Database, cls).__new__(cls)
            inst._initialized = False
            return inst

        with cls._lock:
            if cls._default_instance is None:
                cls._default_instance = super(Database, cls).__new__(cls)
                cls._default_instance._initialized = False
            return cls._default_instance

    def __init__(self, db_path: Optional[str] = None):
        if self._initialized:
            return
        self.db_path = db_path or DB_PATH
        # Ensure parent directory exists
        Path(self.db_path).parent.mkdir(parents=True, exist_ok=True)
        self._local = threading.local()
        self._init_schema()
        self._initialized = True
        logger.info(f"Database initialized at: {self.db_path}")

    def _get_connection(self) -> sqlite3.Connection:
        """Returns thread-local SQLite connection."""
        if not hasattr(self._local, "conn") or self._local.conn is None:
            conn = sqlite3.connect(self.db_path, timeout=10.0, check_same_thread=False)
            conn.row_factory = sqlite3.Row
            # Enable WAL mode for high concurrency
            conn.execute("PRAGMA journal_mode=WAL;")
            conn.execute("PRAGMA foreign_keys=ON;")
            self._local.conn = conn
        return self._local.conn

    def _init_schema(self):
        """Initializes database tables and indexes."""
        conn = self._get_connection()
        cursor = conn.cursor()

        # 1. Settings Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
        """)

        # 2. Long-term Memories Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS memories (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                category TEXT NOT NULL,
                key_fact TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_memories_cat ON memories(category);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_memories_key ON memories(key_fact);")

        # 3. Conversation Sessions & History
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                user_message TEXT NOT NULL,
                assistant_response TEXT NOT NULL,
                tool_calls_json TEXT DEFAULT '[]',
                tool_results_json TEXT DEFAULT '[]'
            );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_conv_session ON conversations(session_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_conv_time ON conversations(timestamp);")

        # 4. Custom Installed Applications Registry
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS custom_apps (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL UNIQUE COLLATE NOCASE,
                path TEXT NOT NULL,
                is_favorite INTEGER DEFAULT 0,
                created_at TEXT NOT NULL
            );
        """)

        conn.commit()

    # --- Settings Key-Value Store ---

    def get_setting(self, key: str, default: Any = None) -> Any:
        """Retrieves a setting value by key, deserializing from JSON if applicable."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = cursor.fetchone()
        if row:
            try:
                return json.loads(row["value"])
            except Exception:
                return row["value"]
        return default

    def set_setting(self, key: str, value: Any):
        """Saves a setting value, serializing complex objects to JSON."""
        conn = self._get_connection()
        cursor = conn.cursor()
        serialized = json.dumps(value) if not isinstance(value, str) else value
        now = get_current_timestamp()
        cursor.execute("""
            INSERT INTO settings (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at;
        """, (key, serialized, now))
        conn.commit()

    def get_all_settings(self) -> Dict[str, Any]:
        """Returns all configured settings as a dictionary."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT key, value FROM settings")
        rows = cursor.fetchall()
        result = {}
        for row in rows:
            try:
                result[row["key"]] = json.loads(row["value"])
            except Exception:
                result[row["key"]] = row["value"]
        return result

    # --- Custom Application Shortcuts ---

    def add_custom_app(self, name: str, path: str) -> bool:
        """Registers a custom application executable or shortcut."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            now = get_current_timestamp()
            cursor.execute("""
                INSERT INTO custom_apps (name, path, created_at)
                VALUES (?, ?, ?)
                ON CONFLICT(name) DO UPDATE SET path = excluded.path;
            """, (name.strip(), path.strip(), now))
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to add custom app {name}: {e}")
            return False

    def remove_custom_app(self, name: str) -> bool:
        """Removes a registered custom application by name."""
        try:
            conn = self._get_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM custom_apps WHERE name = ? COLLATE NOCASE", (name.strip(),))
            conn.commit()
            return True
        except Exception as e:
            logger.error(f"Failed to remove custom app {name}: {e}")
            return False

    def list_custom_apps(self) -> List[Dict[str, Any]]:
        """Returns list of registered custom applications."""
        conn = self._get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, name, path, is_favorite, created_at FROM custom_apps ORDER BY name ASC")
        return [dict(row) for row in cursor.fetchall()]

    def close(self):
        """Closes thread connection if open."""
        if hasattr(self._local, "conn") and self._local.conn is not None:
            self._local.conn.close()
            self._local.conn = None
