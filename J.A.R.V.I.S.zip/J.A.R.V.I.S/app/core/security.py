"""
Security and Permission Management for JARVIS.
Defines permission tiers (SAFE, MODERATE, DANGEROUS) and enforces confirmation checks
before executing destructive or high-risk operations.
"""

from enum import Enum
from typing import Dict, Any, Optional, Callable
from app.config import Config
from app.utils.logger import get_logger

logger = get_logger("Security")


class PermissionLevel(str, Enum):
    SAFE = "safe"              # Read-only operations, queries, arithmetic
    MODERATE = "moderate"      # Non-destructive actions (launch apps, write text, volume)
    DANGEROUS = "dangerous"    # Destructive actions (delete files, shutdown, kill processes)


class SecurityManager:
    """Evaluates tool execution requests against configured security policies."""

    def __init__(self, confirmation_callback: Optional[Callable[[str, Dict[str, Any], str], bool]] = None):
        """
        confirmation_callback: Callable(tool_name, arguments, description) -> bool
        Returns True if user approves, False if denied.
        """
        self.confirmation_callback = confirmation_callback
        self.require_file_deletion_confirm = Config.REQUIRE_CONFIRMATION_DELETION
        self.require_shutdown_confirm = Config.REQUIRE_CONFIRMATION_SHUTDOWN

    def set_confirmation_callback(self, callback: Callable[[str, Dict[str, Any], str], bool]):
        """Sets or updates the UI confirmation prompt callback."""
        self.confirmation_callback = callback

    def check_permission(
        self,
        tool_name: str,
        tool_level: PermissionLevel,
        arguments: Dict[str, Any],
        description: str = "",
    ) -> bool:
        """
        Determines whether tool execution is permitted.
        If tool is DANGEROUS or requires confirmation, invokes callback if available.
        """
        if tool_level == PermissionLevel.SAFE:
            return True

        if tool_level == PermissionLevel.MODERATE:
            # Moderate actions proceed automatically unless strictly configured otherwise
            return True

        if tool_level == PermissionLevel.DANGEROUS:
            logger.warning(f"Security Alert: Intercepted DANGEROUS tool execution: '{tool_name}' with args {arguments}")

            if self.confirmation_callback is not None:
                try:
                    approved = self.confirmation_callback(tool_name, arguments, description)
                    logger.info(f"User confirmation result for '{tool_name}': {'APPROVED' if approved else 'DENIED'}")
                    return approved
                except Exception as e:
                    logger.error(f"Error during confirmation callback for '{tool_name}': {e}")
                    return False
            else:
                logger.warning(f"No confirmation callback registered. Blocking execution of '{tool_name}'.")
                return False

        return False
