"""
System Telemetry HUD Bar Widget for JARVIS.
Displays live CPU, RAM, Battery, Network, Date/Time, and Active Model chips.
"""

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QFrame, QHBoxLayout, QVBoxLayout, QLabel, QProgressBar
from datetime import datetime
from app.utils.helpers import format_bytes


class SystemHudWidget(QFrame):
    """Real-time HUD status bar."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("HudBar")
        self._init_ui()

        # Local clock timer (updates every 1s)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self._update_clock)
        self.clock_timer.start(1000)

    def _init_ui(self):
        layout = QHBoxLayout(self)
        layout.setContentsMargins(12, 6, 12, 6)
        layout.setSpacing(16)

        # 1. CPU Metric
        cpu_box = QVBoxLayout()
        cpu_box.setSpacing(2)
        lbl_cpu = QLabel("CPU USAGE")
        lbl_cpu.setProperty("class", "HudTitle")
        self.val_cpu = QLabel("0.0%")
        self.val_cpu.setProperty("class", "HudValue")
        cpu_box.addWidget(lbl_cpu)
        cpu_box.addWidget(self.val_cpu)
        layout.addLayout(cpu_box)

        # 2. RAM Metric
        ram_box = QVBoxLayout()
        ram_box.setSpacing(2)
        lbl_ram = QLabel("MEMORY")
        lbl_ram.setProperty("class", "HudTitle")
        self.val_ram = QLabel("0.0%")
        self.val_ram.setProperty("class", "HudValue")
        ram_box.addWidget(lbl_ram)
        ram_box.addWidget(self.val_ram)
        layout.addLayout(ram_box)

        # 3. Battery Metric
        bat_box = QVBoxLayout()
        bat_box.setSpacing(2)
        lbl_bat = QLabel("POWER / BATTERY")
        lbl_bat.setProperty("class", "HudTitle")
        self.val_bat = QLabel("AC Power")
        self.val_bat.setProperty("class", "HudValue")
        bat_box.addWidget(lbl_bat)
        bat_box.addWidget(self.val_bat)
        layout.addLayout(bat_box)

        # 4. Network Status
        net_box = QVBoxLayout()
        net_box.setSpacing(2)
        lbl_net = QLabel("NETWORK")
        lbl_net.setProperty("class", "HudTitle")
        self.val_net = QLabel("ONLINE")
        self.val_net.setProperty("class", "HudValue")
        net_box.addWidget(lbl_net)
        net_box.addWidget(self.val_net)
        layout.addLayout(net_box)

        # Spacer
        layout.addStretch()

        # 5. Active Model Badge
        model_box = QVBoxLayout()
        model_box.setSpacing(2)
        lbl_model = QLabel("ACTIVE BRAIN")
        lbl_model.setProperty("class", "HudTitle")
        lbl_model.setAlignment(Qt.AlignRight)
        self.val_model = QLabel("Ollama: llama3.2")
        self.val_model.setProperty("class", "HudValue")
        self.val_model.setAlignment(Qt.AlignRight)
        self.val_model.setStyleSheet("color: #38bdf8;")
        model_box.addWidget(lbl_model)
        model_box.addWidget(self.val_model)
        layout.addLayout(model_box)

        # 6. Current Time Clock
        time_box = QVBoxLayout()
        time_box.setSpacing(2)
        self.lbl_date = QLabel(datetime.now().strftime("%a, %b %d"))
        self.lbl_date.setProperty("class", "HudTitle")
        self.lbl_date.setAlignment(Qt.AlignRight)
        self.val_time = QLabel(datetime.now().strftime("%I:%M:%S %p"))
        self.val_time.setProperty("class", "HudValue")
        self.val_time.setAlignment(Qt.AlignRight)
        self.val_time.setStyleSheet("color: #00e5ff; font-weight: bold;")
        time_box.addWidget(self.lbl_date)
        time_box.addWidget(self.val_time)
        layout.addLayout(time_box)

    def _update_clock(self):
        now = datetime.now()
        self.lbl_date.setText(now.strftime("%a, %b %d"))
        self.val_time.setText(now.strftime("%I:%M:%S %p"))

    def update_metrics(self, data: dict):
        """Updates telemetry labels from background system snapshot."""
        # CPU
        cpu_pct = data.get("cpu_percent", 0.0)
        self.val_cpu.setText(f"{cpu_pct}%")
        if cpu_pct > 80:
            self.val_cpu.setStyleSheet("color: #ef4444;")
        elif cpu_pct > 50:
            self.val_cpu.setStyleSheet("color: #f59e0b;")
        else:
            self.val_cpu.setStyleSheet("color: #00e5ff;")

        # RAM
        ram_pct = data.get("ram_percent", 0.0)
        ram_used = format_bytes(data.get("ram_used_bytes", 0))
        self.val_ram.setText(f"{ram_pct}% ({ram_used})")

        # Battery
        bat_pct = data.get("battery_percent")
        plugged = data.get("battery_power_plugged")
        if bat_pct is not None:
            status_str = f"{bat_pct}% {'(Charging)' if plugged else ''}"
            self.val_bat.setText(status_str)
        else:
            self.val_bat.setText("AC Connected")

        # Network
        is_online = data.get("network_connected", False)
        self.val_net.setText("ONLINE" if is_online else "OFFLINE")
        self.val_net.setStyleSheet("color: #10b981;" if is_online else "color: #ef4444;")

    def set_active_model_name(self, model_name: str, provider: str = "ollama"):
        """Sets the active model badge text."""
        self.val_model.setText(f"{provider.upper()}: {model_name}")
