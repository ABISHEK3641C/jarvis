"""
Chat Stream and Conversation Message Widget for JARVIS.
Renders stylized user prompts, AI markdown responses, tool execution badges, and action chips.
"""

from typing import Optional, List, Dict, Any
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QCursor, QFont
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QScrollArea,
    QFrame,
    QLabel,
    QTextBrowser,
    QPushButton,
    QApplication,
)


class ToolBadge(QFrame):
    """Badge representing an executed tool call and its output."""

    def __init__(self, tool_name: str, arguments: dict, result: Optional[dict] = None, parent=None):
        super().__init__(parent)
        self.setProperty("class", "ToolCard")
        self.tool_name = tool_name
        self.arguments = arguments
        self.result = result
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(8, 6, 8, 6)
        layout.setSpacing(4)

        header = QHBoxLayout()
        icon_lbl = QLabel("⚙️")
        name_lbl = QLabel(f"Tool: <b>{self.tool_name}</b>")
        name_lbl.setStyleSheet("color: #38bdf8; font-size: 11px;")
        header.addWidget(icon_lbl)
        header.addWidget(name_lbl)
        header.addStretch()

        if self.result is not None:
            success = self.result.get("success", True)
            status_lbl = QLabel("SUCCESS" if success else "FAILED")
            status_lbl.setStyleSheet(f"color: {'#10b981' if success else '#ef4444'}; font-size: 10px; font-weight: bold;")
            header.addWidget(status_lbl)

        layout.addLayout(header)

        # Show brief summary of args or result
        if self.arguments:
            args_str = ", ".join(f"{k}='{v}'" for k, v in self.arguments.items())
            args_lbl = QLabel(f"Args: {args_str}")
            args_lbl.setStyleSheet("color: #64748b; font-size: 11px;")
            args_lbl.setWordWrap(True)
            layout.addWidget(args_lbl)


class MessageBubble(QFrame):
    """Individual message bubble for User or JARVIS."""

    def __init__(self, sender: str, text: str, tool_calls: Optional[List[dict]] = None, parent=None):
        super().__init__(parent)
        self.sender = sender.lower()
        self.text = text
        self.tool_calls = tool_calls or []
        self._init_ui()

    def _init_ui(self):
        is_user = self.sender == "user"
        self.setProperty("class", "UserBubble" if is_user else "AssistantBubble")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)

        # Header with name and copy action
        header_layout = QHBoxLayout()
        name_label = QLabel("YOU" if is_user else "JARVIS")
        name_label.setStyleSheet(f"color: {'#38bdf8' if is_user else '#00e5ff'}; font-weight: bold; font-size: 11px;")
        header_layout.addWidget(name_label)
        header_layout.addStretch()

        copy_btn = QPushButton("Copy")
        copy_btn.setFixedSize(45, 20)
        copy_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                border: 1px solid #1e293b;
                border-radius: 3px;
                color: #64748b;
                font-size: 10px;
                padding: 1px;
            }
            QPushButton:hover {
                color: #00e5ff;
                border: 1px solid #00e5ff;
            }
        """)
        copy_btn.clicked.connect(self._copy_to_clipboard)
        header_layout.addWidget(copy_btn)
        layout.addLayout(header_layout)

        # Tool execution badges if any
        for tc in self.tool_calls:
            badge = ToolBadge(tool_name=tc.get("name", "tool"), arguments=tc.get("arguments", {}))
            layout.addWidget(badge)

        # Body Text Browser (supports Markdown / HTML)
        self.text_browser = QTextBrowser()
        self.text_browser.setOpenExternalLinks(True)
        self.text_browser.setStyleSheet("""
            QTextBrowser {
                background-color: transparent;
                border: none;
                color: #f0f9ff;
                font-size: 13px;
                line-height: 1.4;
            }
        """)
        self.text_browser.setMarkdown(self.text)
        self.text_browser.document().adjustSize()
        self.text_browser.setFixedHeight(int(self.text_browser.document().size().height()) + 15)

        layout.addWidget(self.text_browser)

    def _copy_to_clipboard(self):
        clipboard = QApplication.clipboard()
        clipboard.setText(self.text)


class ChatViewWidget(QWidget):
    """Scrollable container displaying the conversation message stream."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._init_ui()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)

        # Scroll Area
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

        self.content_widget = QWidget()
        self.content_widget.setObjectName("ChatContentArea")
        self.messages_layout = QVBoxLayout(self.content_widget)
        self.messages_layout.setContentsMargins(12, 12, 12, 12)
        self.messages_layout.setSpacing(12)
        self.messages_layout.addStretch()

        self.scroll_area.setWidget(self.content_widget)
        main_layout.addWidget(self.scroll_area)

    def add_message(self, sender: str, text: str, tool_calls: Optional[List[dict]] = None):
        """Appends a new message bubble into the conversation stream."""
        bubble = MessageBubble(sender=sender, text=text, tool_calls=tool_calls)

        # Insert before bottom stretch
        count = self.messages_layout.count()
        self.messages_layout.insertWidget(count - 1, bubble)

        # Auto-scroll to bottom after brief layout calculation
        QTimer.singleShot(50, self.scroll_to_bottom)

    def scroll_to_bottom(self):
        """Scrolls the chat viewport to the latest message."""
        bar = self.scroll_area.verticalScrollBar()
        bar.setValue(bar.maximum())

    def clear_chat(self):
        """Removes all message bubbles."""
        while self.messages_layout.count() > 1:
            item = self.messages_layout.takeAt(0)
            widget = item.widget()
            if widget:
                widget.deleteLater()
