"""
JARVIS Vision Panel Widget.
Shows live webcam feed with face detection overlay and emotion status badge.
Integrates with FaceEmotionWorker to display real-time emotion analysis.
"""

from PySide6.QtCore import Qt, QTimer, Signal, QObject
from PySide6.QtWidgets import QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
from PySide6.QtGui import QImage, QPixmap, QFont
from app.utils.logger import get_logger

logger = get_logger("VisionPanel")

# Emotion → emoji + color for the badge
EMOTION_BADGE: dict = {
    "happy":    ("😄 HAPPY",    "#10b981"),
    "sad":      ("😢 SAD",      "#60a5fa"),
    "angry":    ("😠 ANGRY",    "#ef4444"),
    "fear":     ("😨 FEARFUL",  "#f59e0b"),
    "surprise": ("😮 SURPRISED","#a78bfa"),
    "disgust":  ("🤢 DISGUST",  "#84cc16"),
    "neutral":  ("😐 NEUTRAL",  "#64748b"),
}


class FrameBridgeWorker(QObject):
    """Receives numpy frames from background thread and bridges them to Qt main thread."""
    frame_arrived = Signal(object)

    def receive_frame(self, frame):
        self.frame_arrived.emit(frame)


class VisionPanelWidget(QFrame):
    """
    Compact camera panel with:
    - Live webcam feed (320×240 preview)
    - Face detection cyan bounding box overlay
    - Emotion status badge with emoji
    - Toggle button to enable/disable camera
    """

    emotion_changed = Signal(str, float)  # emotion, confidence

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("VisionPanel")
        self.setStyleSheet("""
            QFrame#VisionPanel {
                background-color: #060e1d;
                border: 1px solid #1a2a47;
                border-radius: 10px;
            }
        """)
        self.setFixedWidth(340)

        self._worker = None
        self._camera_active = False

        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(8)

        # Header
        header_row = QHBoxLayout()
        header_lbl = QLabel("◈ JARVIS VISION")
        header_lbl.setStyleSheet("color: #00e5ff; font-weight: bold; font-size: 12px; letter-spacing: 2px;")
        header_row.addWidget(header_lbl)
        header_row.addStretch()

        self.btn_toggle = QPushButton("▶ Activate")
        self.btn_toggle.setStyleSheet("""
            QPushButton {
                background-color: #0f2744;
                border: 1px solid #00e5ff;
                color: #00e5ff;
                font-weight: bold;
                font-size: 11px;
                border-radius: 5px;
                padding: 4px 10px;
            }
            QPushButton:hover { background-color: #1a3a5c; }
        """)
        self.btn_toggle.clicked.connect(self.toggle_camera)
        header_row.addWidget(self.btn_toggle)
        layout.addLayout(header_row)

        # Video Feed Label
        self.lbl_feed = QLabel()
        self.lbl_feed.setFixedSize(320, 240)
        self.lbl_feed.setAlignment(Qt.AlignCenter)
        self.lbl_feed.setStyleSheet("background-color: #040914; border: 1px solid #1e3a5f; border-radius: 6px;")
        self.lbl_feed.setText("Camera Offline\nClick ▶ to Activate")
        self.lbl_feed.setFont(QFont("Segoe UI", 10))
        self.lbl_feed.setStyleSheet(
            "color: #334155; font-size: 13px; background-color: #040914; "
            "border: 1px solid #1e3a5f; border-radius: 6px;"
        )
        layout.addWidget(self.lbl_feed, alignment=Qt.AlignHCenter)

        # Emotion Badge
        self.lbl_emotion = QLabel("● EMOTION: — DETECTING —")
        self.lbl_emotion.setAlignment(Qt.AlignCenter)
        self.lbl_emotion.setStyleSheet(
            "color: #64748b; font-size: 12px; font-weight: bold; "
            "background-color: #040914; border: 1px solid #1e3a5f; "
            "border-radius: 6px; padding: 4px 10px;"
        )
        layout.addWidget(self.lbl_emotion)

        # Face status
        self.lbl_face_status = QLabel("Face: Not detected")
        self.lbl_face_status.setAlignment(Qt.AlignCenter)
        self.lbl_face_status.setStyleSheet("color: #475569; font-size: 10px;")
        layout.addWidget(self.lbl_face_status)

    def toggle_camera(self):
        if self._camera_active:
            self._stop_camera()
        else:
            self._start_camera()

    def _start_camera(self):
        from app.tools.face_emotion import FaceEmotionWorker

        self.btn_toggle.setText("⏹ Deactivate")
        self._camera_active = True

        self._worker = FaceEmotionWorker(
            on_emotion_detected=self._on_emotion_detected_bg,
            on_frame_ready=self._on_frame_ready_bg,
        )
        self._worker.start()

        # Timer to poll frames (avoids threading issues with Qt)
        self._frame_timer = QTimer()
        self._frame_timer.setInterval(33)  # ~30fps
        self._frame_timer.timeout.connect(self._poll_frame_queue)
        self._frame_timer.start()

        self.lbl_feed.setStyleSheet(
            "background-color: #040914; border: 1px solid #00e5ff; border-radius: 6px;"
        )

    def _stop_camera(self):
        if hasattr(self, "_frame_timer"):
            self._frame_timer.stop()
        if self._worker:
            self._worker.stop()
            self._worker = None

        self._camera_active = False
        self.btn_toggle.setText("▶ Activate")
        self.lbl_feed.clear()
        self.lbl_feed.setText("Camera Offline\nClick ▶ to Activate")
        self.lbl_feed.setStyleSheet(
            "color: #334155; font-size: 13px; background-color: #040914; "
            "border: 1px solid #1e3a5f; border-radius: 6px;"
        )
        self.lbl_emotion.setText("● EMOTION: — —")
        self.lbl_emotion.setStyleSheet(
            "color: #64748b; font-size: 12px; font-weight: bold; "
            "background-color: #040914; border: 1px solid #1e3a5f; "
            "border-radius: 6px; padding: 4px 10px;"
        )
        self.lbl_face_status.setText("Face: Not detected")

    def _on_frame_ready_bg(self, frame):
        """Called from background thread — store frame for Qt timer polling."""
        self._latest_frame = frame

    def _on_emotion_detected_bg(self, emotion: str, confidence: float):
        """Called from background thread — bridge to Qt via signal."""
        self.emotion_changed.emit(emotion, confidence)

    def _poll_frame_queue(self):
        """Called from Qt main thread timer — renders latest frame."""
        frame = getattr(self, "_latest_frame", None)
        if frame is None:
            return

        self._latest_frame = None  # consume

        # Update emotion badge from worker state
        if self._worker and self._worker.face_detected:
            emotion = self._worker.current_emotion
            conf = self._worker.current_confidence
            badge_text, badge_color = EMOTION_BADGE.get(emotion, ("● NEUTRAL", "#64748b"))
            self.lbl_emotion.setText(f"● EMOTION: {badge_text}  ({conf:.0f}%)")
            self.lbl_emotion.setStyleSheet(
                f"color: {badge_color}; font-size: 12px; font-weight: bold; "
                f"background-color: #040914; border: 1px solid {badge_color}; "
                f"border-radius: 6px; padding: 4px 10px;"
            )
            self.lbl_face_status.setText("● Face: Detected")
            self.lbl_face_status.setStyleSheet("color: #10b981; font-size: 10px; font-weight: bold;")
        elif self._worker:
            self.lbl_emotion.setText("● EMOTION: Searching for face...")
            self.lbl_emotion.setStyleSheet(
                "color: #64748b; font-size: 12px; font-weight: bold; "
                "background-color: #040914; border: 1px solid #1e3a5f; "
                "border-radius: 6px; padding: 4px 10px;"
            )
            self.lbl_face_status.setText("Face: Not in frame")
            self.lbl_face_status.setStyleSheet("color: #475569; font-size: 10px;")

        # Convert BGR numpy frame → Qt QPixmap
        try:
            import cv2
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb.shape
            bytes_per_line = ch * w
            qt_img = QImage(rgb.data, w, h, bytes_per_line, QImage.Format_RGB888)
            pixmap = QPixmap.fromImage(qt_img).scaled(320, 240, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.lbl_feed.setPixmap(pixmap)
        except Exception as e:
            logger.debug(f"Frame render error: {e}")

    def closeEvent(self, event):
        self._stop_camera()
        super().closeEvent(event)
