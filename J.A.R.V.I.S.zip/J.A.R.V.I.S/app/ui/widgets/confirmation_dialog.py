"""
High-Tech Security Confirmation Modal for JARVIS.
Intercepts dangerous / destructive tool requests (file deletion, process termination, system shutdown)
and prompts the user for explicit approval.
"""

from typing import Dict, Any
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
)


class ConfirmationDialog(QDialog):
    """Interactive permission prompt dialog for dangerous actions."""

    def __init__(self, tool_name: str, arguments: Dict[str, Any], description: str = "", parent=None):
        super().__init__(parent)
        self.tool_name = tool_name
        self.arguments = arguments
        self.description = description
        self.approved = False
        self.setWindowTitle("JARVIS Security Alert - Action Confirmation")
        self.setFixedSize(480, 260)
        self.setModal(True)
        self._init_ui()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)

        # Warning Header
        header = QHBoxLayout()
        icon_lbl = QLabel("⚠️")
        icon_lbl.setStyleSheet("font-size: 24px;")
        title_lbl = QLabel("SECURITY CONFIRMATION REQUIRED")
        title_lbl.setStyleSheet("color: #ffab00; font-size: 14px; font-weight: bold; letter-spacing: 1px;")
        header.addWidget(icon_lbl)
        header.addWidget(title_lbl)
        header.addStretch()
        layout.addLayout(header)

        # Details Frame
        details_frame = QFrame()
        details_frame.setStyleSheet("background-color: #0c1424; border: 1px solid #ffab00; border-radius: 8px; padding: 10px;")
        details_layout = QVBoxLayout(details_frame)
        details_layout.setSpacing(6)

        tool_lbl = QLabel(f"<b>Requested Operation:</b> <span style='color: #00e5ff;'>{self.tool_name}</span>")
        details_layout.addWidget(tool_lbl)

        if self.description:
            desc_lbl = QLabel(f"<b>Details:</b> {self.description}")
            desc_lbl.setStyleSheet("color: #94a3b8; font-size: 12px;")
            details_layout.addWidget(desc_lbl)

        args_str = ", ".join(f"{k}='{v}'" for k, v in self.arguments.items())
        args_lbl = QLabel(f"<b>Parameters:</b> <code>{args_str}</code>")
        args_lbl.setStyleSheet("color: #cbd5e1; font-size: 11px;")
        args_lbl.setWordWrap(True)
        details_layout.addWidget(args_lbl)

        layout.addWidget(details_frame)

        # Prompt question
        question_lbl = QLabel("Are you sure you want JARVIS to execute this operation?")
        question_lbl.setStyleSheet("color: #f8fafc; font-size: 13px; font-weight: 500;")
        layout.addWidget(question_lbl)

        # Action Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()

        self.btn_deny = QPushButton("Deny / Cancel")
        self.btn_deny.setStyleSheet("""
            QPushButton {
                background-color: #3f1d24;
                border: 1px solid #ef4444;
                color: #ef4444;
                padding: 8px 18px;
            }
            QPushButton:hover {
                background-color: #ef4444;
                color: #ffffff;
            }
        """)
        self.btn_deny.clicked.connect(self._on_deny)
        btn_layout.addWidget(self.btn_deny)

        self.btn_approve = QPushButton("Approve & Execute")
        self.btn_approve.setStyleSheet("""
            QPushButton {
                background-color: #0f392b;
                border: 1px solid #10b981;
                color: #10b981;
                font-weight: bold;
                padding: 8px 18px;
            }
            QPushButton:hover {
                background-color: #10b981;
                color: #080d1a;
            }
        """)
        self.btn_approve.clicked.connect(self._on_approve)
        btn_layout.addWidget(self.btn_approve)

        layout.addLayout(btn_layout)

    def _on_approve(self):
        self.approved = True
        self.accept()

    def _on_deny(self):
        self.approved = False
        self.reject()

    @classmethod
    def ask_confirmation(cls, tool_name: str, arguments: Dict[str, Any], description: str = "", parent=None) -> bool:
        """Helper to instantiate and show the dialog synchronously."""
        dialog = cls(tool_name, arguments, description, parent=parent)
        dialog.exec()
        return dialog.approved
