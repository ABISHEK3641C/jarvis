"""
Animated Holographic Status Visualizer Widget for JARVIS.
Renders high-tech circular HUD rings, dynamic sound waveforms, and state transitions using QPainter.
"""

import math
from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
from PySide6.QtGui import QPainter, QColor, QPen, QBrush, QRadialGradient, QFont
from PySide6.QtWidgets import QWidget


class StatusVisualizer(QWidget):
    """Futuristic animated circular HUD status indicator."""

    STATE_COLORS = {
        "IDLE": QColor("#00e5ff"),       # Cyan
        "LISTENING": QColor("#0077ff"),  # Electric Blue
        "THINKING": QColor("#a855f7"),   # Neon Purple
        "SPEAKING": QColor("#10b981"),   # Emerald Green
        "EXECUTING": QColor("#f59e0b"),  # Amber Gold
        "ERROR": QColor("#ef4444"),      # Crimson Red
    }

    def __init__(self, parent=None):
        super().__init__(parent)
        self.state = "IDLE"
        self.angle = 0.0
        self.pulse = 0.0
        self.pulse_dir = 1
        self.audio_amplitude = 0.5

        self.setMinimumSize(180, 180)
        self.setMaximumSize(260, 260)

        # 60 FPS animation timer
        self.timer = QTimer(self)
        self.timer.timeout.connect(self._update_animation)
        self.timer.start(16)

    def set_state(self, state: str):
        """Changes visualizer state (IDLE, LISTENING, THINKING, SPEAKING, EXECUTING, ERROR)."""
        new_state = state.upper()
        if new_state in self.STATE_COLORS:
            self.state = new_state
            self.update()

    def set_audio_amplitude(self, amplitude: float):
        """Sets real-time microphone audio amplitude (0.0 to 1.0) for wave expansion."""
        self.audio_amplitude = max(0.0, min(1.0, amplitude))

    def _update_animation(self):
        """Advances rotation and pulse animations."""
        # Rotation speed depends on state
        speed = 1.0
        if self.state == "THINKING":
            speed = 4.0
        elif self.state == "EXECUTING":
            speed = 2.5
        elif self.state in ("LISTENING", "SPEAKING"):
            speed = 1.5

        self.angle = (self.angle + speed) % 360.0

        # Pulse animation
        self.pulse += 0.02 * self.pulse_dir
        if self.pulse >= 1.0:
            self.pulse = 1.0
            self.pulse_dir = -1
        elif self.pulse <= 0.0:
            self.pulse = 0.0
            self.pulse_dir = 1

        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        w = self.width()
        h = self.height()
        cx = w / 2.0
        cy = h / 2.0
        base_radius = min(w, h) * 0.40

        color = self.STATE_COLORS.get(self.state, self.STATE_COLORS["IDLE"])

        # 1. Background Radial Glow
        gradient = QRadialGradient(cx, cy, base_radius * 1.3)
        glow_color = QColor(color)
        glow_color.setAlpha(int(30 + self.pulse * 25))
        gradient.setColorAt(0.0, glow_color)
        gradient.setColorAt(0.8, QColor(color.red(), color.green(), color.blue(), 5))
        gradient.setColorAt(1.0, QColor(0, 0, 0, 0))
        painter.setBrush(QBrush(gradient))
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QRectF(cx - base_radius * 1.3, cy - base_radius * 1.3, base_radius * 2.6, base_radius * 2.6))

        # 2. Outer Rotating Segmented Ring
        outer_pen = QPen(color, 2.0)
        painter.setPen(outer_pen)
        outer_rect = QRectF(cx - base_radius, cy - base_radius, base_radius * 2, base_radius * 2)

        # Draw 4 curved arc sectors
        for i in range(4):
            start_angle = int((self.angle + i * 90 + 10) * 16)
            span_angle = int(70 * 16)
            painter.drawArc(outer_rect, start_angle, span_angle)

        # 3. Inner Counter-Rotating Dashed Tech Ring
        inner_radius = base_radius * 0.75
        inner_rect = QRectF(cx - inner_radius, cy - inner_radius, inner_radius * 2, inner_radius * 2)
        inner_color = QColor(color)
        inner_color.setAlpha(180)
        inner_pen = QPen(inner_color, 1.5, Qt.DashLine)
        painter.setPen(inner_pen)
        painter.drawArc(inner_rect, int(-self.angle * 1.5 * 16), 360 * 16)

        # 4. Center Core Pulse or Waveforms
        if self.state in ("SPEAKING", "LISTENING"):
            # Waveform visualizer bars
            num_bars = 16
            bar_radius = base_radius * 0.45
            for i in range(num_bars):
                rad = math.radians(i * (360 / num_bars) + self.angle)
                wave_height = 8.0 + math.sin(self.angle * 0.1 + i) * 6.0 + (self.audio_amplitude * 12.0)
                x1 = cx + math.cos(rad) * (bar_radius - wave_height)
                y1 = cy + math.sin(rad) * (bar_radius - wave_height)
                x2 = cx + math.cos(rad) * (bar_radius + wave_height)
                y2 = cy + math.sin(rad) * (bar_radius + wave_height)
                bar_pen = QPen(color, 2.0)
                painter.setPen(bar_pen)
                painter.drawLine(QPointF(x1, y1), QPointF(x2, y2))
        else:
            # Pulsing solid center core
            core_radius = base_radius * 0.35 * (0.85 + self.pulse * 0.15)
            core_rect = QRectF(cx - core_radius, cy - core_radius, core_radius * 2, core_radius * 2)
            core_brush_color = QColor(color)
            core_brush_color.setAlpha(int(60 + self.pulse * 60))
            painter.setBrush(QBrush(core_brush_color))
            painter.setPen(QPen(color, 1.5))
            painter.drawEllipse(core_rect)

        # 5. State Text Label in center
        font = QFont("Segoe UI", 8, QFont.Bold)
        painter.setFont(font)
        painter.setPen(QPen(QColor("#f8fafc")))
        painter.drawText(QRectF(cx - 50, cy - 10, 100, 20), Qt.AlignCenter, self.state)
