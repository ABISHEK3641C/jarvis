"""JARVIS Custom UI Components and Widgets."""
from app.ui.widgets.status_visualizer import StatusVisualizer
from app.ui.widgets.system_hud import SystemHudWidget
from app.ui.widgets.chat_view import ChatViewWidget
from app.ui.widgets.history_sidebar import HistorySidebarWidget
from app.ui.widgets.confirmation_dialog import ConfirmationDialog

__all__ = [
    "StatusVisualizer",
    "SystemHudWidget",
    "ChatViewWidget",
    "HistorySidebarWidget",
    "ConfirmationDialog",
]
