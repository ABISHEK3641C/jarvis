"""
Conversation History Sidebar Widget for JARVIS.
Allows searching, switching, and deleting past conversation sessions.
"""

from typing import Optional, List, Dict, Any
from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame,
    QVBoxLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QListWidget,
    QListWidgetItem,
    QLabel,
    QMessageBox,
)
from app.core.conversation import ConversationManager


class HistorySidebarWidget(QFrame):
    """Sidebar listing conversation sessions with search and management actions."""

    session_selected = Signal(str)
    new_session_requested = Signal()

    def __init__(self, conversation_manager: Optional[ConversationManager] = None, parent=None):
        super().__init__(parent)
        self.setObjectName("SidebarFrame")
        self.setFixedWidth(260)
        self.conv_mgr = conversation_manager or ConversationManager()
        self._init_ui()
        self.refresh_sessions()

    def _init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 12, 10, 12)
        layout.setSpacing(10)

        # Header Title & New Chat Button
        top_bar = QHBoxLayout()
        title_lbl = QLabel("CHATS")
        title_lbl.setStyleSheet("color: #00e5ff; font-weight: bold; font-size: 12px; letter-spacing: 1px;")
        top_bar.addWidget(title_lbl)
        top_bar.addStretch()

        self.btn_new = QPushButton("+ New Chat")
        self.btn_new.setStyleSheet("""
            QPushButton {
                background-color: #0e223d;
                border: 1px solid #00e5ff;
                border-radius: 4px;
                color: #00e5ff;
                font-size: 11px;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background-color: #00e5ff;
                color: #080d1a;
            }
        """)
        self.btn_new.clicked.connect(self._on_new_chat)
        top_bar.addWidget(self.btn_new)
        layout.addLayout(top_bar)

        # Search Bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search history...")
        self.search_input.textChanged.connect(self._filter_sessions)
        layout.addWidget(self.search_input)

        # Sessions List Widget
        self.list_widget = QListWidget()
        self.list_widget.itemClicked.connect(self._on_item_clicked)
        layout.addWidget(self.list_widget)

        # Bottom Actions: Delete Session / Clear All
        bottom_bar = QHBoxLayout()
        self.btn_delete = QPushButton("Delete")
        self.btn_delete.setStyleSheet("font-size: 11px; padding: 4px 8px; color: #ef4444;")
        self.btn_delete.clicked.connect(self._on_delete_selected)
        bottom_bar.addWidget(self.btn_delete)

        self.btn_clear_all = QPushButton("Clear All")
        self.btn_clear_all.setStyleSheet("font-size: 11px; padding: 4px 8px; color: #94a3b8;")
        self.btn_clear_all.clicked.connect(self._on_clear_all)
        bottom_bar.addWidget(self.btn_clear_all)

        layout.addLayout(bottom_bar)

    def refresh_sessions(self):
        """Reloads session list from database."""
        self.list_widget.clear()
        sessions = self.conv_mgr.list_all_sessions()
        for s in sessions:
            sess_id = s["session_id"]
            first_q = s.get("first_query") or "New Conversation"
            item_text = f"💬 {first_q[:24]}...\n   {s.get('last_activity', '')[:16]}"
            item = QListWidgetItem(item_text)
            item.setData(Qt.UserRole, sess_id)
            self.list_widget.addItem(item)

    def _filter_sessions(self, text: str):
        """Filters visible session items matching search string."""
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            match = text.lower() in item.text().lower()
            item.setHidden(not match)

    def _on_item_clicked(self, item: QListWidgetItem):
        sess_id = item.data(Qt.UserRole)
        if sess_id:
            self.session_selected.emit(sess_id)

    def _on_new_chat(self):
        self.new_session_requested.emit()

    def _on_delete_selected(self):
        current_item = self.list_widget.currentItem()
        if not current_item:
            return
        sess_id = current_item.data(Qt.UserRole)
        if sess_id:
            self.conv_mgr.delete_session(sess_id)
            self.refresh_sessions()
            self.new_session_requested.emit()

    def _on_clear_all(self):
        confirm = QMessageBox.question(
            self,
            "Clear All History",
            "Are you sure you want to delete all past conversation history?",
            QMessageBox.Yes | QMessageBox.No
        )
        if confirm == QMessageBox.Yes:
            self.conv_mgr.clear_all_history()
            self.refresh_sessions()
            self.new_session_requested.emit()
