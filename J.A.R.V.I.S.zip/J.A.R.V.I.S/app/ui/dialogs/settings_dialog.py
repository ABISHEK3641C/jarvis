"""
Multi-Tab Settings and Configuration Dialog for JARVIS.
Allows real-time customization of AI models, Voice parameters, Web/Weather, Memories, Custom Apps, and Diagnostics.
"""

from typing import Optional
from pathlib import Path
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QDialog,
    QVBoxLayout,
    QHBoxLayout,
    QTabWidget,
    QWidget,
    QLabel,
    QLineEdit,
    QPushButton,
    QComboBox,
    QSlider,
    QCheckBox,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QTextEdit,
    QMessageBox,
    QFileDialog,
)
from app.config import Config, LOG_FILE_PATH
from app.core.database import Database
from app.core.memory import MemoryManager
from app.core.ai_engine import AIEngine
from app.voice.text_to_speech import TTSEngine
from app.voice.audio_utils import get_microphone_devices


class SettingsDialog(QDialog):
    """Configuration and management modal dialog."""

    def __init__(
        self,
        ai_engine: Optional[AIEngine] = None,
        tts_engine: Optional[TTSEngine] = None,
        memory_manager: Optional[MemoryManager] = None,
        parent=None,
    ):
        super().__init__(parent)
        self.ai_engine = ai_engine or AIEngine()
        self.tts_engine = tts_engine or TTSEngine()
        self.memory_manager = memory_manager or MemoryManager()
        self.db = Database()

        self.setWindowTitle("JARVIS Assistant - Settings & Configuration")
        self.resize(780, 580)
        self.setModal(True)
        self._init_ui()
        self._load_saved_settings()

    def _init_ui(self):
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(16, 16, 16, 16)
        main_layout.setSpacing(12)

        # Tabs container
        self.tabs = QTabWidget()
        self.tab_ai = QWidget()
        self.tab_voice = QWidget()
        self.tab_web = QWidget()
        self.tab_memory = QWidget()
        self.tab_apps = QWidget()
        self.tab_logs = QWidget()

        self.tabs.addTab(self.tab_ai, "🧠 AI Brain")
        self.tabs.addTab(self.tab_voice, "🎙️ Voice & Audio")
        self.tabs.addTab(self.tab_web, "🌐 Web & Weather")
        self.tabs.addTab(self.tab_memory, "💾 Memory")
        self.tabs.addTab(self.tab_apps, "🛡️ Security & Apps")
        self.tabs.addTab(self.tab_logs, "📜 Logs")

        self._setup_ai_tab()
        self._setup_voice_tab()
        self._setup_web_tab()
        self._setup_memory_tab()
        self._setup_apps_tab()
        self._setup_logs_tab()

        main_layout.addWidget(self.tabs)

        # Bottom Action Bar
        bottom_bar = QHBoxLayout()
        bottom_bar.addStretch()

        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        bottom_bar.addWidget(self.btn_cancel)

        self.btn_save = QPushButton("Save Settings")
        self.btn_save.setObjectName("PrimaryButton")
        self.btn_save.clicked.connect(self._save_settings)
        bottom_bar.addWidget(self.btn_save)

        main_layout.addLayout(bottom_bar)

    # --- TAB 1: AI Brain ---
    def _setup_ai_tab(self):
        layout = QVBoxLayout(self.tab_ai)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        # Provider Selection
        layout.addWidget(QLabel("<b>Primary AI Provider:</b>"))
        self.combo_provider = QComboBox()
        self.combo_provider.addItems(["ollama (Local LLM)", "openai (Cloud API / Compatible)"])
        layout.addWidget(self.combo_provider)

        # Ollama Section
        layout.addWidget(QLabel("<b>Ollama Base URL:</b>"))
        self.txt_ollama_url = QLineEdit(self.ai_engine.ollama_url)
        layout.addWidget(self.txt_ollama_url)

        model_bar = QHBoxLayout()
        self.combo_ollama_model = QComboBox()
        self.combo_ollama_model.setEditable(True)
        self.btn_refresh_models = QPushButton("Detect Installed Models")
        self.btn_refresh_models.clicked.connect(self._refresh_ollama_models)
        model_bar.addWidget(self.combo_ollama_model, 2)
        model_bar.addWidget(self.btn_refresh_models, 1)
        layout.addWidget(QLabel("<b>Ollama Model:</b>"))
        layout.addLayout(model_bar)

        # OpenAI Section
        layout.addWidget(QLabel("<b>OpenAI API Key (Optional):</b>"))
        self.txt_openai_key = QLineEdit()
        self.txt_openai_key.setEchoMode(QLineEdit.Password)
        self.txt_openai_key.setPlaceholderText("sk-...")
        layout.addWidget(self.txt_openai_key)

        layout.addWidget(QLabel("<b>OpenAI Model:</b>"))
        self.txt_openai_model = QLineEdit(self.ai_engine.openai_model)
        layout.addWidget(self.txt_openai_model)

        # Temperature
        layout.addWidget(QLabel("<b>Temperature (Creativity):</b>"))
        self.slider_temp = QSlider(Qt.Horizontal)
        self.slider_temp.setRange(0, 100)
        self.slider_temp.setValue(int(self.ai_engine.temperature * 100))
        self.lbl_temp_val = QLabel(f"{self.ai_engine.temperature:.2f}")
        self.slider_temp.valueChanged.connect(lambda v: self.lbl_temp_val.setText(f"{v/100:.2f}"))
        temp_box = QHBoxLayout()
        temp_box.addWidget(self.slider_temp)
        temp_box.addWidget(self.lbl_temp_val)
        layout.addLayout(temp_box)

        layout.addStretch()

    def _refresh_ollama_models(self):
        """Refreshes installed Ollama models into dropdown."""
        self.ai_engine.ollama_url = self.txt_ollama_url.text().strip()
        models = self.ai_engine.get_available_ollama_models()
        self.combo_ollama_model.clear()
        if models:
            self.combo_ollama_model.addItems(models)
            QMessageBox.information(self, "Ollama Models", f"Detected {len(models)} installed model(s): {', '.join(models)}")
        else:
            self.combo_ollama_model.addItem("llama3.2")
            QMessageBox.warning(self, "Ollama Offline", f"Could not reach Ollama at {self.ai_engine.ollama_url}.\nPlease ensure Ollama is running.")

    # --- TAB 2: Voice & Audio ---
    def _setup_voice_tab(self):
        layout = QVBoxLayout(self.tab_voice)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        self.chk_voice_enabled = QCheckBox("Enable Voice & Speech Synthesis")
        self.chk_voice_enabled.setChecked(Config.VOICE_ENABLED)
        layout.addWidget(self.chk_voice_enabled)

        # Microphone selection
        layout.addWidget(QLabel("<b>Input Microphone Device:</b>"))
        self.combo_mics = QComboBox()
        devices = get_microphone_devices()
        default_select_idx = 0
        saved_mic_idx = self.db.get_setting("mic_device_index", default=None)

        for item_pos, d in enumerate(devices):
            self.combo_mics.addItem(d["name"], d["index"])
            if saved_mic_idx is not None and d["index"] == saved_mic_idx:
                default_select_idx = item_pos
            elif saved_mic_idx is None and d.get("is_default"):
                default_select_idx = item_pos

        self.combo_mics.setCurrentIndex(default_select_idx)
        layout.addWidget(self.combo_mics)

        # Mic Test Bar
        mic_test_box = QHBoxLayout()
        self.btn_test_mic = QPushButton("🎙️ Test Microphone (Speak now)")
        self.btn_test_mic.clicked.connect(self._test_microphone_input)
        self.lbl_mic_test_result = QLabel("Status: Ready to test")
        self.lbl_mic_test_result.setStyleSheet("color: #94a3b8; font-size: 11px;")
        mic_test_box.addWidget(self.btn_test_mic)
        mic_test_box.addWidget(self.lbl_mic_test_result, 1)
        layout.addLayout(mic_test_box)

        # Voice Selector
        layout.addWidget(QLabel("<b>TTS Voice:</b>"))
        self.combo_voices = QComboBox()
        voices = self.tts_engine.get_available_voices()
        for v in voices:
            self.combo_voices.addItem(f"{v['name']} ({v['gender']})", v["index"])
        layout.addWidget(self.combo_voices)

        # Speech Rate
        layout.addWidget(QLabel("<b>Speech Rate (Words Per Minute):</b>"))
        self.slider_rate = QSlider(Qt.Horizontal)
        self.slider_rate.setRange(100, 300)
        self.slider_rate.setValue(self.tts_engine.rate)
        self.lbl_rate_val = QLabel(f"{self.tts_engine.rate} wpm")
        self.slider_rate.valueChanged.connect(lambda v: self.lbl_rate_val.setText(f"{v} wpm"))
        rate_box = QHBoxLayout()
        rate_box.addWidget(self.slider_rate)
        rate_box.addWidget(self.lbl_rate_val)
        layout.addLayout(rate_box)

        # Speech Volume
        layout.addWidget(QLabel("<b>Speech Volume:</b>"))
        self.slider_vol = QSlider(Qt.Horizontal)
        self.slider_vol.setRange(0, 100)
        self.slider_vol.setValue(int(self.tts_engine.volume * 100))
        self.lbl_vol_val = QLabel(f"{int(self.tts_engine.volume * 100)}%")
        self.slider_vol.valueChanged.connect(lambda v: self.lbl_vol_val.setText(f"{v}%"))
        vol_box = QHBoxLayout()
        vol_box.addWidget(self.slider_vol)
        vol_box.addWidget(self.lbl_vol_val)
        layout.addLayout(vol_box)

        # Test Voice Button
        self.btn_test_tts = QPushButton("🔊 Test Voice Output")
        self.btn_test_tts.clicked.connect(self._test_voice)
        layout.addWidget(self.btn_test_tts)

        # Wake Word
        layout.addWidget(QLabel("<b>Wake Word Phrase:</b>"))
        self.txt_wake_word = QLineEdit(Config.WAKE_WORD)
        layout.addWidget(self.txt_wake_word)

        layout.addStretch()

    def _test_microphone_input(self):
        """Quick 4-second microphone test on chosen device."""
        mic_idx = self.combo_mics.currentData()
        self.lbl_mic_test_result.setText("🔴 Listening... Speak a word (e.g. 'Hello')")
        self.lbl_mic_test_result.setStyleSheet("color: #00e5ff; font-weight: bold;")
        self.btn_test_mic.setEnabled(False)
        QApplication.processEvents()

        import speech_recognition as sr
        try:
            recognizer = sr.Recognizer()
            recognizer.energy_threshold = 200
            recognizer.dynamic_energy_threshold = True

            kwargs = {"device_index": mic_idx} if mic_idx is not None else {}
            with sr.Microphone(**kwargs) as source:
                recognizer.adjust_for_ambient_noise(source, duration=0.5)
                audio = recognizer.listen(source, timeout=4.0, phrase_time_limit=4.0)

            text = recognizer.recognize_google(audio)
            self.lbl_mic_test_result.setText(f"✅ Recognized: '{text}'")
            self.lbl_mic_test_result.setStyleSheet("color: #10b981; font-weight: bold;")
        except sr.WaitTimeoutError:
            self.lbl_mic_test_result.setText("⚠️ Timed out (No voice heard). Try another mic index.")
            self.lbl_mic_test_result.setStyleSheet("color: #ffab00;")
        except sr.UnknownValueError:
            self.lbl_mic_test_result.setText("⚠️ Voice detected but audio unclear.")
            self.lbl_mic_test_result.setStyleSheet("color: #ffab00;")
        except Exception as e:
            self.lbl_mic_test_result.setText(f"❌ Error: {e}")
            self.lbl_mic_test_result.setStyleSheet("color: #ef4444;")
        finally:
            self.btn_test_mic.setEnabled(True)

    def _test_voice(self):
        self.tts_engine.rate = self.slider_rate.value()
        self.tts_engine.volume = self.slider_vol.value() / 100.0
        v_idx = self.combo_voices.currentData()
        if v_idx is not None:
            self.tts_engine.voice_index = v_idx
        self.tts_engine.speak("JARVIS voice synthesis test. All systems operational, sir.", priority=True)

    # --- TAB 3: Web & Weather ---
    def _setup_web_tab(self):
        layout = QVBoxLayout(self.tab_web)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(12)

        layout.addWidget(QLabel("<b>Default Weather City / Location:</b>"))
        self.txt_weather_loc = QLineEdit(Config.DEFAULT_LOCATION)
        layout.addWidget(self.txt_weather_loc)

        layout.addWidget(QLabel("<b>OpenWeatherMap API Key (Optional fallback):</b>"))
        self.txt_weather_key = QLineEdit(Config.OPENWEATHER_API_KEY)
        self.txt_weather_key.setEchoMode(QLineEdit.Password)
        layout.addWidget(self.txt_weather_key)

        layout.addWidget(QLabel("<b>Web Search Provider:</b>"))
        self.combo_search_provider = QComboBox()
        self.combo_search_provider.addItems(["DuckDuckGo (Free & Live)", "Google Fallback"])
        layout.addWidget(self.combo_search_provider)

        layout.addStretch()

    # --- TAB 4: Memory Manager ---
    def _setup_memory_tab(self):
        layout = QVBoxLayout(self.tab_memory)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Memory Table
        self.mem_table = QTableWidget()
        self.mem_table.setColumnCount(4)
        self.mem_table.setHorizontalHeaderLabels(["ID", "Category", "Key Fact / Topic", "Content / Fact"])
        self.mem_table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.mem_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.mem_table)

        # Action Buttons
        act_bar = QHBoxLayout()
        self.btn_refresh_mem = QPushButton("Refresh")
        self.btn_refresh_mem.clicked.connect(self._load_memories_table)
        act_bar.addWidget(self.btn_refresh_mem)

        self.btn_del_mem = QPushButton("Delete Selected")
        self.btn_del_mem.clicked.connect(self._delete_selected_memory)
        act_bar.addWidget(self.btn_del_mem)

        self.btn_wipe_mem = QPushButton("Clear All Memories")
        self.btn_wipe_mem.setStyleSheet("color: #ef4444;")
        self.btn_wipe_mem.clicked.connect(self._clear_all_memories)
        act_bar.addWidget(self.btn_wipe_mem)

        layout.addLayout(act_bar)

    def _load_memories_table(self):
        self.mem_table.setRowCount(0)
        mems = self.memory_manager.list_memories()
        self.mem_table.setRowCount(len(mems))
        for row_idx, m in enumerate(mems):
            self.mem_table.setItem(row_idx, 0, QTableWidgetItem(str(m["id"])))
            self.mem_table.setItem(row_idx, 1, QTableWidgetItem(m["category"]))
            self.mem_table.setItem(row_idx, 2, QTableWidgetItem(m["key_fact"]))
            self.mem_table.setItem(row_idx, 3, QTableWidgetItem(m["content"]))

    def _delete_selected_memory(self):
        row = self.mem_table.currentRow()
        if row < 0:
            return
        mem_id = self.mem_table.item(row, 0).text()
        self.memory_manager.forget(mem_id)
        self._load_memories_table()

    def _clear_all_memories(self):
        confirm = QMessageBox.question(self, "Clear Memories", "Delete all stored long-term memories?", QMessageBox.Yes | QMessageBox.No)
        if confirm == QMessageBox.Yes:
            self.memory_manager.clear_all()
            self._load_memories_table()

    # --- TAB 5: Security & Apps ---
    def _setup_apps_tab(self):
        layout = QVBoxLayout(self.tab_apps)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        layout.addWidget(QLabel("<b>Registered Custom Application Paths:</b>"))
        self.apps_table = QTableWidget()
        self.apps_table.setColumnCount(2)
        self.apps_table.setHorizontalHeaderLabels(["Application Name", "Executable / Shortcut Path"])
        self.apps_table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.apps_table)

        # Add custom app bar
        add_bar = QHBoxLayout()
        self.txt_app_name = QLineEdit()
        self.txt_app_name.setPlaceholderText("App Name (e.g. Photoshop)")
        self.txt_app_path = QLineEdit()
        self.txt_app_path.setPlaceholderText("Executable Path")
        self.btn_browse_app = QPushButton("Browse...")
        self.btn_browse_app.clicked.connect(self._browse_app_path)
        self.btn_add_app = QPushButton("+ Add App")
        self.btn_add_app.clicked.connect(self._add_custom_app)

        add_bar.addWidget(self.txt_app_name, 1)
        add_bar.addWidget(self.txt_app_path, 2)
        add_bar.addWidget(self.btn_browse_app)
        add_bar.addWidget(self.btn_add_app)
        layout.addLayout(add_bar)

        # Security Confirmation settings
        layout.addWidget(QLabel("<b>Safety Safeguards:</b>"))
        self.chk_confirm_delete = QCheckBox("Require confirmation before deleting files or directories")
        self.chk_confirm_delete.setChecked(Config.REQUIRE_CONFIRMATION_DELETION)
        layout.addWidget(self.chk_confirm_delete)

        self.chk_confirm_shutdown = QCheckBox("Require confirmation before computer shutdown or restart")
        self.chk_confirm_shutdown.setChecked(Config.REQUIRE_CONFIRMATION_SHUTDOWN)
        layout.addWidget(self.chk_confirm_shutdown)

        layout.addStretch()

    def _browse_app_path(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select Application Executable", "", "Executables (*.exe *.cmd *.bat *.lnk)")
        if file_path:
            self.txt_app_path.setText(file_path)
            if not self.txt_app_name.text():
                self.txt_app_name.setText(Path(file_path).stem)

    def _add_custom_app(self):
        name = self.txt_app_name.text().strip()
        path = self.txt_app_path.text().strip()
        if name and path:
            self.db.add_custom_app(name, path)
            self.txt_app_name.clear()
            self.txt_app_path.clear()
            self._load_apps_table()

    def _load_apps_table(self):
        self.apps_table.setRowCount(0)
        apps = self.db.list_custom_apps()
        self.apps_table.setRowCount(len(apps))
        for row_idx, app in enumerate(apps):
            self.apps_table.setItem(row_idx, 0, QTableWidgetItem(app["name"]))
            self.apps_table.setItem(row_idx, 1, QTableWidgetItem(app["path"]))

    # --- TAB 6: Logs ---
    def _setup_logs_tab(self):
        layout = QVBoxLayout(self.tab_logs)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setStyleSheet("background-color: #060b14; color: #a5f3fc; font-family: Consolas, monospace; font-size: 11px;")
        layout.addWidget(self.txt_logs)

        log_actions = QHBoxLayout()
        self.btn_refresh_log = QPushButton("Refresh Logs")
        self.btn_refresh_log.clicked.connect(self._load_logs)
        log_actions.addWidget(self.btn_refresh_log)

        self.btn_clear_log = QPushButton("Clear Log File")
        self.btn_clear_log.clicked.connect(self._clear_logs)
        log_actions.addWidget(self.btn_clear_log)
        layout.addLayout(log_actions)

    def _load_logs(self):
        try:
            log_p = Path(LOG_FILE_PATH)
            if log_p.exists():
                lines = log_p.read_text(encoding="utf-8", errors="replace").splitlines()
                self.txt_logs.setPlainText("\n".join(lines[-200:]))
            else:
                self.txt_logs.setPlainText("Log file does not exist yet.")
        except Exception as e:
            self.txt_logs.setPlainText(f"Error loading logs: {e}")

    def _clear_logs(self):
        try:
            log_p = Path(LOG_FILE_PATH)
            if log_p.exists():
                log_p.write_text("", encoding="utf-8")
                self._load_logs()
        except Exception as e:
            QMessageBox.warning(self, "Log Error", str(e))

    def _load_saved_settings(self):
        """Loads and applies all persisted settings into the UI controls."""
        settings = self.db.get_all_settings()

        # AI
        prov = settings.get("ai_provider", self.ai_engine.provider)
        self.combo_provider.setCurrentIndex(0 if prov == "ollama" else 1)
        self.txt_ollama_url.setText(settings.get("ollama_url", self.ai_engine.ollama_url))
        self.combo_ollama_model.setCurrentText(settings.get("ollama_model", self.ai_engine.ollama_model))
        self.txt_openai_key.setText(settings.get("openai_key", self.ai_engine.openai_api_key))
        self.txt_openai_model.setText(settings.get("openai_model", self.ai_engine.openai_model))

        # Memory & Apps tables
        self._load_memories_table()
        self._load_apps_table()
        self._load_logs()

    def _save_settings(self):
        """Saves configured settings into Database and updates active engine instances."""
        provider = "ollama" if self.combo_provider.currentIndex() == 0 else "openai"
        ollama_url = self.txt_ollama_url.text().strip()
        ollama_model = self.combo_ollama_model.currentText().strip() or "llama3.2"
        openai_key = self.txt_openai_key.text().strip()
        openai_model = self.txt_openai_model.text().strip() or "gpt-4o-mini"
        temp = self.slider_temp.value() / 100.0

        # Save to Database
        self.db.set_setting("ai_provider", provider)
        self.db.set_setting("ollama_url", ollama_url)
        self.db.set_setting("ollama_model", ollama_model)
        self.db.set_setting("openai_key", openai_key)
        self.db.set_setting("openai_model", openai_model)
        self.db.set_setting("temperature", temp)

        selected_mic_idx = self.combo_mics.currentData()
        self.db.set_setting("mic_device_index", selected_mic_idx)

        # Update Live Engines
        self.ai_engine.provider = provider
        self.ai_engine.ollama_url = ollama_url
        self.ai_engine.ollama_model = ollama_model
        self.ai_engine.openai_api_key = openai_key
        self.ai_engine.openai_model = openai_model
        self.ai_engine.temperature = temp

        self.tts_engine.rate = self.slider_rate.value()
        self.tts_engine.volume = self.slider_vol.value() / 100.0
        v_idx = self.combo_voices.currentData()
        if v_idx is not None:
            self.tts_engine.voice_index = v_idx

        Config.DEFAULT_LOCATION = self.txt_weather_loc.text().strip()
        Config.WAKE_WORD = self.txt_wake_word.text().strip().lower()

        QMessageBox.information(self, "Saved", "Settings saved and applied successfully!")
        self.accept()
