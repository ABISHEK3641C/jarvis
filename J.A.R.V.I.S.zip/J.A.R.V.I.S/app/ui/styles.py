"""
Modern Cyberpunk / HUD Styling and Theme for JARVIS Desktop Application.
Color Palette:
- Primary Background: #080d1a
- Surface / Card Background: #0d1527
- Accent Cyan / Neon Glow: #00e5ff
- Accent Blue: #0077ff
- Text Primary: #e0f2fe
- Text Secondary: #7dd3fc
- Danger / Alert: #ff3366
- Success / Safe: #00e676
- Warning / Executing: #ffab00
"""

MAIN_STYLESHEET = """
QMainWindow {
    background-color: #080d1a;
    color: #e0f2fe;
    font-family: 'Segoe UI', 'Segoe UI Variable', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
}

QWidget#CentralWidget {
    background-color: #080d1a;
}

/* Scrollbars */
QScrollBar:vertical {
    border: none;
    background: #0d1527;
    width: 8px;
    margin: 0px 0px 0px 0px;
    border-radius: 4px;
}
QScrollBar::handle:vertical {
    background: #1e293b;
    min-height: 25px;
    border-radius: 4px;
}
QScrollBar::handle:vertical:hover {
    background: #00e5ff;
}
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* Header & HUD */
QFrame#HudBar {
    background-color: #0c1424;
    border: 1px solid #1a2a47;
    border-radius: 8px;
}

QLabel.HudTitle {
    color: #64748b;
    font-size: 10px;
    font-weight: bold;
    text-transform: uppercase;
}

QLabel.HudValue {
    color: #00e5ff;
    font-size: 12px;
    font-weight: bold;
}

/* Text Input & Buttons */
QLineEdit {
    background-color: #0d1527;
    border: 1px solid #1e293b;
    border-radius: 8px;
    padding: 10px 14px;
    color: #f0f9ff;
    font-size: 14px;
    selection-background-color: #00e5ff;
    selection-color: #080d1a;
}
QLineEdit:focus {
    border: 1px solid #00e5ff;
    background-color: #0e1930;
}

QPushButton {
    background-color: #0d1a33;
    border: 1px solid #1e3a5f;
    border-radius: 8px;
    color: #e0f2fe;
    padding: 8px 16px;
    font-size: 13px;
    font-weight: 600;
}
QPushButton:hover {
    background-color: #13274d;
    border: 1px solid #00e5ff;
    color: #00e5ff;
}
QPushButton:pressed {
    background-color: #00e5ff;
    color: #080d1a;
}
QPushButton:disabled {
    background-color: #090e1a;
    border: 1px solid #152238;
    color: #475569;
}

/* Primary Action / Send Button */
QPushButton#PrimaryButton {
    background-color: #00e5ff;
    color: #080d1a;
    border: none;
    font-weight: bold;
}
QPushButton#PrimaryButton:hover {
    background-color: #38bdf8;
    color: #080d1a;
}

/* Mic / Voice Button */
QPushButton#VoiceButton {
    background-color: #0f1d38;
    border: 2px solid #00e5ff;
    border-radius: 24px;
    min-width: 48px;
    max-width: 48px;
    min-height: 48px;
    max-height: 48px;
    font-size: 18px;
}
QPushButton#VoiceButton:hover {
    background-color: #1a3360;
}
QPushButton#VoiceButton[listening="true"] {
    background-color: #ff3366;
    border: 2px solid #ff6699;
}

/* Chat Messages */
QScrollArea {
    border: none;
    background-color: transparent;
}
QWidget#ChatContentArea {
    background-color: transparent;
}

QFrame.UserBubble {
    background-color: #0e2444;
    border: 1px solid #1d4ed8;
    border-radius: 12px;
    border-top-right-radius: 2px;
    padding: 12px 16px;
}

QFrame.AssistantBubble {
    background-color: #0c1424;
    border: 1px solid #1a2a47;
    border-radius: 12px;
    border-top-left-radius: 2px;
    padding: 12px 16px;
}

QFrame.ToolCard {
    background-color: #060b14;
    border: 1px dashed #0284c7;
    border-radius: 6px;
    padding: 6px 10px;
    margin-top: 4px;
    margin-bottom: 4px;
}

/* History Sidebar */
QFrame#SidebarFrame {
    background-color: #060a14;
    border-right: 1px solid #132238;
}

QListWidget {
    background-color: transparent;
    border: none;
    color: #94a3b8;
}
QListWidget::item {
    padding: 10px 12px;
    border-radius: 6px;
    margin-bottom: 4px;
}
QListWidget::item:hover {
    background-color: #0d192f;
    color: #38bdf8;
}
QListWidget::item:selected {
    background-color: #102447;
    color: #00e5ff;
    font-weight: bold;
}

/* Dialogs & Tabs */
QDialog {
    background-color: #080d1a;
    color: #e0f2fe;
}

QTabWidget::pane {
    border: 1px solid #1a2a47;
    background-color: #0a1122;
    border-radius: 6px;
}
QTabBar::tab {
    background: #080d1a;
    color: #64748b;
    padding: 10px 18px;
    font-weight: 600;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
}
QTabBar::tab:selected {
    background: #0a1122;
    color: #00e5ff;
    border-bottom: 2px solid #00e5ff;
}

QTableWidget {
    background-color: #080d1a;
    border: 1px solid #1a2a47;
    gridline-color: #132238;
    color: #e0f2fe;
    selection-background-color: #00e5ff;
    selection-color: #080d1a;
}
QHeaderView::section {
    background-color: #0c1424;
    color: #38bdf8;
    padding: 6px;
    border: 1px solid #132238;
    font-weight: bold;
}

QComboBox {
    background-color: #0d1527;
    border: 1px solid #1e293b;
    border-radius: 6px;
    padding: 6px 12px;
    color: #f0f9ff;
}
QComboBox QAbstractItemView {
    background-color: #0d1527;
    color: #f0f9ff;
    selection-background-color: #00e5ff;
    selection-color: #080d1a;
}
"""
