"""
Main HUD Window for JARVIS Desktop Assistant.
Pure Voice-Focused Futuristic Command Center with:
 - Continuous hands-free listening loop (no button needed)
 - Live face recognition & emotion detection panel
 - Caring/empathetic AI responses based on detected emotions
 - Real-time speech subtitles and animated holographic core
"""

import random
import time
from typing import Optional
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLineEdit, QPushButton, QLabel, QFrame, QApplication,
)
from app.config import Config
from app.core.database import Database
from app.core.memory import MemoryManager
from app.core.conversation import ConversationManager
from app.core.security import SecurityManager
from app.core.tool_manager import ToolManager
from app.core.ai_engine import AIEngine
from app.tools import register_all_tools
from app.voice.text_to_speech import TTSEngine
from app.voice.speech_to_text import STTEngine
from app.tools.screenshot import take_screenshot
from app.utils.system_info import SystemMonitorWorker
from app.ui.styles import MAIN_STYLESHEET
from app.ui.widgets.status_visualizer import StatusVisualizer
from app.ui.widgets.system_hud import SystemHudWidget
from app.ui.widgets.confirmation_dialog import ConfirmationDialog
from app.ui.widgets.vision_panel import VisionPanelWidget
from app.ui.dialogs.settings_dialog import SettingsDialog
from app.utils.logger import get_logger
from app.tools.face_emotion import EMOTION_RESPONSES

logger = get_logger("MainWindow")


class AIQueryWorker(QThread):
    """Background QThread for executing AI inference and tool calling cycles."""
    status_changed = Signal(str)
    tool_executed = Signal(str, dict)
    query_finished = Signal(dict)
    query_failed = Signal(str)

    def __init__(self, ai_engine: AIEngine, prompt: str, parent=None):
        super().__init__(parent)
        self.ai_engine = ai_engine
        self.prompt = prompt

    def run(self):
        try:
            result = self.ai_engine.process_query(
                user_prompt=self.prompt,
                on_status_change=lambda s: self.status_changed.emit(s),
                on_tool_execute=lambda n, a: self.tool_executed.emit(n, a),
            )
            self.query_finished.emit(result)
        except Exception as e:
            logger.error(f"Error in AIQueryWorker: {e}", exc_info=True)
            self.query_failed.emit(str(e))


class ContinuousListeningWorker(QThread):
    """Background QThread running continuous hands-free voice recognition loop."""
    speech_detected = Signal(str)
    status_changed = Signal(str)

    def __init__(self, stt_engine: STTEngine, tts_engine: TTSEngine, parent=None):
        super().__init__(parent)
        self.stt_engine = stt_engine
        self.tts_engine = tts_engine
        self._is_active = True
        self._is_paused = False

    def pause_listening(self):
        self._is_paused = True

    def resume_listening(self):
        self._is_paused = False

    def stop(self):
        self._is_active = False

    def run(self):
        # Initial calibration once on startup
        self.stt_engine.calibrate_ambient_noise(duration_sec=0.6)

        while self._is_active:
            if self._is_paused or self.tts_engine.is_speaking:
                time.sleep(0.3)
                continue
            try:
                self.status_changed.emit("LISTENING")
                text = self.stt_engine.listen_one_shot(timeout=4.0, phrase_time_limit=10.0)
                if text and text.strip() and not self._is_paused and not self.tts_engine.is_speaking:
                    logger.info(f"Voice captured: '{text}'")
                    self.speech_detected.emit(text.strip())
                    time.sleep(0.8)
                else:
                    if not self.tts_engine.is_speaking:
                        self.status_changed.emit("IDLE")
            except Exception as e:
                logger.debug(f"Continuous listen loop: {e}")
                time.sleep(0.5)


class JarvisMainWindow(QMainWindow):
    """Primary Voice-Driven JARVIS HUD Application Window."""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("J.A.R.V.I.S — Autonomous AI Desktop Assistant")
        self.resize(1280, 700)
        self.setMinimumSize(960, 600)
        self.setStyleSheet(MAIN_STYLESHEET)

        # Core Subsystems
        self.db = Database()
        self.memory_mgr = MemoryManager(self.db)
        self.conv_mgr = ConversationManager(self.db)
        self.security_mgr = SecurityManager(confirmation_callback=self._handle_security_confirmation)
        self.tool_mgr = ToolManager(self.security_mgr)
        register_all_tools(self.tool_mgr, self.memory_mgr)
        self.tool_mgr.load_plugins_from_directory()

        saved_mic = self.db.get_setting("mic_device_index", default=2)
        self.ai_engine = AIEngine(self.tool_mgr, self.memory_mgr, self.conv_mgr)
        self.tts_engine = TTSEngine()
        self.stt_engine = STTEngine(device_index=saved_mic)

        self.tts_engine.set_callbacks(
            on_start=self._on_tts_start,
            on_finish=self._on_tts_finish,
        )

        self._active_ai_worker: Optional[AIQueryWorker] = None
        self._auto_listening_enabled = True
        self._last_emotion_response_time: float = 0.0

        self._init_ui()
        self._init_background_monitors()

        QTimer.singleShot(700, self._start_continuous_voice_loop)
        QTimer.singleShot(500, self._speak_welcome)

    # ------------------------------------------------------------------
    # UI Setup
    # ------------------------------------------------------------------
    def _init_ui(self):
        central = QWidget()
        central.setObjectName("CentralWidget")
        self.setCentralWidget(central)

        root = QHBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        # ── Left: Vision Panel ──────────────────────────────────────────
        self.vision_panel = VisionPanelWidget()
        self.vision_panel.emotion_changed.connect(self._on_emotion_detected)
        root.addWidget(self.vision_panel)

        # ── Right: Main HUD ─────────────────────────────────────────────
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(18, 14, 18, 14)
        right_layout.setSpacing(12)
        root.addWidget(right_panel, 1)

        # ── Top Bar ──────────────────────────────────────────────────────
        top_bar = QHBoxLayout()
        top_bar.setSpacing(10)

        logo_lbl = QLabel("◈ J.A.R.V.I.S ◈")
        logo_lbl.setStyleSheet("color: #00e5ff; font-weight: bold; font-size: 18px; letter-spacing: 3px;")
        top_bar.addWidget(logo_lbl)

        sub_lbl = QLabel("— Hands-Free AI Voice Assistant")
        sub_lbl.setStyleSheet("color: #64748b; font-size: 13px;")
        top_bar.addWidget(sub_lbl)
        top_bar.addStretch()

        self.btn_toggle_listen = QPushButton("🎙️ Auto-Listen: ON")
        self.btn_toggle_listen.setStyleSheet(
            "background-color: #064e3b; border: 1px solid #10b981; color: #34d399; font-weight: bold; padding: 4px 10px; border-radius: 5px;"
        )
        self.btn_toggle_listen.clicked.connect(self._toggle_auto_listening)
        top_bar.addWidget(self.btn_toggle_listen)

        self.btn_screenshot = QPushButton("📸 Screen")
        self.btn_screenshot.clicked.connect(self._on_quick_screenshot)
        top_bar.addWidget(self.btn_screenshot)

        self.btn_settings = QPushButton("⚙️ Settings")
        self.btn_settings.clicked.connect(self._open_settings)
        top_bar.addWidget(self.btn_settings)

        right_layout.addLayout(top_bar)

        # ── Telemetry HUD ─────────────────────────────────────────────
        self.hud_bar = SystemHudWidget()
        self.hud_bar.set_active_model_name(self.ai_engine.ollama_model, self.ai_engine.provider)
        right_layout.addWidget(self.hud_bar)

        # ── Center Display Card ───────────────────────────────────────
        center_frame = QFrame()
        center_frame.setStyleSheet(
            "background-color: #0b1324; border: 1px solid #1a2a47; border-radius: 12px;"
        )
        center_layout = QVBoxLayout(center_frame)
        center_layout.setContentsMargins(20, 16, 20, 16)
        center_layout.setSpacing(14)

        # Holographic Visualizer
        vis_box = QHBoxLayout()
        vis_box.addStretch()
        self.status_visualizer = StatusVisualizer()
        vis_box.addWidget(self.status_visualizer)
        vis_box.addStretch()
        center_layout.addLayout(vis_box)

        # Speech subtitle cards
        subtitles_box = QVBoxLayout()
        subtitles_box.setSpacing(8)

        # YOU SPOKE card
        user_card = QFrame()
        user_card.setStyleSheet(
            "background-color: #060e1d; border: 1px solid #1e3a5f; border-radius: 8px;"
        )
        user_layout = QHBoxLayout(user_card)
        user_layout.setContentsMargins(10, 6, 10, 6)
        user_title = QLabel("👤 YOU:")
        user_title.setStyleSheet("color: #38bdf8; font-size: 11px; font-weight: bold;")
        user_title.setFixedWidth(90)
        self.lbl_user_spoken = QLabel("Speak directly — I'm always listening, sir.")
        self.lbl_user_spoken.setStyleSheet("color: #f1f5f9; font-size: 13px;")
        self.lbl_user_spoken.setWordWrap(True)
        user_layout.addWidget(user_title)
        user_layout.addWidget(self.lbl_user_spoken, 1)
        subtitles_box.addWidget(user_card)

        # JARVIS Response card
        jarvis_card = QFrame()
        jarvis_card.setStyleSheet(
            "background-color: #060e1d; border: 1px solid #00e5ff; border-radius: 8px;"
        )
        jarvis_layout = QHBoxLayout(jarvis_card)
        jarvis_layout.setContentsMargins(10, 6, 10, 6)
        jarvis_title = QLabel("🤖 JARVIS:")
        jarvis_title.setStyleSheet("color: #00e5ff; font-size: 11px; font-weight: bold;")
        jarvis_title.setFixedWidth(90)
        self.lbl_jarvis_response = QLabel(
            "Online and ready. Try: 'Open YouTube', 'What's the weather?', or 'How's my system doing?'"
        )
        self.lbl_jarvis_response.setStyleSheet("color: #e0f2fe; font-size: 13px; font-weight: 600;")
        self.lbl_jarvis_response.setWordWrap(True)
        jarvis_layout.addWidget(jarvis_title)
        jarvis_layout.addWidget(self.lbl_jarvis_response, 1)
        subtitles_box.addWidget(jarvis_card)

        # Emotion reaction card
        emotion_card = QFrame()
        emotion_card.setStyleSheet(
            "background-color: #040914; border: 1px dashed #7c3aed; border-radius: 8px;"
        )
        emotion_layout = QHBoxLayout(emotion_card)
        emotion_layout.setContentsMargins(10, 4, 10, 4)
        emotion_title = QLabel("💜 MOOD:")
        emotion_title.setStyleSheet("color: #a78bfa; font-size: 10px; font-weight: bold;")
        emotion_title.setFixedWidth(90)
        self.lbl_emotion_status = QLabel("Activate camera to enable emotion detection")
        self.lbl_emotion_status.setStyleSheet("color: #64748b; font-size: 11px;")
        self.lbl_emotion_status.setWordWrap(True)
        emotion_layout.addWidget(emotion_title)
        emotion_layout.addWidget(self.lbl_emotion_status, 1)
        subtitles_box.addWidget(emotion_card)

        # Action pill
        action_card = QFrame()
        action_card.setStyleSheet(
            "background-color: #040914; border: 1px dashed #334155; border-radius: 8px;"
        )
        action_layout = QHBoxLayout(action_card)
        action_layout.setContentsMargins(10, 3, 10, 3)
        action_title = QLabel("⚙️ ACTION:")
        action_title.setStyleSheet("color: #f59e0b; font-size: 10px; font-weight: bold;")
        action_title.setFixedWidth(90)
        self.lbl_action_executed = QLabel("Idle — No active tool.")
        self.lbl_action_executed.setStyleSheet("color: #94a3b8; font-size: 11px;")
        self.lbl_action_executed.setWordWrap(True)
        action_layout.addWidget(action_title)
        action_layout.addWidget(self.lbl_action_executed, 1)
        subtitles_box.addWidget(action_card)

        center_layout.addLayout(subtitles_box)
        right_layout.addWidget(center_frame, 1)

        # ── Bottom Text Fallback ───────────────────────────────────────
        bottom_bar = QHBoxLayout()
        bottom_bar.setSpacing(8)

        self.txt_input = QLineEdit()
        self.txt_input.setPlaceholderText(
            "Or type a command here... (e.g. 'Open YouTube', 'What is 50 × 20', 'Remember I love coffee')"
        )
        self.txt_input.returnPressed.connect(self._on_send_text)
        bottom_bar.addWidget(self.txt_input, 1)

        self.btn_send = QPushButton("Execute")
        self.btn_send.setObjectName("PrimaryButton")
        self.btn_send.setFixedWidth(90)
        self.btn_send.clicked.connect(self._on_send_text)
        bottom_bar.addWidget(self.btn_send)

        right_layout.addLayout(bottom_bar)

    # ------------------------------------------------------------------
    # Background Setup
    # ------------------------------------------------------------------
    def _init_background_monitors(self):
        self.sys_monitor_worker = SystemMonitorWorker(interval_seconds=2.0)
        self.sys_monitor_worker.metrics_updated.connect(self.hud_bar.update_metrics)
        self.sys_monitor_worker.start()

    def _start_continuous_voice_loop(self):
        self.continuous_voice_worker = ContinuousListeningWorker(self.stt_engine, self.tts_engine)
        self.continuous_voice_worker.speech_detected.connect(self._handle_recognized_speech)
        self.continuous_voice_worker.status_changed.connect(self.status_visualizer.set_state)
        self.continuous_voice_worker.start()
        logger.info("Continuous Hands-Free Voice Loop started.")

    def _speak_welcome(self):
        if Config.VOICE_ENABLED:
            self.tts_engine.speak(
                "JARVIS is online, sir. I'm listening continuously. "
                "Activate the vision panel on the left to enable emotion detection."
            )

    # ------------------------------------------------------------------
    # TTS Callbacks
    # ------------------------------------------------------------------
    def _on_tts_start(self):
        self.status_visualizer.set_state("SPEAKING")

    def _on_tts_finish(self):
        if self._auto_listening_enabled:
            self.status_visualizer.set_state("LISTENING")
        else:
            self.status_visualizer.set_state("IDLE")

    # ------------------------------------------------------------------
    # Emotion Detection Response
    # ------------------------------------------------------------------
    def _on_emotion_detected(self, emotion: str, confidence: float):
        """Called when DeepFace detects a significant emotion change. Responds caringly."""
        now = time.time()
        # 60 second minimum cooldown between emotion reactions
        if now - self._last_emotion_response_time < 60.0:
            return
        self._last_emotion_response_time = now

        responses = EMOTION_RESPONSES.get(emotion, [])
        if not responses:
            return

        caring_response = random.choice(responses)
        self.lbl_emotion_status.setText(f"{emotion.upper()} ({confidence:.0f}%) — Reacting...")
        self.lbl_emotion_status.setStyleSheet("color: #a78bfa; font-size: 11px; font-weight: bold;")

        logger.info(f"JARVIS caring emotion response for '{emotion}': {caring_response}")
        self.lbl_jarvis_response.setText(caring_response)

        if Config.VOICE_ENABLED:
            self.tts_engine.speak(caring_response)

    # ------------------------------------------------------------------
    # Auto-Listening Toggle
    # ------------------------------------------------------------------
    def _toggle_auto_listening(self):
        self._auto_listening_enabled = not self._auto_listening_enabled
        if self._auto_listening_enabled:
            self.btn_toggle_listen.setText("🎙️ Auto-Listen: ON")
            self.btn_toggle_listen.setStyleSheet(
                "background-color: #064e3b; border: 1px solid #10b981; color: #34d399; "
                "font-weight: bold; padding: 4px 10px; border-radius: 5px;"
            )
            if hasattr(self, "continuous_voice_worker"):
                self.continuous_voice_worker.resume_listening()
            self.status_visualizer.set_state("LISTENING")
        else:
            self.btn_toggle_listen.setText("⏸️ Auto-Listen: PAUSED")
            self.btn_toggle_listen.setStyleSheet(
                "background-color: #3f1d24; border: 1px solid #ef4444; color: #ef4444; "
                "font-weight: bold; padding: 4px 10px; border-radius: 5px;"
            )
            if hasattr(self, "continuous_voice_worker"):
                self.continuous_voice_worker.pause_listening()
            self.status_visualizer.set_state("IDLE")

    # ------------------------------------------------------------------
    # Voice & Text Command Handling
    # ------------------------------------------------------------------
    def _handle_recognized_speech(self, text: str):
        if not text or not text.strip():
            return
        self.lbl_user_spoken.setText(f'"{text}"')
        self._process_command(text)

    def _on_send_text(self):
        prompt = self.txt_input.text().strip()
        if not prompt:
            return
        self.txt_input.clear()
        self.lbl_user_spoken.setText(f'"{prompt}"')
        self._process_command(prompt)

    def _process_command(self, prompt: str):
        self.tts_engine.stop()
        self.btn_send.setEnabled(False)
        self.lbl_action_executed.setText("Analyzing request...")
        self.status_visualizer.set_state("THINKING")

        self._active_ai_worker = AIQueryWorker(self.ai_engine, prompt)
        self._active_ai_worker.status_changed.connect(self.status_visualizer.set_state)
        self._active_ai_worker.tool_executed.connect(self._on_tool_executed_live)
        self._active_ai_worker.query_finished.connect(self._on_ai_query_finished)
        self._active_ai_worker.query_failed.connect(self._on_ai_query_failed)
        self._active_ai_worker.start()

    def _on_tool_executed_live(self, tool_name: str, arguments: dict):
        args_str = ", ".join(f"{k}='{v}'" for k, v in arguments.items())
        self.lbl_action_executed.setText(f"Executing: {tool_name}({args_str})")

    def _on_ai_query_finished(self, result: dict):
        self.btn_send.setEnabled(True)
        resp_text = result.get("response", "")
        tool_calls = result.get("tool_calls", [])
        self.lbl_jarvis_response.setText(resp_text)
        if tool_calls:
            self.lbl_action_executed.setText(
                "Completed: " + ", ".join(tc.get("name", "") for tc in tool_calls)
            )
        else:
            self.lbl_action_executed.setText("Response generated.")
        if Config.VOICE_ENABLED and resp_text:
            self.tts_engine.speak(resp_text)

    def _on_ai_query_failed(self, error_msg: str):
        self.btn_send.setEnabled(True)
        self.status_visualizer.set_state("ERROR")
        self.lbl_jarvis_response.setText(f"⚠️ Error: {error_msg}")
        self.lbl_action_executed.setText("Execution failed.")
        if Config.VOICE_ENABLED:
            self.tts_engine.speak("I encountered an error, sir. Please try again.")

    def _handle_security_confirmation(self, tool_name: str, arguments: dict, description: str) -> bool:
        return ConfirmationDialog.ask_confirmation(
            tool_name=tool_name,
            arguments=arguments,
            description=description,
            parent=self,
        )

    def _on_quick_screenshot(self):
        res = take_screenshot()
        if res.get("status") == "success":
            self.lbl_action_executed.setText(f"Screenshot saved: {res['path']}")
            self.lbl_jarvis_response.setText("Screenshot captured, sir.")
            if Config.VOICE_ENABLED:
                self.tts_engine.speak("Screenshot captured and saved, sir.")

    def _open_settings(self):
        dialog = SettingsDialog(
            ai_engine=self.ai_engine,
            tts_engine=self.tts_engine,
            memory_manager=self.memory_mgr,
            parent=self,
        )
        if dialog.exec():
            self.hud_bar.set_active_model_name(self.ai_engine.ollama_model, self.ai_engine.provider)
            saved_mic = self.db.get_setting("mic_device_index", default=2)
            self.stt_engine.device_index = saved_mic

    def closeEvent(self, event):
        logger.info("Shutting down JARVIS...")
        if hasattr(self, "vision_panel"):
            self.vision_panel._stop_camera()
        if hasattr(self, "continuous_voice_worker"):
            self.continuous_voice_worker.stop()
        if hasattr(self, "sys_monitor_worker"):
            self.sys_monitor_worker.stop()
        if hasattr(self, "tts_engine"):
            self.tts_engine.stop()
        event.accept()
