"""
Windows System Control and Hardware Monitoring Tools for JARVIS.
Controls master volume, media keys, lock screen, power operations, and retrieves system resource metrics.
"""

import sys
import os
import platform
import ctypes
import psutil
from typing import Dict, Any, Optional
from app.utils.system_info import get_system_snapshot
from app.utils.helpers import format_bytes
from app.utils.logger import get_logger

logger = get_logger("SystemControl")

# Windows Virtual Key Codes for Media & Volume
VK_VOLUME_MUTE = 0xAD
VK_VOLUME_DOWN = 0xAE
VK_VOLUME_UP = 0xAF
VK_MEDIA_NEXT_TRACK = 0xB0
VK_MEDIA_PREV_TRACK = 0xB1
VK_MEDIA_STOP = 0xB2
VK_MEDIA_PLAY_PAUSE = 0xB3
KEYEVENTF_EXTENDEDKEY = 0x0001
KEYEVENTF_KEYUP = 0x0002


def _send_vk_key(vk_code: int):
    """Sends a Windows Virtual Key event safely via user32."""
    if platform.system() == "Windows":
        try:
            ctypes.windll.user32.keybd_event(vk_code, 0, KEYEVENTF_EXTENDEDKEY, 0)
            ctypes.windll.user32.keybd_event(vk_code, 0, KEYEVENTF_EXTENDEDKEY | KEYEVENTF_KEYUP, 0)
        except Exception as e:
            logger.error(f"Failed to send VK key {vk_code}: {e}")


def get_system_information() -> Dict[str, Any]:
    """Returns a full diagnostic overview of the host PC (CPU, RAM, Disk, Battery, Network, OS)."""
    snapshot = get_system_snapshot()
    return {
        "os": snapshot["os"],
        "cpu_usage_percent": f"{snapshot['cpu_percent']}%",
        "cpu_cores": snapshot["cpu_count"],
        "ram_usage": f"{snapshot['ram_percent']}% ({format_bytes(snapshot['ram_used_bytes'])} / {format_bytes(snapshot['ram_total_bytes'])})",
        "disk_usage": f"{snapshot['disk_percent']}% ({format_bytes(snapshot['disk_used_bytes'])} / {format_bytes(snapshot['disk_total_bytes'])})",
        "battery": f"{snapshot['battery_percent']}% {'(Charging)' if snapshot['battery_power_plugged'] else '(On Battery)'}" if snapshot['battery_percent'] is not None else "No Battery (Desktop PC)",
        "network_connected": snapshot["network_connected"],
        "ip_address": snapshot["ip_address"],
    }


def get_cpu_usage() -> Dict[str, Any]:
    """Returns the current CPU utilization percentage and core count."""
    percent = psutil.cpu_percent(interval=0.2)
    cores = psutil.cpu_count(logical=True)
    return {
        "cpu_percent": percent,
        "cores": cores,
        "summary": f"Current CPU utilization is at {percent}% across {cores} logical cores."
    }


def get_ram_usage() -> Dict[str, Any]:
    """Returns current RAM consumption and total memory capacity."""
    mem = psutil.virtual_memory()
    return {
        "percent": mem.percent,
        "used": format_bytes(mem.used),
        "total": format_bytes(mem.total),
        "available": format_bytes(mem.available),
        "summary": f"Memory usage is {mem.percent}% ({format_bytes(mem.used)} used out of {format_bytes(mem.total)})."
    }


def get_battery_status() -> Dict[str, Any]:
    """Returns laptop battery percentage, power plug state, and estimated remaining time."""
    if not hasattr(psutil, "sensors_battery"):
        return {"error": "Battery monitoring is not supported on this platform."}
    battery = psutil.sensors_battery()
    if battery is None:
        return {"has_battery": False, "summary": "This computer does not have a battery (Desktop / AC powered)."}

    mins_left = round(battery.secsleft / 60) if battery.secsleft > 0 and battery.secsleft != psutil.POWER_TIME_UNLIMITED else None
    return {
        "has_battery": True,
        "percent": round(battery.percent, 1),
        "is_plugged": battery.power_plugged,
        "time_remaining_minutes": mins_left,
        "summary": f"Battery is at {round(battery.percent)}% {'and charging' if battery.power_plugged else 'discharging'}{f' (~{mins_left} mins remaining)' if mins_left else ''}."
    }


def volume_up(steps: int = 5) -> Dict[str, Any]:
    """Increases master system volume."""
    for _ in range(max(1, min(steps, 25))):
        _send_vk_key(VK_VOLUME_UP)
    return {"status": "success", "message": f"Volume increased by {steps} steps."}


def volume_down(steps: int = 5) -> Dict[str, Any]:
    """Decreases master system volume."""
    for _ in range(max(1, min(steps, 25))):
        _send_vk_key(VK_VOLUME_DOWN)
    return {"status": "success", "message": f"Volume decreased by {steps} steps."}


def mute_volume() -> Dict[str, Any]:
    """Toggles or sets mute state on Windows master audio."""
    _send_vk_key(VK_VOLUME_MUTE)
    return {"status": "success", "message": "Master audio muted."}


def unmute_volume() -> Dict[str, Any]:
    """Unmutes audio by triggering volume step."""
    _send_vk_key(VK_VOLUME_UP)
    return {"status": "success", "message": "Master audio unmuted."}


def media_play_pause() -> Dict[str, Any]:
    """Toggles Play/Pause on active media player (Spotify, YouTube, VLC, Media Player)."""
    _send_vk_key(VK_MEDIA_PLAY_PAUSE)
    return {"status": "success", "message": "Triggered media Play/Pause."}


def media_next() -> Dict[str, Any]:
    """Skips to the next media track."""
    _send_vk_key(VK_MEDIA_NEXT_TRACK)
    return {"status": "success", "message": "Skipped to next track."}


def media_previous() -> Dict[str, Any]:
    """Returns to the previous media track."""
    _send_vk_key(VK_MEDIA_PREV_TRACK)
    return {"status": "success", "message": "Returned to previous track."}


def lock_workstation() -> Dict[str, Any]:
    """Locks the Windows workstation instantly."""
    if platform.system() == "Windows":
        ctypes.windll.user32.LockWorkStation()
        return {"status": "success", "message": "Workstation locked."}
    return {"error": "Lock screen only supported on Windows."}


def shutdown_system(timer_seconds: int = 30) -> Dict[str, Any]:
    """Initiates a safe Windows system shutdown with a countdown."""
    if platform.system() == "Windows":
        os.system(f"shutdown /s /t {timer_seconds}")
        return {"status": "success", "message": f"System shutdown scheduled in {timer_seconds} seconds. Use 'shutdown /a' to abort."}
    return {"error": "Shutdown tool only supported on Windows."}


def restart_system(timer_seconds: int = 30) -> Dict[str, Any]:
    """Initiates a safe Windows system reboot with a countdown."""
    if platform.system() == "Windows":
        os.system(f"shutdown /r /t {timer_seconds}")
        return {"status": "success", "message": f"System reboot scheduled in {timer_seconds} seconds. Use 'shutdown /a' to abort."}
    return {"error": "Restart tool only supported on Windows."}
