"""
Real-time Weather Information Tool for JARVIS.
Fetches current weather and forecasts using the Open-Meteo API (free worldwide geocoding & forecast, no API key needed)
with optional OpenWeatherMap fallback.
"""

import requests
from typing import Dict, Any, Optional
from app.config import Config
from app.utils.logger import get_logger

logger = get_logger("Weather")

# Open-Meteo Weather Interpretation Codes (WMO)
WMO_WEATHER_CODES = {
    0: "Clear sky ☀️",
    1: "Mainly clear 🌤️",
    2: "Partly cloudy ⛅",
    3: "Overcast ☁️",
    45: "Foggy 🌫️",
    48: "Depositing rime fog 🌫️",
    51: "Light drizzle 🌧️",
    53: "Moderate drizzle 🌧️",
    55: "Dense drizzle 🌧️",
    61: "Slight rain 🌦️",
    63: "Moderate rain 🌧️",
    65: "Heavy rain 🌧️🌧️",
    71: "Slight snowfall 🌨️",
    73: "Moderate snowfall 🌨️",
    75: "Heavy snowfall ❄️",
    77: "Snow grains ❄️",
    80: "Slight rain showers 🌦️",
    81: "Moderate rain showers 🌧️",
    82: "Violent rain showers ⛈️",
    85: "Slight snow showers 🌨️",
    86: "Heavy snow showers ❄️",
    95: "Thunderstorm ⚡",
    96: "Thunderstorm with slight hail ⛈️",
    99: "Thunderstorm with heavy hail ⛈️",
}


def _geocode_location(city_name: str) -> Optional[Dict[str, Any]]:
    """Resolves city name to latitude/longitude using Open-Meteo Geocoding API."""
    try:
        url = "https://geocoding-api.open-meteo.com/v1/search"
        params = {"name": city_name, "count": 1, "language": "en", "format": "json"}
        resp = requests.get(url, params=params, timeout=5.0)
        if resp.status_code == 200:
            data = resp.json()
            results = data.get("results", [])
            if results:
                res = results[0]
                return {
                    "name": res.get("name"),
                    "country": res.get("country", ""),
                    "admin1": res.get("admin1", ""),
                    "lat": res.get("latitude"),
                    "lon": res.get("longitude"),
                }
    except Exception as e:
        logger.debug(f"Geocoding failed for {city_name}: {e}")
    return None


def get_weather(location: Optional[str] = None) -> Dict[str, Any]:
    """
    Retrieves the current weather and 24-hour conditions for any city worldwide.
    Defaults to configured location (e.g. New York, London, Bangalore).
    """
    loc_query = location or Config.DEFAULT_LOCATION
    geo = _geocode_location(loc_query)
    if not geo:
        return {
            "status": "error",
            "location": loc_query,
            "error": f"Could not find geographic coordinates for '{loc_query}'. Please check the city name.",
        }

    try:
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": geo["lat"],
            "longitude": geo["lon"],
            "current": ["temperature_2m", "relative_humidity_2m", "apparent_temperature", "weather_code", "wind_speed_10m", "precipitation"],
            "daily": ["temperature_2m_max", "temperature_2m_min", "precipitation_probability_max"],
            "timezone": "auto",
        }
        resp = requests.get(url, params=params, timeout=5.0)
        if resp.status_code != 200:
            return {"status": "error", "error": f"Weather service returned HTTP {resp.status_code}"}

        data = resp.json()
        current = data.get("current", {})
        daily = data.get("daily", {})

        weather_code = current.get("weather_code", 0)
        weather_desc = WMO_WEATHER_CODES.get(weather_code, "Partly cloudy")

        temp = current.get("temperature_2m")
        feels_like = current.get("apparent_temperature")
        humidity = current.get("relative_humidity_2m")
        wind_speed = current.get("wind_speed_10m")
        precip = current.get("precipitation")

        high_temp = daily.get("temperature_2m_max", [temp])[0]
        low_temp = daily.get("temperature_2m_min", [temp])[0]
        rain_prob = daily.get("precipitation_probability_max", [0])[0]

        place_str = f"{geo['name']}, {geo['country']}" if geo['country'] else geo['name']
        summary = (
            f"The weather in {place_str} is currently {weather_desc} at {temp}°C (feels like {feels_like}°C). "
            f"Humidity is {humidity}%, wind is {wind_speed} km/h, and today's high will reach {high_temp}°C with a low of {low_temp}°C."
        )

        return {
            "status": "success",
            "location": place_str,
            "condition": weather_desc,
            "temperature_celsius": temp,
            "feels_like_celsius": feels_like,
            "humidity_percent": humidity,
            "wind_speed_kmh": wind_speed,
            "precipitation_mm": precip,
            "rain_probability_percent": rain_prob,
            "high_celsius": high_temp,
            "low_celsius": low_temp,
            "summary": summary,
        }
    except Exception as e:
        logger.error(f"Failed to fetch forecast: {e}")
        return {"status": "error", "error": f"Weather fetch failed: {e}"}
