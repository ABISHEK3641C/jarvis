"""
Unit Conversion Tool for JARVIS.
Pure-math conversion for length, weight, temperature, and data sizes.
Currency conversion uses the free exchangerate.host API with offline fallback rates.
"""

from typing import Dict, Any, Optional
import requests
from app.utils.logger import get_logger

logger = get_logger("UnitConverter")


# Each table maps unit alias → (canonical_name, factor_to_base_unit).
# Base units: meter (length), gram (weight), byte (data), celsius (temperature handled separately).
LENGTH_TABLE = {
    "m": ("meter", 1.0), "meter": ("meter", 1.0), "meters": ("meter", 1.0), "metre": ("meter", 1.0),
    "km": ("kilometer", 1000.0), "kilometer": ("kilometer", 1000.0), "kilometers": ("kilometer", 1000.0),
    "cm": ("centimeter", 0.01), "centimeter": ("centimeter", 0.01), "centimeters": ("centimeter", 0.01),
    "mm": ("millimeter", 0.001), "millimeter": ("millimeter", 0.001),
    "mi": ("mile", 1609.344), "mile": ("mile", 1609.344), "miles": ("mile", 1609.344),
    "yd": ("yard", 0.9144), "yard": ("yard", 0.9144), "yards": ("yard", 0.9144),
    "ft": ("foot", 0.3048), "foot": ("foot", 0.3048), "feet": ("foot", 0.3048),
    "in": ("inch", 0.0254), "inch": ("inch", 0.0254), "inches": ("inch", 0.0254),
}

WEIGHT_TABLE = {
    "g": ("gram", 1.0), "gram": ("gram", 1.0), "grams": ("gram", 1.0),
    "kg": ("kilogram", 1000.0), "kilogram": ("kilogram", 1000.0), "kilograms": ("kilogram", 1000.0),
    "mg": ("milligram", 0.001), "milligram": ("milligram", 0.001),
    "lb": ("pound", 453.592), "lbs": ("pound", 453.592), "pound": ("pound", 453.592), "pounds": ("pound", 453.592),
    "oz": ("ounce", 28.3495), "ounce": ("ounce", 28.3495), "ounces": ("ounce", 28.3495),
    "ton": ("metric_ton", 1_000_000.0), "tonne": ("metric_ton", 1_000_000.0),
}

DATA_TABLE = {
    "b": ("byte", 1.0), "byte": ("byte", 1.0), "bytes": ("byte", 1.0),
    "kb": ("kilobyte", 1024.0), "kilobyte": ("kilobyte", 1024.0),
    "mb": ("megabyte", 1024.0 ** 2), "megabyte": ("megabyte", 1024.0 ** 2),
    "gb": ("gigabyte", 1024.0 ** 3), "gigabyte": ("gigabyte", 1024.0 ** 3),
    "tb": ("terabyte", 1024.0 ** 4), "terabyte": ("terabyte", 1024.0 ** 4),
    "pb": ("petabyte", 1024.0 ** 5), "petabyte": ("petabyte", 1024.0 ** 5),
}

# Offline fallback rates (USD base). Updated as of 2024 — used only when API is unreachable.
FALLBACK_CURRENCY_RATES = {
    "USD": 1.0, "EUR": 0.92, "GBP": 0.79, "INR": 83.5, "JPY": 156.0,
    "CNY": 7.24, "AUD": 1.52, "CAD": 1.36, "CHF": 0.91, "SGD": 1.35,
    "AED": 3.67, "SAR": 3.75, "PKR": 278.0, "BDT": 117.0, "RUB": 92.0,
}


def _resolve(table: Dict[str, tuple], key: str) -> Optional[tuple]:
    """Returns (canonical_name, factor_to_base) or None if unknown."""
    if not key:
        return None
    return table.get(key.strip().lower())


def convert_length(value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
    src = _resolve(LENGTH_TABLE, from_unit)
    tgt = _resolve(LENGTH_TABLE, to_unit)
    if not src or not tgt:
        return {"status": "error", "error": f"Unknown length unit: '{from_unit}' or '{to_unit}'."}
    meters = value * src[1]
    result = meters / tgt[1]
    return {
        "status": "success",
        "category": "length",
        "from": f"{value} {src[0]}",
        "to": f"{result:.6g} {tgt[0]}",
        "result": result,
        "summary": f"{value} {src[0]} = {result:.4g} {tgt[0]}",
    }


def convert_weight(value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
    src = _resolve(WEIGHT_TABLE, from_unit)
    tgt = _resolve(WEIGHT_TABLE, to_unit)
    if not src or not tgt:
        return {"status": "error", "error": f"Unknown weight unit: '{from_unit}' or '{to_unit}'."}
    grams = value * src[1]
    result = grams / tgt[1]
    return {
        "status": "success",
        "category": "weight",
        "from": f"{value} {src[0]}",
        "to": f"{result:.6g} {tgt[0]}",
        "result": result,
        "summary": f"{value} {src[0]} = {result:.4g} {tgt[0]}",
    }


def convert_temperature(value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
    f = from_unit.strip().lower()
    t = to_unit.strip().lower()
    # Normalize aliases.
    f = {"celsius": "c", "centigrade": "c", "°c": "c", "c": "c",
         "fahrenheit": "f", "°f": "f", "f": "f",
         "kelvin": "k", "k": "k"}.get(f, f)
    t = {"celsius": "c", "centigrade": "c", "°c": "c", "c": "c",
         "fahrenheit": "f", "°f": "f", "f": "f",
         "kelvin": "k", "k": "k"}.get(t, t)
    if f not in ("c", "f", "k") or t not in ("c", "f", "k"):
        return {"status": "error", "error": f"Unknown temperature unit: '{from_unit}' or '{to_unit}'."}

    # Convert input → Celsius
    if f == "c":
        celsius = value
    elif f == "f":
        celsius = (value - 32) * 5 / 9
    else:  # kelvin
        celsius = value - 273.15

    # Convert Celsius → target
    if t == "c":
        result = celsius
        unit = "°C"
    elif t == "f":
        result = celsius * 9 / 5 + 32
        unit = "°F"
    else:
        result = celsius + 273.15
        unit = "K"

    return {
        "status": "success",
        "category": "temperature",
        "from": f"{value} {f.upper()}",
        "to": f"{result:.4g} {unit}",
        "result": result,
        "summary": f"{value} {f.upper()} = {result:.3f} {unit}",
    }


def convert_data(value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
    src = _resolve(DATA_TABLE, from_unit)
    tgt = _resolve(DATA_TABLE, to_unit)
    if not src or not tgt:
        return {"status": "error", "error": f"Unknown data unit: '{from_unit}' or '{to_unit}'."}
    bytes_ = value * src[1]
    result = bytes_ / tgt[1]
    return {
        "status": "success",
        "category": "data",
        "from": f"{value} {src[0]}",
        "to": f"{result:.6g} {tgt[0]}",
        "result": result,
        "summary": f"{value} {src[0]} = {result:.4g} {tgt[0]}",
    }


def convert_currency(value: float, from_unit: str, to_unit: str) -> Dict[str, Any]:
    """Live currency conversion via exchangerate.host (free, no key) with offline fallback."""
    base = from_unit.strip().upper()
    target = to_unit.strip().upper()
    if not base or not target:
        return {"status": "error", "error": "Both currency codes are required."}
    if base == target:
        return {
            "status": "success",
            "category": "currency",
            "from": f"{value} {base}",
            "to": f"{value} {target}",
            "result": value,
            "summary": f"{value} {base} = {value} {target} (same currency).",
        }

    rate = None
    source = "fallback"
    try:
        url = "https://api.exchangerate.host/latest"
        params = {"base": base, "symbols": target}
        resp = requests.get(url, params=params, timeout=5.0)
        if resp.status_code == 200:
            data = resp.json()
            r = data.get("rates", {}).get(target)
            if r:
                rate = float(r)
                source = "live"
    except Exception as e:
        logger.debug(f"Live currency fetch failed ({base}->{target}): {e}")

    if rate is None:
        if base in FALLBACK_CURRENCY_RATES and target in FALLBACK_CURRENCY_RATES:
            # Convert base → USD → target using fallback rates.
            rate = FALLBACK_CURRENCY_RATES[target] / FALLBACK_CURRENCY_RATES[base]
            source = "fallback"
        else:
            return {"status": "error", "error": f"Unknown currency '{base}' or '{target}'."}

    result = value * rate
    return {
        "status": "success",
        "category": "currency",
        "from": f"{value} {base}",
        "to": f"{result:.4f} {target}",
        "result": result,
        "rate": rate,
        "rate_source": source,
        "summary": f"{value} {base} = {result:.2f} {target} (rate {rate:.4f}, {source}).",
    }


def convert_units(value: float, from_unit: str, to_unit: str, category: str = "auto") -> Dict[str, Any]:
    """
    High-level converter. Auto-detects category from unit names, or accepts an explicit category.
    Categories: 'length', 'weight', 'temperature', 'data', 'currency'.
    """
    if category == "auto":
        category = _guess_category(from_unit, to_unit)

    if category == "length":
        return convert_length(value, from_unit, to_unit)
    if category == "weight":
        return convert_weight(value, from_unit, to_unit)
    if category == "temperature":
        return convert_temperature(value, from_unit, to_unit)
    if category == "data":
        return convert_data(value, from_unit, to_unit)
    if category == "currency":
        return convert_currency(value, from_unit, to_unit)
    return {
        "status": "error",
        "error": f"Could not determine category for '{from_unit}' -> '{to_unit}'. "
                 f"Please specify one of: length, weight, temperature, data, currency.",
    }


def _guess_category(from_unit: str, to_unit: str) -> str:
    f = (from_unit or "").strip().lower()
    t = (to_unit or "").strip().lower()
    if f in LENGTH_TABLE or t in LENGTH_TABLE:
        return "length"
    if f in WEIGHT_TABLE or t in WEIGHT_TABLE:
        return "weight"
    if f in DATA_TABLE or t in DATA_TABLE:
        return "data"
    # Temperature aliases need explicit check.
    temp_aliases = {"c", "f", "k", "celsius", "fahrenheit", "kelvin", "°c", "°f"}
    if f in temp_aliases or t in temp_aliases:
        return "temperature"
    # Currency codes are 3 uppercase letters.
    if len(f) == 3 and len(t) == 3 and f.isalpha() and t.isalpha():
        return "currency"
    return "unknown"
