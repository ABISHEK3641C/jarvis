"""
Windows Application Management and Launcher Tool for JARVIS.
Detects installed applications, Start Menu shortcuts, common programs, web apps, and custom registered paths.
Launches and safely terminates desktop applications.
"""

import os
import subprocess
import webbrowser
import psutil
from pathlib import Path
from typing import Dict, Any, List, Optional
from app.core.database import Database
from app.utils.logger import get_logger

logger = get_logger("Applications")

# Common Windows desktop executable aliases
COMMON_APP_MAP = {
    "notepad": "notepad.exe",
    "calculator": "calc.exe",
    "calc": "calc.exe",
    "explorer": "explorer.exe",
    "file explorer": "explorer.exe",
    "cmd": "cmd.exe",
    "command prompt": "cmd.exe",
    "powershell": "powershell.exe",
    "paint": "mspaint.exe",
    "task manager": "taskmgr.exe",
    "taskmgr": "taskmgr.exe",
    "control panel": "control.exe",
    "settings": "ms-settings:",
    "chrome": "chrome.exe",
    "google chrome": "chrome.exe",
    "edge": "msedge.exe",
    "microsoft edge": "msedge.exe",
    "firefox": "firefox.exe",
    "vscode": "code.cmd",
    "vs code": "code.cmd",
    "visual studio code": "code.cmd",
    "discord": "Discord.exe",
    "spotify": "Spotify.exe",
    "steam": "steam.exe",
    "word": "winword.exe",
    "excel": "excel.exe",
    "powerpoint": "powerpnt.exe",
    "vlc": "vlc.exe",
}

# Popular Web Applications & Websites
POPULAR_WEB_APPS = {
    "youtube": "https://www.youtube.com",
    "yt": "https://www.youtube.com",
    "google": "https://www.google.com",
    "chatgpt": "https://chatgpt.com",
    "openai": "https://chatgpt.com",
    "github": "https://github.com",
    "gmail": "https://mail.google.com",
    "instagram": "https://www.instagram.com",
    "facebook": "https://www.facebook.com",
    "twitter": "https://x.com",
    "x": "https://x.com",
    "reddit": "https://www.reddit.com",
    "netflix": "https://www.netflix.com",
    "amazon": "https://www.amazon.com",
    "whatsapp": "https://web.whatsapp.com",
    "telegram": "https://web.telegram.org",
    "linkedin": "https://www.linkedin.com",
    "maps": "https://maps.google.com",
    "google maps": "https://maps.google.com",
    "wikipedia": "https://www.wikipedia.org",
    "stackoverflow": "https://stackoverflow.com",
    "prime video": "https://www.primevideo.com",
    "hotstar": "https://www.hotstar.com",
}


def _scan_start_menu_shortcuts() -> Dict[str, str]:
    """Scans Start Menu folders for installed .lnk shortcuts."""
    shortcuts = {}
    scan_paths = [
        Path(os.environ.get("ProgramData", "C:\\ProgramData")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
        Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs",
    ]

    for base in scan_paths:
        if base.exists():
            try:
                for lnk in base.rglob("*.lnk"):
                    clean_name = lnk.stem.lower()
                    if clean_name not in shortcuts:
                        shortcuts[clean_name] = str(lnk)
            except Exception as e:
                logger.debug(f"Error scanning shortcuts in {base}: {e}")

    return shortcuts


def open_application(app_name: str) -> Dict[str, Any]:
    """
    Launches an application by common name, executable filename, shortcut, or web application URL.
    Supports Windows desktop apps, browsers, start menu programs, and web platforms (YouTube, ChatGPT, GitHub, etc.).
    """
    target = app_name.strip().lower()
    db = Database()

    # 1. Check custom database registered apps
    custom_apps = db.list_custom_apps()
    for app in custom_apps:
        if app["name"].lower() == target:
            app_path = app["path"]
            try:
                os.startfile(app_path)
                return {"status": "success", "app": app["name"], "path": app_path, "message": f"Launched custom application '{app['name']}'."}
            except Exception as e:
                return {"status": "error", "error": f"Failed to launch '{app_path}': {e}"}

    # 2. Check desktop common aliases map
    if target in COMMON_APP_MAP:
        exec_target = COMMON_APP_MAP[target]
        try:
            os.startfile(exec_target)
            return {"status": "success", "app": app_name, "executable": exec_target, "message": f"Successfully opened {app_name}."}
        except Exception:
            try:
                subprocess.Popen(exec_target, shell=True)
                return {"status": "success", "app": app_name, "executable": exec_target, "message": f"Successfully opened {app_name}."}
            except Exception as e:
                logger.debug(f"Direct startfile failed for {exec_target}: {e}")

    # 3. Check Start Menu shortcuts
    shortcuts = _scan_start_menu_shortcuts()
    for s_name, s_path in shortcuts.items():
        if target == s_name or (len(target) > 3 and target in s_name):
            try:
                os.startfile(s_path)
                return {"status": "success", "app": s_name, "path": s_path, "message": f"Launched '{s_name}' from Start Menu."}
            except Exception as e:
                return {"status": "error", "error": f"Failed to start shortcut {s_name}: {e}"}

    # 4. Check Popular Web Applications (YouTube, ChatGPT, Gmail, GitHub, Instagram, etc.)
    clean_web_target = target.replace(" ", "").replace(".com", "")
    for web_key, web_url in POPULAR_WEB_APPS.items():
        if target == web_key or clean_web_target == web_key.replace(" ", "") or target.startswith(web_key):
            try:
                webbrowser.open(web_url)
                return {"status": "success", "app": web_key.title(), "url": web_url, "message": f"Opened {web_key.title()} in your web browser."}
            except Exception as e:
                return {"status": "error", "error": f"Failed to open web app {web_key}: {e}"}

    # 5. Check if it is a domain name (e.g. youtube.com, reddit.com, news.ycombinator.com)
    if "." in target and not target.endswith(".exe") and not target.endswith(".lnk"):
        url = target if target.startswith("http") else f"https://{target}"
        try:
            webbrowser.open(url)
            return {"status": "success", "app": target, "url": url, "message": f"Opened {url} in your browser."}
        except Exception as e:
            return {"status": "error", "error": f"Failed to open {url}: {e}"}

    # 6. Try generic Windows startfile
    try:
        os.startfile(app_name)
        return {"status": "success", "app": app_name, "message": f"Started {app_name} via Windows Shell."}
    except Exception:
        pass

    return {
        "status": "not_found",
        "app": app_name,
        "error": f"Could not find an installed application matching '{app_name}'. You can register its exact path in JARVIS Settings.",
    }


def close_application(app_name: str) -> Dict[str, Any]:
    """
    Finds running processes matching app_name and requests termination.
    """
    target = app_name.strip().lower()
    if target in COMMON_APP_MAP:
        target_exec = COMMON_APP_MAP[target].lower().replace(".exe", "").replace(".cmd", "")
    else:
        target_exec = target.replace(".exe", "")

    killed_count = 0
    killed_names = set()

    for proc in psutil.process_iter(["pid", "name"]):
        try:
            p_name = proc.info["name"].lower()
            if target_exec in p_name:
                proc.terminate()
                killed_count += 1
                killed_names.add(proc.info["name"])
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue

    if killed_count > 0:
        return {
            "status": "success",
            "app": app_name,
            "processes_terminated": list(killed_names),
            "count": killed_count,
            "message": f"Closed {killed_count} running process instance(s) of '{app_name}'."
        }

    return {
        "status": "not_running",
        "app": app_name,
        "message": f"No active processes found matching '{app_name}'."
    }


def list_installed_applications(filter_name: Optional[str] = None) -> Dict[str, Any]:
    """Returns a list of detected start menu applications, web apps, and custom registered paths."""
    shortcuts = _scan_start_menu_shortcuts()
    db = Database()
    custom_apps = db.list_custom_apps()

    app_list = sorted(list(shortcuts.keys()))
    if filter_name:
        f = filter_name.lower()
        app_list = [a for a in app_list if f in a]

    return {
        "start_menu_apps_count": len(shortcuts),
        "matching_apps": app_list[:50],
        "web_apps": list(POPULAR_WEB_APPS.keys()),
        "custom_apps": [a["name"] for a in custom_apps],
    }


def add_custom_application(name: str, path: str) -> Dict[str, Any]:
    """Registers a new custom executable path into JARVIS database."""
    if not os.path.exists(path):
        return {"status": "error", "error": f"Path '{path}' does not exist on this machine."}
    db = Database()
    success = db.add_custom_app(name, path)
    if success:
        return {"status": "success", "message": f"Registered '{name}' pointing to '{path}'."}
    return {"status": "error", "error": "Failed to save application to database."}
