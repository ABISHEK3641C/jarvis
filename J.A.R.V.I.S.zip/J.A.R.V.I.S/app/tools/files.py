"""
File System Management and Search Tools for JARVIS.
Controlled file and directory operations (search, read, write, move, rename, delete with safety checks).
"""

import os
import shutil
from pathlib import Path
from typing import Dict, Any, List, Optional
from datetime import datetime
from app.utils.helpers import format_bytes
from app.utils.logger import get_logger

logger = get_logger("Files")

# Default user root directories to search safely
def _get_search_roots(custom_dir: Optional[str] = None) -> List[Path]:
    """Returns candidate directories for search operations."""
    if custom_dir:
        p = Path(custom_dir).expanduser().resolve()
        if p.exists() and p.is_dir():
            return [p]

    user_home = Path.home()
    roots = [
        user_home / "Desktop",
        user_home / "Documents",
        user_home / "Downloads",
        user_home / "Pictures",
        user_home / "Videos",
        user_home / "Music",
    ]
    return [r for r in roots if r.exists()]


def search_files(
    pattern: str,
    search_dir: Optional[str] = None,
    max_results: int = 25,
    max_depth: int = 4,
) -> Dict[str, Any]:
    """
    Searches for files matching a glob or wildcard pattern (e.g. '*.pdf', 'budget*.*', '*.py').
    Searches standard user folders or a specific target directory up to a bounded depth.
    """
    roots = _get_search_roots(search_dir)
    results = []
    clean_pattern = pattern.strip()
    if not any(c in clean_pattern for c in ["*", "?"]):
        clean_pattern = f"*{clean_pattern}*"

    for root in roots:
        try:
            for root_dir, dirs, files in os.walk(root):
                # Calculate relative depth to prevent excessive deep scanning
                rel_depth = len(Path(root_dir).relative_to(root).parts)
                if rel_depth > max_depth:
                    dirs.clear()  # Don't descend further
                    continue

                for filename in files:
                    file_path = Path(root_dir) / filename
                    if file_path.match(clean_pattern):
                        try:
                            stat = file_path.stat()
                            results.append({
                                "name": filename,
                                "path": str(file_path),
                                "size": format_bytes(stat.st_size),
                                "size_bytes": stat.st_size,
                                "modified": datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M"),
                            })
                            if len(results) >= max_results:
                                break
                        except Exception:
                            continue
                if len(results) >= max_results:
                    break
        except Exception as e:
            logger.debug(f"Error scanning directory {root}: {e}")

    return {
        "pattern": pattern,
        "count": len(results),
        "matches": results,
        "summary": f"Found {len(results)} file(s) matching '{pattern}'."
    }


def read_file(file_path: str, max_chars: int = 4000) -> Dict[str, Any]:
    """Reads and returns the textual contents of a local file."""
    path = Path(file_path).expanduser().resolve()
    if not path.exists():
        return {"status": "error", "error": f"File '{file_path}' does not exist."}
    if not path.is_file():
        return {"status": "error", "error": f"Path '{file_path}' is not a regular file."}

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
        truncated = len(content) > max_chars
        preview = content[:max_chars]
        return {
            "status": "success",
            "path": str(path),
            "size": format_bytes(path.stat().st_size),
            "content": preview,
            "truncated": truncated,
            "total_chars": len(content),
        }
    except Exception as e:
        return {"status": "error", "error": f"Failed to read file: {e}"}


def create_file(file_path: str, content: str = "") -> Dict[str, Any]:
    """Creates a new text file with the specified content."""
    path = Path(file_path).expanduser().resolve()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return {
            "status": "success",
            "path": str(path),
            "size": format_bytes(len(content.encode('utf-8'))),
            "message": f"Successfully created file at '{path}'."
        }
    except Exception as e:
        return {"status": "error", "error": f"Failed to create file: {e}"}


def create_folder(folder_path: str) -> Dict[str, Any]:
    """Creates a new directory structure."""
    path = Path(folder_path).expanduser().resolve()
    try:
        path.mkdir(parents=True, exist_ok=True)
        return {"status": "success", "path": str(path), "message": f"Created directory at '{path}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to create directory: {e}"}


def open_folder(folder_path: str = "") -> Dict[str, Any]:
    """Opens a folder in Windows File Explorer (defaults to User Home or Documents)."""
    target = folder_path.strip().lower()
    if not target or target in ("home", "user"):
        path = Path.home()
    elif target in ("documents", "docs"):
        path = Path.home() / "Documents"
    elif target in ("downloads", "download"):
        path = Path.home() / "Downloads"
    elif target in ("desktop", "desk"):
        path = Path.home() / "Desktop"
    elif target in ("pictures", "photos"):
        path = Path.home() / "Pictures"
    else:
        path = Path(folder_path).expanduser().resolve()

    if not path.exists():
        return {"status": "error", "error": f"Folder '{folder_path}' does not exist."}

    try:
        os.startfile(str(path))
        return {"status": "success", "path": str(path), "message": f"Opened folder '{path}' in Explorer."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to open folder: {e}"}


def rename_file(file_path: str, new_name: str) -> Dict[str, Any]:
    """Renames an existing file or folder."""
    src = Path(file_path).expanduser().resolve()
    if not src.exists():
        return {"status": "error", "error": f"Source path '{file_path}' does not exist."}
    dest = src.parent / new_name.strip()
    try:
        src.rename(dest)
        return {"status": "success", "old_path": str(src), "new_path": str(dest), "message": f"Renamed '{src.name}' to '{new_name}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to rename file: {e}"}


def move_file(source_path: str, destination_path: str) -> Dict[str, Any]:
    """Moves a file or folder to a new destination."""
    src = Path(source_path).expanduser().resolve()
    dest = Path(destination_path).expanduser().resolve()
    if not src.exists():
        return {"status": "error", "error": f"Source '{source_path}' does not exist."}
    try:
        shutil.move(str(src), str(dest))
        return {"status": "success", "message": f"Moved '{src}' to '{dest}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to move: {e}"}


def copy_file(source_path: str, destination_path: str) -> Dict[str, Any]:
    """Copies a file to a new destination."""
    src = Path(source_path).expanduser().resolve()
    dest = Path(destination_path).expanduser().resolve()
    if not src.exists():
        return {"status": "error", "error": f"Source '{source_path}' does not exist."}
    try:
        if src.is_dir():
            shutil.copytree(str(src), str(dest))
        else:
            shutil.copy2(str(src), str(dest))
        return {"status": "success", "message": f"Copied '{src}' to '{dest}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to copy: {e}"}


def delete_file(file_path: str) -> Dict[str, Any]:
    """Deletes a file permanently. Marked DANGEROUS - Requires confirmation."""
    path = Path(file_path).expanduser().resolve()
    if not path.exists():
        return {"status": "error", "error": f"File '{file_path}' does not exist."}
    if not path.is_file():
        return {"status": "error", "error": f"Path '{file_path}' is a directory, not a file. Use delete_folder."}
    try:
        path.unlink()
        return {"status": "success", "path": str(path), "message": f"Successfully deleted file '{path}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to delete file: {e}"}


def delete_folder(folder_path: str) -> Dict[str, Any]:
    """Deletes a directory and its contents permanently. Marked DANGEROUS - Requires confirmation."""
    path = Path(folder_path).expanduser().resolve()
    if not path.exists():
        return {"status": "error", "error": f"Folder '{folder_path}' does not exist."}
    if not path.is_dir():
        return {"status": "error", "error": f"Path '{folder_path}' is a file, not a folder."}
    try:
        shutil.rmtree(str(path))
        return {"status": "success", "path": str(path), "message": f"Successfully deleted directory '{path}'."}
    except Exception as e:
        return {"status": "error", "error": f"Failed to delete directory: {e}"}
