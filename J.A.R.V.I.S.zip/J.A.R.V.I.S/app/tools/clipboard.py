"""
Clipboard Read and Write Tools for JARVIS.
"""

from typing import Dict, Any
import pyperclip
from app.utils.logger import get_logger

logger = get_logger("Clipboard")


def clipboard_read() -> Dict[str, Any]:
    """Reads and returns the current text content from the Windows clipboard."""
    try:
        content = pyperclip.paste()
        return {
            "status": "success",
            "content": content,
            "length": len(content),
            "summary": f"Clipboard content: '{content[:200]}...'" if len(content) > 200 else f"Clipboard content: '{content}'"
        }
    except Exception as e:
        logger.error(f"Failed to read clipboard: {e}")
        return {"status": "error", "error": str(e)}


def clipboard_write(text: str) -> Dict[str, Any]:
    """Copies text into the Windows clipboard."""
    try:
        pyperclip.copy(text)
        return {
            "status": "success",
            "length": len(text),
            "message": f"Copied {len(text)} characters to clipboard."
        }
    except Exception as e:
        logger.error(f"Failed to write clipboard: {e}")
        return {"status": "error", "error": str(e)}
