"""
Date, Time, and Temporal Tools for JARVIS.
Provides current time, date, day of week, and timezone details.
"""

import time
from datetime import datetime
from typing import Dict, Any


def get_current_time() -> Dict[str, Any]:
    """Returns the current local time in 12-hour and 24-hour formats."""
    now = datetime.now()
    return {
        "time_12h": now.strftime("%I:%M:%S %p"),
        "time_24h": now.strftime("%H:%M:%S"),
        "timezone": time.tzname[0] if time.tzname else "Local",
        "timestamp_iso": now.isoformat(),
        "summary": f"The current time is {now.strftime('%I:%M %p')}."
    }


def get_current_date() -> Dict[str, Any]:
    """Returns the current date, day of the week, and formatted human date."""
    now = datetime.now()
    return {
        "date": now.strftime("%Y-%m-%d"),
        "day_of_week": now.strftime("%A"),
        "formatted": now.strftime("%A, %B %d, %Y"),
        "year": now.year,
        "month": now.strftime("%B"),
        "day": now.day,
        "summary": f"Today is {now.strftime('%A, %B %d, %Y')}."
    }
