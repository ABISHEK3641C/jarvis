"""
Built-in Tool Registration for JARVIS.
Registers all system, file, web, automation, math, and memory tools into the ToolManager.
"""

from typing import Optional
from app.core.tool_manager import ToolManager
from app.core.security import PermissionLevel
from app.core.memory import MemoryManager
from app.tools.calculator import calculate
from app.tools.datetime_tools import get_current_time, get_current_date
from app.tools.system_control import (
    get_system_information,
    get_cpu_usage,
    get_ram_usage,
    get_battery_status,
    volume_up,
    volume_down,
    mute_volume,
    unmute_volume,
    media_play_pause,
    media_next,
    media_previous,
    lock_workstation,
    shutdown_system,
    restart_system,
)
from app.tools.applications import (
    open_application,
    close_application,
    list_installed_applications,
    add_custom_application,
)
from app.tools.files import (
    search_files,
    read_file,
    create_file,
    create_folder,
    open_folder,
    rename_file,
    move_file,
    copy_file,
    delete_file,
    delete_folder,
)
from app.tools.web import search_web, search_youtube, launch_url
from app.tools.weather import get_weather
from app.tools.screenshot import take_screenshot
from app.tools.clipboard import clipboard_read, clipboard_write
from app.tools.input_automation import type_text, press_key


def register_all_tools(tool_mgr: ToolManager, memory_mgr: Optional[MemoryManager] = None):
    """Registers all built-in system tools and memory adapters into the ToolManager."""
    mem_mgr = memory_mgr or MemoryManager()

    # 1. Calculator
    tool_mgr.register_tool(
        name="calculate",
        description="Safely calculates mathematical expressions (+, -, *, /, %, ^, sqrt, sin, cos, round, pi, e).",
        parameters={
            "type": "object",
            "properties": {"expression": {"type": "string", "description": "The math expression, e.g. '25 * 4 + sqrt(144)'"}},
            "required": ["expression"],
        },
        handler=calculate,
        permission_level=PermissionLevel.SAFE,
        category="math",
    )

    # 2. DateTime
    tool_mgr.register_tool(
        name="get_current_time",
        description="Returns the current local time in 12-hour and 24-hour formats.",
        parameters={"type": "object", "properties": {}},
        handler=get_current_time,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )
    tool_mgr.register_tool(
        name="get_current_date",
        description="Returns today's date, day of week, and year.",
        parameters={"type": "object", "properties": {}},
        handler=get_current_date,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )

    # 3. System Telemetry & Control
    tool_mgr.register_tool(
        name="get_system_information",
        description="Retrieves a complete hardware status report (CPU, RAM, Disk, Battery, OS, IP).",
        parameters={"type": "object", "properties": {}},
        handler=get_system_information,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )
    tool_mgr.register_tool(
        name="get_cpu_usage",
        description="Returns current CPU load percentage and core count.",
        parameters={"type": "object", "properties": {}},
        handler=get_cpu_usage,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )
    tool_mgr.register_tool(
        name="get_ram_usage",
        description="Returns current RAM consumption, used bytes, and total capacity.",
        parameters={"type": "object", "properties": {}},
        handler=get_ram_usage,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )
    tool_mgr.register_tool(
        name="get_battery_status",
        description="Returns laptop battery percentage, power plug state, and remaining runtime.",
        parameters={"type": "object", "properties": {}},
        handler=get_battery_status,
        permission_level=PermissionLevel.SAFE,
        category="system",
    )
    tool_mgr.register_tool(
        name="volume_up",
        description="Increases Windows master audio volume.",
        parameters={"type": "object", "properties": {"steps": {"type": "integer", "description": "Number of volume steps (1-20)"}}},
        handler=volume_up,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="volume_down",
        description="Decreases Windows master audio volume.",
        parameters={"type": "object", "properties": {"steps": {"type": "integer", "description": "Number of volume steps (1-20)"}}},
        handler=volume_down,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="mute_volume",
        description="Mutes system audio.",
        parameters={"type": "object", "properties": {}},
        handler=mute_volume,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="unmute_volume",
        description="Unmutes system audio.",
        parameters={"type": "object", "properties": {}},
        handler=unmute_volume,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="media_play_pause",
        description="Toggles media Play/Pause across Spotify, YouTube, VLC, and Windows Media Player.",
        parameters={"type": "object", "properties": {}},
        handler=media_play_pause,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="media_next",
        description="Skips to next media track.",
        parameters={"type": "object", "properties": {}},
        handler=media_next,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="media_previous",
        description="Plays previous media track.",
        parameters={"type": "object", "properties": {}},
        handler=media_previous,
        permission_level=PermissionLevel.MODERATE,
        category="media",
    )
    tool_mgr.register_tool(
        name="lock_workstation",
        description="Locks the Windows screen immediately.",
        parameters={"type": "object", "properties": {}},
        handler=lock_workstation,
        permission_level=PermissionLevel.MODERATE,
        category="system",
    )
    tool_mgr.register_tool(
        name="shutdown_system",
        description="Schedules a safe Windows computer shutdown. Requires explicit confirmation.",
        parameters={"type": "object", "properties": {"timer_seconds": {"type": "integer", "description": "Delay in seconds (default 30)"}}},
        handler=shutdown_system,
        permission_level=PermissionLevel.DANGEROUS,
        category="system",
    )
    tool_mgr.register_tool(
        name="restart_system",
        description="Schedules a safe Windows reboot. Requires explicit confirmation.",
        parameters={"type": "object", "properties": {"timer_seconds": {"type": "integer", "description": "Delay in seconds (default 30)"}}},
        handler=restart_system,
        permission_level=PermissionLevel.DANGEROUS,
        category="system",
    )

    # 4. Applications
    tool_mgr.register_tool(
        name="open_application",
        description="Launches an installed Windows desktop application (e.g. Chrome, Notepad, VS Code, Discord, Spotify, Explorer).",
        parameters={
            "type": "object",
            "properties": {"app_name": {"type": "string", "description": "Name or executable of application to open"}},
            "required": ["app_name"],
        },
        handler=open_application,
        permission_level=PermissionLevel.MODERATE,
        category="apps",
    )
    tool_mgr.register_tool(
        name="close_application",
        description="Closes running instances of an application by name. Requires confirmation.",
        parameters={
            "type": "object",
            "properties": {"app_name": {"type": "string", "description": "Name of application to close (e.g. 'chrome', 'notepad')"}},
            "required": ["app_name"],
        },
        handler=close_application,
        permission_level=PermissionLevel.DANGEROUS,
        category="apps",
    )
    tool_mgr.register_tool(
        name="list_installed_applications",
        description="Lists detected installed applications from Windows Start Menu.",
        parameters={"type": "object", "properties": {"filter_name": {"type": "string", "description": "Optional search term to filter results"}}},
        handler=list_installed_applications,
        permission_level=PermissionLevel.SAFE,
        category="apps",
    )

    # 5. File System
    tool_mgr.register_tool(
        name="search_files",
        description="Searches user folders for files matching a pattern or extension (e.g. '*.pdf', '*.py', 'notes*').",
        parameters={
            "type": "object",
            "properties": {
                "pattern": {"type": "string", "description": "Search pattern or filename"},
                "search_dir": {"type": "string", "description": "Optional specific folder path to search"},
            },
            "required": ["pattern"],
        },
        handler=search_files,
        permission_level=PermissionLevel.SAFE,
        category="files",
    )
    tool_mgr.register_tool(
        name="read_file",
        description="Reads the text content of a file on disk.",
        parameters={
            "type": "object",
            "properties": {"file_path": {"type": "string", "description": "Absolute or relative path to file"}},
            "required": ["file_path"],
        },
        handler=read_file,
        permission_level=PermissionLevel.SAFE,
        category="files",
    )
    tool_mgr.register_tool(
        name="create_file",
        description="Creates a new text file with content.",
        parameters={
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Target file path"},
                "content": {"type": "string", "description": "Text content to write into file"},
            },
            "required": ["file_path"],
        },
        handler=create_file,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="create_folder",
        description="Creates a new folder directory.",
        parameters={
            "type": "object",
            "properties": {"folder_path": {"type": "string", "description": "Folder directory path to create"}},
            "required": ["folder_path"],
        },
        handler=create_folder,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="open_folder",
        description="Opens a folder in Windows File Explorer.",
        parameters={"type": "object", "properties": {"folder_path": {"type": "string", "description": "Path or alias (downloads, desktop, documents)"}}},
        handler=open_folder,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="rename_file",
        description="Renames an existing file or directory.",
        parameters={
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Path of file to rename"},
                "new_name": {"type": "string", "description": "New filename or folder name"},
            },
            "required": ["file_path", "new_name"],
        },
        handler=rename_file,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="move_file",
        description="Moves a file or folder to a new path.",
        parameters={
            "type": "object",
            "properties": {
                "source_path": {"type": "string", "description": "Source file path"},
                "destination_path": {"type": "string", "description": "Destination file path"},
            },
            "required": ["source_path", "destination_path"],
        },
        handler=move_file,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="copy_file",
        description="Copies a file or folder to a new path.",
        parameters={
            "type": "object",
            "properties": {
                "source_path": {"type": "string", "description": "Source file path"},
                "destination_path": {"type": "string", "description": "Destination file path"},
            },
            "required": ["source_path", "destination_path"],
        },
        handler=copy_file,
        permission_level=PermissionLevel.MODERATE,
        category="files",
    )
    tool_mgr.register_tool(
        name="delete_file",
        description="Permanently deletes a file. DANGEROUS - Requires user confirmation.",
        parameters={
            "type": "object",
            "properties": {"file_path": {"type": "string", "description": "File path to delete"}},
            "required": ["file_path"],
        },
        handler=delete_file,
        permission_level=PermissionLevel.DANGEROUS,
        category="files",
    )
    tool_mgr.register_tool(
        name="delete_folder",
        description="Permanently deletes a folder. DANGEROUS - Requires user confirmation.",
        parameters={
            "type": "object",
            "properties": {"folder_path": {"type": "string", "description": "Folder path to delete"}},
            "required": ["folder_path"],
        },
        handler=delete_folder,
        permission_level=PermissionLevel.DANGEROUS,
        category="files",
    )

    # 6. Web & Search
    tool_mgr.register_tool(
        name="search_web",
        description="Searches the live web using DuckDuckGo to find real-time information, documentation, and news.",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
                "max_results": {"type": "integer", "description": "Max results to return (default 5)"},
            },
            "required": ["query"],
        },
        handler=search_web,
        permission_level=PermissionLevel.SAFE,
        category="web",
    )
    tool_mgr.register_tool(
        name="search_youtube",
        description="Searches YouTube for videos and opens the results page in browser.",
        parameters={
            "type": "object",
            "properties": {"query": {"type": "string", "description": "YouTube search query"}},
            "required": ["query"],
        },
        handler=search_youtube,
        permission_level=PermissionLevel.MODERATE,
        category="web",
    )
    tool_mgr.register_tool(
        name="launch_url",
        description="Opens a website URL in the user's default browser.",
        parameters={
            "type": "object",
            "properties": {"url": {"type": "string", "description": "URL to open"}},
            "required": ["url"],
        },
        handler=launch_url,
        permission_level=PermissionLevel.MODERATE,
        category="web",
    )
    tool_mgr.register_tool(
        name="get_weather",
        description="Fetches live weather conditions, temperature, humidity, wind, and forecast for any city.",
        parameters={
            "type": "object",
            "properties": {"location": {"type": "string", "description": "City name (e.g. London, Tokyo, Bangalore, New York)"}},
        },
        handler=get_weather,
        permission_level=PermissionLevel.SAFE,
        category="weather",
    )

    # 7. Screenshot & Clipboard
    tool_mgr.register_tool(
        name="take_screenshot",
        description="Captures the desktop screen and saves it as an image.",
        parameters={"type": "object", "properties": {"filename": {"type": "string", "description": "Optional custom filename"}}},
        handler=take_screenshot,
        permission_level=PermissionLevel.MODERATE,
        category="automation",
    )
    tool_mgr.register_tool(
        name="clipboard_read",
        description="Reads the text currently stored in the Windows clipboard.",
        parameters={"type": "object", "properties": {}},
        handler=clipboard_read,
        permission_level=PermissionLevel.SAFE,
        category="clipboard",
    )
    tool_mgr.register_tool(
        name="clipboard_write",
        description="Copies specified text to the Windows clipboard.",
        parameters={
            "type": "object",
            "properties": {"text": {"type": "string", "description": "Text to copy"}},
            "required": ["text"],
        },
        handler=clipboard_write,
        permission_level=PermissionLevel.MODERATE,
        category="clipboard",
    )

    # 8. Input Automation
    tool_mgr.register_tool(
        name="type_text",
        description="Types text into the currently active desktop window.",
        parameters={
            "type": "object",
            "properties": {"text": {"type": "string", "description": "Text string to type"}},
            "required": ["text"],
        },
        handler=type_text,
        permission_level=PermissionLevel.MODERATE,
        category="automation",
    )
    tool_mgr.register_tool(
        name="press_key",
        description="Presses keyboard hotkeys or keys (e.g. 'enter', 'esc', 'ctrl+c', 'ctrl+v', 'alt+tab').",
        parameters={
            "type": "object",
            "properties": {"keys": {"type": "string", "description": "Key or combo string"}},
            "required": ["keys"],
        },
        handler=press_key,
        permission_level=PermissionLevel.MODERATE,
        category="automation",
    )

    # 9. Long-term Memory Tools
    def _remember_wrapper(key_fact: str, content: str, category: str = "facts"):
        return mem_mgr.remember(key_fact=key_fact, content=content, category=category)

    def _retrieve_wrapper(query: str, category: Optional[str] = None):
        res = mem_mgr.retrieve(query=query, category=category)
        return {"query": query, "count": len(res), "memories": res}

    def _forget_wrapper(identifier: str):
        deleted = mem_mgr.forget(identifier)
        return {"identifier": identifier, "deleted": deleted, "message": "Memory forgotten." if deleted else "Memory not found."}

    tool_mgr.register_tool(
        name="remember_information",
        description="Stores important user preferences, project details, facts, or instructions into persistent memory.",
        parameters={
            "type": "object",
            "properties": {
                "key_fact": {"type": "string", "description": "Short subject/topic (e.g. 'favorite editor', 'project name')"},
                "content": {"type": "string", "description": "Detailed fact or preference to remember"},
                "category": {"type": "string", "enum": ["preferences", "projects", "facts", "instructions"], "description": "Category"},
            },
            "required": ["key_fact", "content"],
        },
        handler=_remember_wrapper,
        permission_level=PermissionLevel.MODERATE,
        category="memory",
    )
    tool_mgr.register_tool(
        name="retrieve_memory",
        description="Searches persistent long-term memory for remembered facts, user preferences, or project details.",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Keyword or topic to search"},
                "category": {"type": "string", "description": "Optional category filter"},
            },
            "required": ["query"],
        },
        handler=_retrieve_wrapper,
        permission_level=PermissionLevel.SAFE,
        category="memory",
    )
    tool_mgr.register_tool(
        name="forget_memory",
        description="Deletes a stored memory fact by key or ID. Requires confirmation.",
        parameters={
            "type": "object",
            "properties": {"identifier": {"type": "string", "description": "Memory key or ID to forget"}},
            "required": ["identifier"],
        },
        handler=_forget_wrapper,
        permission_level=PermissionLevel.DANGEROUS,
        category="memory",
    )
