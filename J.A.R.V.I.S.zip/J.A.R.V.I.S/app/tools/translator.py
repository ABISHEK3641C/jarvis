"""
Free Language Translation Tool for JARVIS.
Uses MyMemory translation API (free, no API key required, 5000 words/day).
Supports 30+ common languages via ISO 639-1 codes.
"""

import re
from typing import Dict, Any
import requests
from app.utils.logger import get_logger

logger = get_logger("Translator")


# Friendly names → ISO 639-1 codes that MyMemory accepts.
LANGUAGE_ALIASES = {
    "english": "en", "spanish": "es", "french": "fr", "german": "de",
    "hindi": "hi", "italian": "it", "portuguese": "pt", "russian": "ru",
    "japanese": "ja", "chinese": "zh-CN", "korean": "ko", "arabic": "ar",
    "turkish": "tr", "dutch": "nl", "greek": "el", "polish": "pl",
    "swedish": "sv", "norwegian": "no", "danish": "da", "finnish": "fi",
    "czech": "cs", "hungarian": "hu", "romanian": "ro", "thai": "th",
    "vietnamese": "vi", "indonesian": "id", "malay": "ms", "ukrainian": "uk",
    "hebrew": "iw", "bengali": "bn", "tamil": "ta", "telugu": "te",
}


def _resolve_lang_code(name_or_code: str) -> str:
    """Resolves a friendly language name or ISO code to ISO 639-1."""
    if not name_or_code:
        return ""
    s = name_or_code.strip().lower()
    if s in LANGUAGE_ALIASES:
        return LANGUAGE_ALIASES[s]
    # Allow direct code passthrough (en, es, fr, hi, zh-CN, etc.)
    return name_or_code.strip()


def translate_text(text: str, target_lang: str = "es", source_lang: str = "en") -> Dict[str, Any]:
    """
    Translates text to the target language using MyMemory's free public endpoint.
    Returns a structured dict with status, source/target text, languages, and a summary.
    """
    if not text or not text.strip():
        return {"status": "error", "error": "Empty text provided."}

    src = _resolve_lang_code(source_lang) or "en"
    tgt = _resolve_lang_code(target_lang)
    if not tgt:
        return {"status": "error", "error": f"Unknown target language '{target_lang}'."}

    if src == tgt:
        return {
            "status": "success",
            "source_text": text,
            "translated_text": text,
            "source_lang": src,
            "target_lang": tgt,
            "summary": f"Source and target languages are the same ({tgt}); no translation needed.",
        }

    try:
        url = "https://api.mymemory.translated.net/get"
        params = {"q": text[:500], "langpair": f"{src}|{tgt}"}
        resp = requests.get(url, params=params, timeout=6.0)
        if resp.status_code != 200:
            return {"status": "error", "error": f"Translator returned HTTP {resp.status_code}."}

        data = resp.json()
        translated = (data.get("responseData") or {}).get("translatedText", "")
        if not translated:
            return {"status": "error", "error": "Translation service returned no result."}

        # MyMemory HTML-escapes its output — decode common entities.
        translated = (
            translated.replace("&#39;", "'")
            .replace("&quot;", '"')
            .replace("&amp;", "&")
            .replace("&lt;", "<")
            .replace("&gt;", ">")
        )

        return {
            "status": "success",
            "source_text": text,
            "translated_text": translated,
            "source_lang": src,
            "target_lang": tgt,
            "summary": f"Translated from {src} to {tgt}: \"{translated}\"",
        }
    except Exception as e:
        logger.error(f"Translation failed: {e}")
        return {"status": "error", "error": f"Translation failed: {e}"}
