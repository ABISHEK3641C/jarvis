"""
Safe Keyboard and Input Automation Tools for JARVIS.
Allows typing text into active windows and pressing standard keyboard shortcuts.
"""

import time
from typing import Dict, Any, List
import pyautogui
from app.utils.logger import get_logger

logger = get_logger("InputAutomation")

# Safety pause
pyautogui.PAUSE = 0.05
pyautogui.FAILSAFE = True


def type_text(text: str, interval: float = 0.02) -> Dict[str, Any]:
    """
    Types the given text into the currently active desktop window.
    """
    try:
        time.sleep(0.3)  # Brief delay to allow window focus
        pyautogui.write(text, interval=interval)
        return {"status": "success", "length": len(text), "message": f"Typed {len(text)} characters into active window."}
    except Exception as e:
        logger.error(f"Failed to type text: {e}")
        return {"status": "error", "error": str(e)}


def press_key(keys: str) -> Dict[str, Any]:
    """
    Presses a key or hotkey combination (e.g. 'enter', 'esc', 'ctrl+c', 'ctrl+v', 'alt+tab', 'win+d').
    """
    try:
        parts = [k.strip().lower() for k in keys.split("+")]
        if len(parts) == 1:
            pyautogui.press(parts[0])
        else:
            pyautogui.hotkey(*parts)
        return {"status": "success", "keys": keys, "message": f"Triggered key combination '{keys}'."}
    except Exception as e:
        logger.error(f"Failed to press keys '{keys}': {e}")
        return {"status": "error", "error": str(e)}
