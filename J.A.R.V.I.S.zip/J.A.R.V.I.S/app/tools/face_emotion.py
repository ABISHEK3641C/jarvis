"""
JARVIS Face Recognition & Emotion Detection Module.
Uses pure OpenCV (no TensorFlow/DeepFace required).

Face detection: OpenCV Haar Cascade (built-in, zero dependency)
Emotion scoring: Facial landmark geometry heuristics + histogram analysis
                 (lightweight, runs at 30fps on any CPU)

If DeepFace is available (optional), it is used for higher accuracy.
"""

import threading
import time
import random
import math
from typing import Optional, Callable, Dict, Any
from app.utils.logger import get_logger

logger = get_logger("FaceEmotion")

# --------------------------------------------------------------------------
# Caring JARVIS responses per detected emotion (girlfriend-style)
# --------------------------------------------------------------------------
EMOTION_RESPONSES: Dict[str, list] = {
    "sad": [
        "Hey, I noticed you look a little down. Do you want to talk about it? I'm right here.",
        "You don't seem like your usual self. Is everything okay? I'm here for you, sir.",
        "You look sad. Would you like me to play some music, or would you rather just talk?",
        "I'm worried about you. Take a deep breath. Want to tell me what's going on?",
    ],
    "angry": [
        "You look a bit frustrated right now. Take a breath — I'm here to help.",
        "I can see something is bothering you. Want me to help sort it out?",
        "You seem upset. Want me to close some apps and play something calming for you?",
        "Hey, it's okay to feel angry. Talk to me — what happened?",
    ],
    "fear": [
        "You look a little worried. Hey, I'm right here with you — it's okay.",
        "Whatever it is, we'll handle it together. What's going on?",
        "You seem anxious. Take a deep breath. I've got you, sir.",
    ],
    "surprise": [
        "Whoa, you look surprised! Good news or bad? Tell me everything!",
        "Something caught you off guard! What happened? I'm curious!",
        "That looks like quite a surprise! What's going on?",
    ],
    "happy": [
        "You're looking amazing and happy today! That genuinely makes me happy too!",
        "Love seeing that smile! Great energy today — whatever you're doing, keep it up!",
        "You seem really happy right now. Care to share the good news with me?",
        "That smile looks great on you! What's making you so happy today?",
    ],
    "neutral": [],
    "disgust": [
        "Ew, something's bothering you? Tell me and I'll see what I can do!",
        "You don't look too pleased. What's wrong? Maybe I can help.",
    ],
}

# Minimum seconds between two emotion-triggered responses (avoid spam)
EMOTION_COOLDOWN_SEC = 50


class FaceEmotionWorker(threading.Thread):
    """
    Continuously captures webcam frames, detects faces with OpenCV,
    estimates emotion using geometric + histogram heuristics (no ML needed),
    and optionally upgrades to DeepFace if available.
    """

    def __init__(
        self,
        on_emotion_detected: Optional[Callable[[str, float], None]] = None,
        on_frame_ready: Optional[Callable[[Any], None]] = None,
        camera_index: int = 0,
        analysis_interval: float = 2.5,
    ):
        super().__init__(daemon=True, name="FaceEmotionWorker")
        self.on_emotion_detected = on_emotion_detected
        self.on_frame_ready = on_frame_ready
        self.camera_index = camera_index
        self.analysis_interval = analysis_interval

        self._is_running = False
        self._last_emotion: str = ""
        self._last_emotion_time: float = 0.0
        self.current_emotion: str = "neutral"
        self.current_confidence: float = 0.0
        self.face_detected: bool = False

        # Optional DeepFace
        self._deepface_available = False
        try:
            from deepface import DeepFace  # noqa
            self._deepface_available = True
            logger.info("DeepFace available — using high-accuracy emotion analysis.")
        except Exception:
            logger.info("DeepFace not installed — using built-in OpenCV emotion heuristics.")

    def stop(self):
        self._is_running = False

    # ------------------------------------------------------------------
    # Lightweight emotion estimation from face ROI (pure OpenCV/NumPy)
    # ------------------------------------------------------------------
    @staticmethod
    def _estimate_emotion_opencv(face_roi_gray) -> tuple[str, float]:
        """
        Estimates dominant emotion from grayscale face ROI using:
        - Mean brightness (happy faces tend brighter in lower-half)
        - Gradient intensity (angry/fear = high edge activity around brows)
        - Vertical vs horizontal gradient ratio (surprise = vertical dominant)
        Returns (emotion_label, confidence_0_to_100)
        """
        import cv2
        import numpy as np

        h, w = face_roi_gray.shape
        if h < 20 or w < 20:
            return "neutral", 0.0

        face_roi_gray = cv2.resize(face_roi_gray, (64, 64))
        h, w = 64, 64

        # Split into regions
        upper = face_roi_gray[:h // 2, :]      # brow / eyes
        lower = face_roi_gray[h // 2:, :]      # nose / mouth

        mean_upper = float(np.mean(upper))
        mean_lower = float(np.mean(lower))

        # Edge density (Sobel)
        grad_x = cv2.Sobel(face_roi_gray, cv2.CV_32F, 1, 0, ksize=3)
        grad_y = cv2.Sobel(face_roi_gray, cv2.CV_32F, 0, 1, ksize=3)
        edge_intensity = float(np.mean(np.abs(grad_x) + np.abs(grad_y)))
        h_dominance = float(np.mean(np.abs(grad_x))) / (float(np.mean(np.abs(grad_y))) + 1e-5)
        v_dominance = float(np.mean(np.abs(grad_y))) / (float(np.mean(np.abs(grad_x))) + 1e-5)

        # Mouth region brightness variance (smile = high variance in lower third)
        mouth = face_roi_gray[int(h * 0.65):, :]
        mouth_var = float(np.var(mouth))

        # Scoring heuristics
        scores: Dict[str, float] = {
            "happy":   min(100, mouth_var / 4.0 + max(0, mean_lower - mean_upper) * 0.5),
            "angry":   min(100, edge_intensity * 0.6 + max(0, mean_upper - mean_lower) * 0.4),
            "surprise": min(100, v_dominance * 30 + edge_intensity * 0.3),
            "sad":     min(100, max(0, 120 - mean_lower) * 0.6 + max(0, mean_upper - mean_lower) * 0.3),
            "fear":    min(100, edge_intensity * 0.4 + v_dominance * 20),
            "neutral": 30.0,
        }

        dominant = max(scores, key=scores.get)
        confidence = scores[dominant]

        # Only report non-neutral if clearly dominant
        if dominant == "neutral" or confidence < 35:
            return "neutral", confidence
        return dominant, min(confidence, 95.0)

    def run(self):
        try:
            import cv2
        except ImportError:
            logger.error("OpenCV not installed. Run: pip install opencv-python")
            return

        import numpy as np

        cap = cv2.VideoCapture(self.camera_index)
        if not cap.isOpened():
            logger.error(f"Cannot open camera index {self.camera_index}")
            return

        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
        cap.set(cv2.CAP_PROP_FPS, 30)

        face_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
        )
        eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_eye.xml"
        )

        self._is_running = True
        last_analysis_time = 0.0
        logger.info("Face & Emotion worker started (OpenCV mode).")

        while self._is_running:
            ret, frame = cap.read()
            if not ret:
                time.sleep(0.05)
                continue

            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.equalizeHist(gray)

            faces = face_cascade.detectMultiScale(
                gray, scaleFactor=1.1, minNeighbors=5, minSize=(80, 80)
            )
            self.face_detected = len(faces) > 0

            # Draw face boxes, eye dots and emotion label
            for (x, y, w, h) in faces:
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 229, 255), 2)

                # Detect eyes inside face ROI
                face_gray_roi = gray[y:y + h, x:x + w]
                eyes = eye_cascade.detectMultiScale(face_gray_roi, scaleFactor=1.1, minNeighbors=5)
                for (ex, ey, ew, eh) in eyes[:2]:
                    eye_center = (x + ex + ew // 2, y + ey + eh // 2)
                    cv2.circle(frame, eye_center, 4, (0, 229, 255), -1)

                if self.current_emotion and self.current_emotion != "neutral":
                    label = f"{self.current_emotion.upper()}  {self.current_confidence:.0f}%"
                    cv2.putText(frame, label, (x, y - 12),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.65, (0, 229, 255), 2)

            # Status overlay
            face_txt = "● FACE DETECTED" if self.face_detected else "Searching for face..."
            cv2.putText(frame, f"JARVIS VISION  |  {face_txt}",
                        (10, 24), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0, 229, 255), 2)

            if self.on_frame_ready:
                self.on_frame_ready(frame)

            # Emotion analysis at interval
            now = time.time()
            if self.face_detected and (now - last_analysis_time) >= self.analysis_interval:
                last_analysis_time = now
                dominant, confidence = "neutral", 0.0

                # Try DeepFace first if available
                if self._deepface_available:
                    try:
                        from deepface import DeepFace
                        result = DeepFace.analyze(
                            img_path=frame, actions=["emotion"],
                            enforce_detection=False, silent=True,
                        )
                        if isinstance(result, list):
                            result = result[0]
                        dominant = result.get("dominant_emotion", "neutral")
                        confidence = result.get("emotion", {}).get(dominant, 0.0)
                    except Exception as e:
                        logger.debug(f"DeepFace error: {e}")
                        dominant, confidence = "neutral", 0.0

                # Fallback to pure OpenCV heuristics
                if dominant == "neutral" or confidence < 40:
                    fx, fy, fw, fh = faces[0]
                    face_roi = gray[fy:fy + fh, fx:fx + fw]
                    dominant, confidence = self._estimate_emotion_opencv(face_roi)

                self.current_emotion = dominant
                self.current_confidence = confidence

                emotion_changed = (dominant != self._last_emotion and dominant != "neutral")
                cooldown_ok = (now - self._last_emotion_time) >= EMOTION_COOLDOWN_SEC

                if emotion_changed and cooldown_ok and confidence >= 38.0:
                    self._last_emotion = dominant
                    self._last_emotion_time = now
                    logger.info(f"Emotion detected: {dominant} ({confidence:.1f}%)")
                    if self.on_emotion_detected:
                        self.on_emotion_detected(dominant, confidence)

            time.sleep(0.033)

        cap.release()
        logger.info("Face & Emotion worker stopped.")
