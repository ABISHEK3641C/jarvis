"""
Screenshot Capture and Vision Tools for JARVIS.
Captures screen images, saves to disk, and prepares base64 encoding for multimodal vision models.
"""

import os
import base64
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime
from PIL import ImageGrab
from app.config import DATA_DIR
from app.utils.logger import get_logger

logger = get_logger("Screenshot")

SCREENSHOTS_DIR = DATA_DIR / "screenshots"
SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)


def take_screenshot(filename: Optional[str] = None) -> Dict[str, Any]:
    """
    Captures the primary monitor display and saves it to data/screenshots.
    """
    try:
        now_str = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = filename or f"screenshot_{now_str}.png"
        if not fname.endswith(".png"):
            fname += ".png"

        save_path = SCREENSHOTS_DIR / fname
        img = ImageGrab.grab()
        img.save(str(save_path), "PNG")

        logger.info(f"Captured screenshot: {save_path}")
        return {
            "status": "success",
            "filename": fname,
            "path": str(save_path),
            "width": img.width,
            "height": img.height,
            "message": f"Screenshot saved to {save_path}.",
        }
    except Exception as e:
        logger.error(f"Failed to capture screenshot: {e}")
        return {"status": "error", "error": f"Screenshot failed: {e}"}


def get_latest_screenshot_base64() -> Optional[str]:
    """Returns base64 string of the most recent screenshot for vision processing."""
    try:
        files = list(SCREENSHOTS_DIR.glob("*.png"))
        if not files:
            return None
        latest = max(files, key=lambda f: f.stat().st_mtime)
        with open(latest, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode("utf-8")
    except Exception as e:
        logger.error(f"Failed to encode screenshot: {e}")
        return None
