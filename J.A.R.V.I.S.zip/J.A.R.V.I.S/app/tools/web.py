"""
Web Search and URL Navigation Tools for JARVIS.
Integrates live web searching via DuckDuckGo, DuckDuckGo Instant Answer API, Wikipedia, and browser navigation.
"""

import webbrowser
import urllib.parse
import requests
from typing import Dict, Any, List, Optional
from app.utils.logger import get_logger

logger = get_logger("Web")


def _search_duckduckgo_api(query: str) -> Optional[Dict[str, Any]]:
    """Fetches instant answers from DuckDuckGo's public JSON API."""
    try:
        url = "https://api.duckduckgo.com/"
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
        params = {"q": query, "format": "json", "no_html": 1, "skip_disambig": 1}
        resp = requests.get(url, params=params, headers=headers, timeout=4.0)
        if resp.status_code == 200:
            data = resp.json()
            abstract = data.get("AbstractText", "")
            heading = data.get("Heading", query)
            source_url = data.get("AbstractURL", "")
            if abstract:
                return {
                    "title": heading,
                    "url": source_url or f"https://duckduckgo.com/?q={urllib.parse.quote_plus(query)}",
                    "snippet": abstract,
                }
    except Exception as e:
        logger.debug(f"DDG Instant Answer error: {e}")
    return None


def _search_wikipedia_api(query: str) -> Optional[Dict[str, Any]]:
    """Fetches Wikipedia article summary for the query."""
    try:
        search_url = "https://en.wikipedia.org/w/api.php"
        headers = {"User-Agent": "JarvisDesktopAssistant/1.0 (Personal AI System)"}
        params = {
            "action": "query",
            "list": "search",
            "srsearch": query,
            "format": "json",
            "srlimit": 1,
        }
        resp = requests.get(search_url, params=params, headers=headers, timeout=4.0)
        if resp.status_code == 200:
            data = resp.json()
            search_items = data.get("query", {}).get("search", [])
            if search_items:
                item = search_items[0]
                page_title = item.get("title")
                snippet = item.get("snippet", "").replace('<span class="searchmatch">', "").replace("</span>", "")
                page_url = f"https://en.wikipedia.org/wiki/{urllib.parse.quote(page_title.replace(' ', '_'))}"
                return {
                    "title": f"Wikipedia: {page_title}",
                    "url": page_url,
                    "snippet": snippet,
                }
    except Exception as e:
        logger.debug(f"Wikipedia search error: {e}")
    return None


def search_web(query: str, max_results: int = 5) -> Dict[str, Any]:
    """
    Performs a real-time web search.
    Uses DDGS, DDG Instant Answers, and Wikipedia APIs with fallback to direct browser URL.
    """
    clean_query = query.strip()
    formatted_results = []

    # 1. Try DDGS
    try:
        try:
            from ddgs import DDGS
        except ImportError:
            from duckduckgo_search import DDGS

        ddgs_client = DDGS()
        raw_results = list(ddgs_client.text(clean_query, max_results=max_results))
        for r in raw_results:
            formatted_results.append({
                "title": r.get("title", ""),
                "url": r.get("href", ""),
                "snippet": r.get("body", ""),
            })
    except Exception as e:
        logger.debug(f"DDGS text search failed: {e}")

    # 2. If results empty, query DuckDuckGo Instant Answer API
    if not formatted_results:
        ddg_answer = _search_duckduckgo_api(clean_query)
        if ddg_answer:
            formatted_results.append(ddg_answer)

    # 3. If still empty, query Wikipedia API
    if not formatted_results:
        wiki_answer = _search_wikipedia_api(clean_query)
        if wiki_answer:
            formatted_results.append(wiki_answer)

    # 4. If any results found, construct clean summary
    if formatted_results:
        summary_lines = [f"• {r['title']} - {r['snippet']}" for r in formatted_results]
        return {
            "query": clean_query,
            "count": len(formatted_results),
            "results": formatted_results,
            "summary": "\n".join(summary_lines),
        }

    # 5. Final fallback
    search_url = f"https://www.google.com/search?q={urllib.parse.quote_plus(clean_query)}"
    return {
        "query": clean_query,
        "count": 0,
        "results": [],
        "fallback_url": search_url,
        "summary": f"No direct search summary found. Live search results available at: {search_url}",
    }


def search_youtube(query: str) -> Dict[str, Any]:
    """Searches YouTube for the query and opens the results page in the default web browser."""
    clean_query = query.strip()
    encoded = urllib.parse.quote_plus(clean_query)
    yt_url = f"https://www.youtube.com/results?search_query={encoded}"
    webbrowser.open(yt_url)
    return {
        "query": clean_query,
        "url": yt_url,
        "message": f"Opened YouTube search for '{clean_query}' in your browser."
    }


def launch_url(url: str) -> Dict[str, Any]:
    """Opens a website URL in the user's default web browser."""
    clean_url = url.strip()
    if not clean_url.startswith("http://") and not clean_url.startswith("https://"):
        clean_url = f"https://{clean_url}"

    try:
        webbrowser.open(clean_url)
        return {"status": "success", "url": clean_url, "message": f"Opened {clean_url} in browser."}
    except Exception as e:
        return {"status": "error", "url": clean_url, "error": f"Failed to launch browser: {e}"}
