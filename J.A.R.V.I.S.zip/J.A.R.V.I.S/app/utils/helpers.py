"""
Common helper functions for JARVIS.
Includes formatting, string sanitization, asynchronous thread launchers, and path utilities.
"""

import os
import re
import threading
from typing import Callable, Any, Optional
from datetime import datetime


def format_bytes(size_in_bytes: float) -> str:
    """Formats raw bytes into a human-readable string (KB, MB, GB, TB)."""
    if size_in_bytes < 0:
        return "0 B"
    units = ["B", "KB", "MB", "GB", "TB", "PB"]
    unit_index = 0
    size = float(size_in_bytes)
    while size >= 1024.0 and unit_index < len(units) - 1:
        size /= 1024.0
        unit_index += 1
    return f"{size:.2f} {units[unit_index]}"


def sanitize_filename(filename: str) -> str:
    """Removes invalid Windows filesystem characters from a filename."""
    # Invalid characters in Windows: \ / : * ? " < > |
    sanitized = re.sub(r'[\\/*?:"<>|]', "", filename)
    return sanitized.strip()


def run_in_thread(target: Callable, args: tuple = (), kwargs: Optional[dict] = None, daemon: bool = True) -> threading.Thread:
    """Runs a callable function inside a separate background thread."""
    if kwargs is None:
        kwargs = {}
    thread = threading.Thread(target=target, args=args, kwargs=kwargs, daemon=daemon)
    thread.start()
    return thread


def get_current_timestamp() -> str:
    """Returns current ISO formatted datetime string."""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def truncate_text(text: str, max_length: int = 120) -> str:
    """Truncates text safely with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."
