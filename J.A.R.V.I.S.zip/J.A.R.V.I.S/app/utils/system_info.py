"""
System telemetry and hardware monitoring utilities.
Uses psutil to collect live metrics on CPU, RAM, Disk, Battery, Network, and OS details.
Provides a PySide6 QThread worker to stream continuous telemetry to the GUI without UI blocking.
"""

import sys
import platform
import socket
import psutil
from typing import Dict, Any, Optional
from datetime import datetime
from PySide6.QtCore import QThread, Signal
from app.utils.logger import get_logger
from app.utils.helpers import format_bytes

logger = get_logger("SystemInfo")


def get_system_snapshot() -> Dict[str, Any]:
    """
    Collects a comprehensive instantaneous snapshot of system metrics.
    Safe on all machines, including desktops without batteries.
    """
    snapshot = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "os": f"{platform.system()} {platform.release()} ({platform.version()})",
        "hostname": socket.gethostname(),
        "python_version": sys.version.split()[0],
        "cpu_percent": 0.0,
        "cpu_count": psutil.cpu_count(logical=True) or 1,
        "cpu_freq_mhz": 0.0,
        "ram_total_bytes": 0,
        "ram_used_bytes": 0,
        "ram_percent": 0.0,
        "disk_total_bytes": 0,
        "disk_used_bytes": 0,
        "disk_percent": 0.0,
        "battery_percent": None,
        "battery_power_plugged": None,
        "battery_time_left_secs": None,
        "network_connected": False,
        "ip_address": "127.0.0.1",
    }

    try:
        # CPU
        snapshot["cpu_percent"] = psutil.cpu_percent(interval=None)
        cpu_freq = psutil.cpu_freq()
        if cpu_freq:
            snapshot["cpu_freq_mhz"] = round(cpu_freq.current, 1)

        # RAM
        virtual_mem = psutil.virtual_memory()
        snapshot["ram_total_bytes"] = virtual_mem.total
        snapshot["ram_used_bytes"] = virtual_mem.used
        snapshot["ram_percent"] = virtual_mem.percent

        # Disk (Primary system drive)
        disk_usage = psutil.disk_usage("C:\\" if platform.system() == "Windows" else "/")
        snapshot["disk_total_bytes"] = disk_usage.total
        snapshot["disk_used_bytes"] = disk_usage.used
        snapshot["disk_percent"] = disk_usage.percent

        # Battery
        if hasattr(psutil, "sensors_battery"):
            battery = psutil.sensors_battery()
            if battery:
                snapshot["battery_percent"] = round(battery.percent, 1)
                snapshot["battery_power_plugged"] = battery.power_plugged
                snapshot["battery_time_left_secs"] = battery.secsleft if battery.secsleft != psutil.POWER_TIME_UNLIMITED else None

        # Network Check
        try:
            # Quick DNS socket probe to 8.8.8.8 to verify internet connectivity
            test_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            test_socket.settimeout(0.5)
            test_socket.connect(("8.8.8.8", 53))
            snapshot["ip_address"] = test_socket.getsockname()[0]
            test_socket.close()
            snapshot["network_connected"] = True
        except Exception:
            snapshot["network_connected"] = False

    except Exception as e:
        logger.warning(f"Error gathering system telemetry: {e}")

    return snapshot


class SystemMonitorWorker(QThread):
    """Background QThread that continuously polls system statistics and emits updates."""
    metrics_updated = Signal(dict)

    def __init__(self, interval_seconds: float = 2.0, parent=None):
        super().__init__(parent)
        self.interval_seconds = max(0.5, interval_seconds)
        self._is_running = True

    def run(self):
        # Initial cpu_percent call to prime the counter
        psutil.cpu_percent(interval=None)
        while self._is_running:
            try:
                metrics = get_system_snapshot()
                self.metrics_updated.emit(metrics)
            except Exception as e:
                logger.error(f"Error in SystemMonitorWorker: {e}")
            self.msleep(int(self.interval_seconds * 1000))

    def stop(self):
        """Stops the worker thread cleanly."""
        self._is_running = False
        self.wait(1500)
