"""
Centralized logging facility for JARVIS.
Outputs formatted logs to console and rotating log file at logs/jarvis.log.
"""

import sys
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from app.config import LOG_FILE_PATH, LOGS_DIR

# Ensure logs directory exists
LOGS_DIR.mkdir(parents=True, exist_ok=True)

# Standard Log Formatter
LOG_FORMAT = "%(asctime)s [%(levelname)s] [%(name)s:%(lineno)d] - %(message)s"
DATE_FORMAT = "%Y-%m-%d %H:%M:%S"


def setup_logger(name: str = "JARVIS", level: int = logging.INFO) -> logging.Logger:
    """Sets up and returns a configured logger instance."""
    logger_instance = logging.getLogger(name)
    logger_instance.setLevel(level)

    # Avoid duplicate handlers if setup is called multiple times
    if not logger_instance.handlers:
        formatter = logging.Formatter(LOG_FORMAT, datefmt=DATE_FORMAT)

        # Rotating file handler (Max 5MB per file, keep 5 backups)
        file_handler = RotatingFileHandler(
            LOG_FILE_PATH,
            maxBytes=5 * 1024 * 1024,
            backupCount=5,
            encoding="utf-8"
        )
        file_handler.setLevel(level)
        file_handler.setFormatter(formatter)
        logger_instance.addHandler(file_handler)

        # Console Stream Handler with UTF-8 safe output
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(level)
        console_handler.setFormatter(formatter)
        logger_instance.addHandler(console_handler)

    return logger_instance


# Root application logger instance
logger = setup_logger()


def get_logger(module_name: str) -> logging.Logger:
    """Returns a child logger scoped to the specified module name."""
    return logging.getLogger(f"JARVIS.{module_name}")
