"""
Note Taker Plugin for JARVIS.
Allows quick note taking and memo management stored in data/notes.
"""

from pathlib import Path
from typing import List, Dict, Any
from datetime import datetime
from app.core.plugin_base import BasePlugin, PluginTool
from app.core.security import PermissionLevel
from app.config import DATA_DIR

NOTES_DIR = DATA_DIR / "notes"
NOTES_DIR.mkdir(parents=True, exist_ok=True)


class NoteTakerPlugin(BasePlugin):
    """Plugin to save and read quick notes."""

    @property
    def name(self) -> str:
        return "NoteTaker"

    @property
    def description(self) -> str:
        return "Allows JARVIS to manage quick notes and memos."

    @property
    def version(self) -> str:
        return "1.0.0"

    def take_note(self, title: str, content: str) -> Dict[str, Any]:
        """Creates or appends to a named note."""
        clean_title = "".join(c for c in title if c.isalnum() or c in (" ", "_", "-")).strip()
        if not clean_title:
            clean_title = "QuickNote"
        note_file = NOTES_DIR / f"{clean_title}.txt"
        now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        entry = f"\n--- [{now_str}] ---\n{content.strip()}\n"

        with open(note_file, "a", encoding="utf-8") as f:
            f.write(entry)

        return {
            "status": "success",
            "title": clean_title,
            "path": str(note_file),
            "message": f"Saved note '{clean_title}'."
        }

    def list_notes(self) -> Dict[str, Any]:
        """Lists all existing notes in data/notes."""
        notes = [f.stem for f in NOTES_DIR.glob("*.txt")]
        return {
            "count": len(notes),
            "notes": notes,
            "summary": f"Found {len(notes)} note(s): {', '.join(notes)}" if notes else "No notes found."
        }

    def read_note(self, title: str) -> Dict[str, Any]:
        """Reads the content of a saved note."""
        clean_title = "".join(c for c in title if c.isalnum() or c in (" ", "_", "-")).strip()
        note_file = NOTES_DIR / f"{clean_title}.txt"
        if not note_file.exists():
            return {"status": "error", "error": f"Note '{title}' does not exist."}
        content = note_file.read_text(encoding="utf-8")
        return {
            "status": "success",
            "title": clean_title,
            "content": content,
        }

    def get_tools(self) -> List[PluginTool]:
        return [
            PluginTool(
                name="take_note",
                description="Saves a quick note or memo to disk.",
                parameters_schema={
                    "type": "object",
                    "properties": {
                        "title": {"type": "string", "description": "Title or subject of the note"},
                        "content": {"type": "string", "description": "Note content"},
                    },
                    "required": ["title", "content"],
                },
                handler=self.take_note,
                permission_level=PermissionLevel.MODERATE,
            ),
            PluginTool(
                name="list_notes",
                description="Lists all saved notes.",
                parameters_schema={"type": "object", "properties": {}},
                handler=self.list_notes,
                permission_level=PermissionLevel.SAFE,
            ),
            PluginTool(
                name="read_note",
                description="Reads the text content of a note.",
                parameters_schema={
                    "type": "object",
                    "properties": {"title": {"type": "string", "description": "Title of note to read"}},
                    "required": ["title"],
                },
                handler=self.read_note,
                permission_level=PermissionLevel.SAFE,
            ),
        ]
