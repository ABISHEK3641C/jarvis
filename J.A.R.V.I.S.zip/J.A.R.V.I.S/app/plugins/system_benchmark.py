"""
System Benchmark Plugin for JARVIS.
Performs quick mathematical compute test to measure processor performance.
"""

import time
import math
from typing import List, Dict, Any
from app.core.plugin_base import BasePlugin, PluginTool
from app.core.security import PermissionLevel


class SystemBenchmarkPlugin(BasePlugin):
    """Plugin to run quick diagnostic benchmarks."""

    @property
    def name(self) -> str:
        return "SystemBenchmark"

    @property
    def description(self) -> str:
        return "Runs diagnostic benchmarks to assess machine speed."

    @property
    def version(self) -> str:
        return "1.0.0"

    def run_benchmark(self, iterations: int = 500000) -> Dict[str, Any]:
        """Runs a fast CPU arithmetic test and returns the execution duration and score."""
        count = max(100000, min(iterations, 2000000))
        start = time.perf_counter()

        # Simple math loop
        val = 0.0
        for i in range(1, count + 1):
            val += math.sqrt(i) * math.sin(i)

        elapsed = time.perf_counter() - start
        ops_per_sec = round(count / max(elapsed, 0.0001))
        score = round(ops_per_sec / 10000)

        return {
            "iterations": count,
            "duration_seconds": round(elapsed, 4),
            "operations_per_second": ops_per_sec,
            "benchmark_score": score,
            "summary": f"Benchmark complete: {count:,} mathematical ops completed in {round(elapsed, 3)}s (Rating: {score} pts)."
        }

    def get_tools(self) -> List[PluginTool]:
        return [
            PluginTool(
                name="run_cpu_benchmark",
                description="Runs a fast single-core CPU diagnostic benchmark test.",
                parameters_schema={
                    "type": "object",
                    "properties": {"iterations": {"type": "integer", "description": "Number of test iterations (default 500,000)"}},
                },
                handler=self.run_benchmark,
                permission_level=PermissionLevel.SAFE,
            )
        ]
