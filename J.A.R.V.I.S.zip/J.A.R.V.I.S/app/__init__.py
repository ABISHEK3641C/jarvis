"""JARVIS AI Desktop Assistant Package"""
__version__ = "1.0.0"
