"""
Configuration module for JARVIS AI Desktop Assistant.
Handles paths, environment variables, default settings, and persistent configuration.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Base paths
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
ASSETS_DIR = BASE_DIR / "assets"
PLUGINS_DIR = BASE_DIR / "app" / "plugins"

# Ensure runtime directories exist
DATA_DIR.mkdir(parents=True, exist_ok=True)
LOGS_DIR.mkdir(parents=True, exist_ok=True)
ASSETS_DIR.mkdir(parents=True, exist_ok=True)
PLUGINS_DIR.mkdir(parents=True, exist_ok=True)

# Database and log paths
DB_PATH = str(DATA_DIR / "jarvis.db")
LOG_FILE_PATH = str(LOGS_DIR / "jarvis.log")

# Load environment variables
ENV_PATH = BASE_DIR / ".env"
if ENV_PATH.exists():
    load_dotenv(dotenv_path=ENV_PATH)
else:
    load_dotenv()


class Config:
    """Application-wide configuration with fallback defaults."""

    # Application Metadata
    APP_NAME = "JARVIS AI Assistant"
    APP_VERSION = "1.0.0"
    APP_AUTHOR = "Advanced AI System"

    # AI Engine Defaults
    DEFAULT_AI_PROVIDER = os.getenv("AI_PROVIDER", "ollama").lower()
    OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
    DEFAULT_OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    OPENAI_BASE_URL = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")
    DEFAULT_OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    AI_TEMPERATURE = float(os.getenv("AI_TEMPERATURE", "0.5"))
    AI_MAX_TOKENS = int(os.getenv("AI_MAX_TOKENS", "512"))

    # Voice & Speech Defaults
    VOICE_ENABLED = os.getenv("VOICE_ENABLED", "true").lower() in ("true", "1", "yes")
    WAKE_WORD = os.getenv("WAKE_WORD", "hey jarvis").strip().lower()
    TTS_ENGINE = os.getenv("TTS_ENGINE", "pyttsx3")  # 'pyttsx3' or 'edge-tts'
    TTS_RATE = int(os.getenv("TTS_RATE", "200"))
    TTS_VOLUME = float(os.getenv("TTS_VOLUME", "1.0"))
    # Default to Microsoft Zira Desktop (index 2) — David (0) is silent on many Windows 11 systems.
    TTS_VOICE_INDEX = int(os.getenv("TTS_VOICE_INDEX", "2"))
    STT_ENERGY_THRESHOLD = int(os.getenv("STT_ENERGY_THRESHOLD", "300"))
    STT_PAUSE_THRESHOLD = float(os.getenv("STT_PAUSE_THRESHOLD", "0.8"))

    # Web & External Services
    DEFAULT_LOCATION = os.getenv("DEFAULT_LOCATION", "New York")
    OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "")
    SEARCH_MAX_RESULTS = int(os.getenv("SEARCH_MAX_RESULTS", "5"))

    # Security & Execution Safeguards
    REQUIRE_CONFIRMATION_DELETION = os.getenv("REQUIRE_CONFIRMATION_FOR_DELETION", "true").lower() in ("true", "1", "yes")
    REQUIRE_CONFIRMATION_SHUTDOWN = os.getenv("REQUIRE_CONFIRMATION_FOR_SHUTDOWN", "true").lower() in ("true", "1", "yes")

    # UI Theme & Display
    UI_WIDTH = 1100
    UI_HEIGHT = 760
    UI_MIN_WIDTH = 950
    UI_MIN_HEIGHT = 650
    THEME_ACCENT_COLOR = "#00e5ff"  # Neon Cyan
    THEME_BG_COLOR = "#080d1a"      # Deep Futuristic Navy/Black
