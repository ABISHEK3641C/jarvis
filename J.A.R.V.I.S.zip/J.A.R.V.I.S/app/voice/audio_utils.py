"""
Audio Hardware and Device Utilities for JARVIS.
Discovers available microphones and input devices, prioritizing active internal/external mics and headsets.
"""

from typing import List, Dict, Any, Optional
import speech_recognition as sr
from app.utils.logger import get_logger

logger = get_logger("AudioUtils")


def get_default_microphone_index() -> Optional[int]:
    """
    Returns the most suitable default microphone index.
    Prefers Internal Microphone or active physical capture endpoints over unplugged external jacks.
    """
    try:
        import pyaudio
        p = pyaudio.PyAudio()
        info_count = p.get_device_count()

        internal_idx = None
        array_idx = None
        external_idx = None
        first_input = None

        for i in range(info_count):
            try:
                dev = p.get_device_info_by_index(i)
                if dev.get("maxInputChannels", 0) > 0:
                    name = dev.get("name", "").lower()
                    if first_input is None:
                        first_input = i
                    if "internal microphone" in name or "built-in" in name:
                        internal_idx = i
                    elif "microphone array" in name:
                        array_idx = i
                    elif "external microphone" in name:
                        external_idx = i
            except Exception:
                continue

        p.terminate()

        # Prioritize Internal / Array if available on laptops
        if internal_idx is not None:
            return internal_idx
        if array_idx is not None:
            return array_idx
        if external_idx is not None:
            return external_idx
        return first_input
    except Exception as e:
        logger.debug(f"Could not query default microphone index: {e}")
        return None


def get_microphone_devices() -> List[Dict[str, Any]]:
    """
    Returns a clean list of detected microphone input devices with their indices.
    """
    devices = []
    seen_names = set()
    best_default_idx = get_default_microphone_index()

    try:
        import pyaudio
        p = pyaudio.PyAudio()
        info_count = p.get_device_count()

        for i in range(info_count):
            try:
                dev = p.get_device_info_by_index(i)
                channels = dev.get("maxInputChannels", 0)
                if channels > 0:
                    raw_name = dev.get("name", f"Microphone {i}").strip()
                    # Clean ugly Windows driver path strings
                    clean_name = raw_name
                    if "@System32" in clean_name or ";" in clean_name:
                        parts = clean_name.split(";")
                        clean_name = parts[-1].replace("(", "").replace(")", "").strip() or raw_name

                    # Short unique identifier
                    is_rec = (i == best_default_idx)
                    tag = " ⭐ [Recommended]" if is_rec else ""
                    display = f"[{i}] {clean_name}{tag}"

                    devices.append({
                        "index": i,
                        "name": display,
                        "raw_name": raw_name,
                        "clean_name": clean_name,
                        "is_default": is_rec,
                        "channels": channels,
                    })
            except Exception:
                continue

        p.terminate()
    except Exception as e:
        logger.warning(f"Error querying PyAudio devices: {e}")

    # Fallback if empty
    if not devices:
        devices.append({
            "index": 2,
            "name": "[2] Internal Microphone (Default)",
            "raw_name": "Internal Microphone",
            "clean_name": "Internal Microphone",
            "is_default": True,
            "channels": 2,
        })

    return devices
