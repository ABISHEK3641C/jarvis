"""
Speech-to-Text (STT) Recognition Subsystem for JARVIS.
Features multi-language recognition (en-IN with fallback to en-US/hi-IN),
optimized ambient calibration, high-sensitivity voice capture, and continuous listening loop support.
"""

import threading
import time
from typing import Optional, Callable
import speech_recognition as sr
from app.config import Config
from app.voice.audio_utils import get_default_microphone_index
from app.utils.logger import get_logger

logger = get_logger("STT")


class STTEngine:
    """High-sensitivity microphone speech recognition manager."""

    def __init__(
        self,
        device_index: Optional[int] = 2,
        energy_threshold: int = 150,
        pause_threshold: float = 0.8,
    ):
        self.device_index = device_index
        self.energy_threshold = energy_threshold
        self.pause_threshold = pause_threshold

        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = self.energy_threshold
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.dynamic_energy_adjustment_damping = 0.15
        self.recognizer.dynamic_energy_ratio = 1.3
        self.recognizer.pause_threshold = self.pause_threshold
        self.recognizer.non_speaking_duration = 0.4
        self.recognizer.phrase_threshold = 0.2

        self._is_listening = False
        self._is_calibrated = False
        self._stop_listening_fn: Optional[Callable] = None
        self._on_recognized_callback: Optional[Callable[[str], None]] = None
        self._on_error_callback: Optional[Callable[[str], None]] = None
        self._on_status_callback: Optional[Callable[[str], None]] = None

    def _get_active_device_index(self) -> Optional[int]:
        """Resolves active device index or falls back to system default microphone."""
        if self.device_index is not None:
            return self.device_index
        return get_default_microphone_index()

    def set_callbacks(
        self,
        on_recognized: Optional[Callable[[str], None]] = None,
        on_error: Optional[Callable[[str], None]] = None,
        on_status: Optional[Callable[[str], None]] = None,
    ):
        """Sets external handler callbacks for the UI."""
        self._on_recognized_callback = on_recognized
        self._on_error_callback = on_error
        self._on_status_callback = on_status

    def calibrate_ambient_noise(self, duration_sec: float = 0.8) -> bool:
        """Calibrates microphone energy levels once against background room noise."""
        try:
            mic_idx = self._get_active_device_index()
            mic_kwargs = {"device_index": mic_idx} if mic_idx is not None else {}

            with sr.Microphone(**mic_kwargs) as source:
                logger.info(f"Calibrating ambient noise on device [{mic_idx}]...")
                self.recognizer.adjust_for_ambient_noise(source, duration=duration_sec)
                # Keep energy threshold reasonable but let it land naturally — don't floor it at 80
                # (80 was too low and caused random noise to be treated as speech)
                self.recognizer.energy_threshold = max(self.recognizer.energy_threshold, 180)
                self.recognizer.energy_threshold = min(self.recognizer.energy_threshold, 400)
                logger.info(f"Calibrated energy threshold: {self.recognizer.energy_threshold}")
                self._is_calibrated = True
                return True
        except Exception as e:
            logger.warning(f"Microphone noise calibration failed: {e}")
            return False

    def listen_one_shot(self, timeout: float = 5.0, phrase_time_limit: float = 12.0) -> Optional[str]:
        """
        Listens synchronously for spoken phrase and transcribes with multi-language fallback.
        """
        mic_idx = self._get_active_device_index()
        mic_kwargs = {"device_index": mic_idx} if mic_idx is not None else {}

        try:
            if self._on_status_callback:
                self._on_status_callback("LISTENING")

            with sr.Microphone(**mic_kwargs) as source:
                # If not calibrated yet, calibrate briefly
                if not self._is_calibrated:
                    self.recognizer.adjust_for_ambient_noise(source, duration=0.3)
                    self._is_calibrated = True

                logger.debug(f"Microphone [{mic_idx}] listening...")
                audio = self.recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)

            if self._on_status_callback:
                self._on_status_callback("THINKING")

            # Try Indian English (en-IN) first for best natural recognition, fallback to en-US and hi-IN
            text = None
            for lang in ["en-IN", "en-US", "hi-IN"]:
                try:
                    text = self.recognizer.recognize_google(audio, language=lang)
                    if text and text.strip():
                        logger.info(f"STT Recognized Voice ({lang}): '{text}'")
                        break
                except sr.UnknownValueError:
                    continue
                except sr.RequestError:
                    break

            return text if (text and text.strip()) else None

        except sr.WaitTimeoutError:
            logger.debug("Speech recognition timed out (no audio detected).")
            return None
        except sr.UnknownValueError:
            logger.debug("Speech detected but could not be transcribed by any language model.")
            return None
        except sr.RequestError as re:
            logger.error(f"Speech recognition network request error: {re}")
            if self._on_error_callback:
                self._on_error_callback("Speech recognition network error. Please check your internet connection.")
            return None
        except Exception as e:
            logger.error(f"Microphone input error on device [{mic_idx}]: {e}")
            if self._on_error_callback:
                self._on_error_callback(f"Microphone error on device [{mic_idx}]: {e}")
            return None
