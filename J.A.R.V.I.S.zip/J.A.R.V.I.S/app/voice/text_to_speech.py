"""
Text-to-Speech (TTS) Engine for JARVIS.
Provides high-performance, low-latency offline voice synthesis with real-time speech interruption.
Uses a single persistent pyttsx3 engine (pre-initialized) so the first word is spoken
within ~150 ms of a request, not after a 3-second engine cold-start.
"""

import threading
import queue
import time
from typing import List, Dict, Any, Optional, Callable
import pyttsx3
from app.config import Config
from app.utils.logger import get_logger

logger = get_logger("TTS")


class TTSEngine:
    """Non-blocking Text-to-Speech Engine with interrupt capabilities."""

    def __init__(
        self,
        rate: int = Config.TTS_RATE,
        volume: float = Config.TTS_VOLUME,
        voice_index: int = Config.TTS_VOICE_INDEX,
    ):
        self.rate = rate
        self.volume = volume
        self.voice_index = voice_index
        self._speech_queue: "queue.Queue[Optional[str]]" = queue.Queue()
        self._is_speaking = False
        self._stop_requested = False
        self._lock = threading.Lock()
        self._on_start_callback: Optional[Callable[[], None]] = None
        self._on_finish_callback: Optional[Callable[[], None]] = None
        self._engine = None  # Persistent pyttsx3 engine — reused for every utterance.

        self._init_engine()
        self._init_worker()

    # ------------------------------------------------------------------ engine

    def _init_engine(self):
        """Builds one pyttsx3 engine and applies configured voice / rate / volume."""
        try:
            self._engine = pyttsx3.init()
            try:
                self._engine.setProperty("rate", self.rate)
            except Exception:
                pass
            try:
                self._engine.setProperty("volume", self.volume)
            except Exception:
                pass

            voices = self._engine.getProperty("voices") or []
            # Try configured voice_index first; if that voice fails to load, fall back
            # to the first English voice that exists on this system.
            chosen_id = None
            if 0 <= self.voice_index < len(voices):
                chosen_id = voices[self.voice_index].id

            if chosen_id:
                try:
                    self._engine.setProperty("voice", chosen_id)
                    logger.info(f"TTS voice set: [{self.voice_index}] {voices[self.voice_index].name}")
                except Exception as e:
                    logger.warning(f"Configured voice index {self.voice_index} failed: {e}; falling back.")
                    chosen_id = None

            if not chosen_id and voices:
                # Pick the first voice whose name contains 'Zira', 'Hazel', or any English voice.
                for v in voices:
                    name = (v.name or "").lower()
                    if "zira" in name or "hazel" in name:
                        try:
                            self._engine.setProperty("voice", v.id)
                            logger.info(f"TTS fallback voice: {v.name}")
                            chosen_id = v.id
                            break
                        except Exception:
                            continue
                if not chosen_id:
                    try:
                        self._engine.setProperty("voice", voices[0].id)
                        logger.info(f"TTS last-resort voice: {voices[0].name}")
                    except Exception:
                        pass
        except Exception as e:
            logger.error(f"Failed to initialize pyttsx3 engine: {e}", exc_info=True)
            self._engine = None

    def _init_worker(self):
        """Starts the dedicated background TTS worker thread."""
        self._worker_thread = threading.Thread(target=self._process_queue, daemon=True)
        self._worker_thread.start()

    # --------------------------------------------------------------- public api

    def get_available_voices(self) -> List[Dict[str, Any]]:
        """Returns list of installed Windows SAPI5 TTS voices."""
        voices_list = []
        try:
            scratch = pyttsx3.init()
            voices = scratch.getProperty("voices")
            for idx, v in enumerate(voices):
                voices_list.append({
                    "index": idx,
                    "id": v.id,
                    "name": v.name,
                    "languages": getattr(v, "languages", []),
                    "gender": getattr(v, "gender", "unknown"),
                })
            scratch.stop()
        except Exception as e:
            logger.error(f"Error fetching TTS voices: {e}")
        return voices_list

    def set_callbacks(
        self,
        on_start: Optional[Callable[[], None]] = None,
        on_finish: Optional[Callable[[], None]] = None,
    ):
        """Configures start/finish state callbacks for the UI."""
        self._on_start_callback = on_start
        self._on_finish_callback = on_finish

    def speak(self, text: str, priority: bool = False):
        """
        Enqueues text for speech synthesis.
        If priority is True, clears existing queue and speaks immediately.
        """
        if not text or not text.strip():
            return

        clean_text = self._clean_speech_text(text)
        if not clean_text:
            return

        if priority:
            self.stop()

        self._speech_queue.put(clean_text)
        logger.debug(f"Queued speech: '{clean_text[:60]}...'")

    def stop(self):
        """Interrupts ongoing speech immediately and drains queue."""
        self._stop_requested = True
        with self._lock:
            while not self._speech_queue.empty():
                try:
                    self._speech_queue.get_nowait()
                    self._speech_queue.task_done()
                except Exception:
                    break

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking

    # ---------------------------------------------------------------- helpers

    def _clean_speech_text(self, text: str) -> str:
        """Removes markdown symbols, URLs, and code blocks for smooth speech output."""
        import re
        cleaned = re.sub(r"```[\s\S]*?```", " [code block omitted] ", text)
        cleaned = re.sub(r"`([^`]+)`", r"\1", cleaned)
        cleaned = re.sub(r"\[([^\]]+)\]\([^\)]+\)", r"\1", cleaned)
        cleaned = re.sub(r"[#*_~>]+", "", cleaned)
        cleaned = " ".join(cleaned.split())
        return cleaned.strip()

    def _process_queue(self):
        """Background loop that consumes speech requests on the persistent engine."""
        while True:
            text = self._speech_queue.get()
            if text is None:
                break

            self._stop_requested = False
            self._is_speaking = True
            if self._on_start_callback:
                try:
                    self._on_start_callback()
                except Exception:
                    pass

            try:
                if self._engine is None:
                    self._init_engine()

                # If the persistent engine was lost or broken, rebuild it once.
                if self._engine is None:
                    logger.error("TTS engine unavailable — dropping utterance.")
                else:
                    # Speak sentence by sentence to allow rapid interruption.
                    sentences = [s.strip() for s in text.replace("\n", ". ").split(". ") if s.strip()]
                    if not sentences:
                        sentences = [text]

                    for sentence in sentences:
                        if self._stop_requested:
                            break
                        try:
                            self._engine.say(sentence)
                            self._engine.runAndWait()
                        except Exception as e:
                            logger.error(f"TTS per-sentence error: {e}")
                            # Rebuild engine on failure — common if SAPI voice crashed.
                            try:
                                self._engine.stop()
                            except Exception:
                                pass
                            self._init_engine()
                            if self._engine is not None:
                                try:
                                    self._engine.say(sentence)
                                    self._engine.runAndWait()
                                except Exception:
                                    pass
            except Exception as e:
                logger.error(f"TTS synthesis error: {e}", exc_info=True)
            finally:
                self._is_speaking = False
                self._speech_queue.task_done()
                if self._on_finish_callback:
                    try:
                        self._on_finish_callback()
                    except Exception:
                        pass
