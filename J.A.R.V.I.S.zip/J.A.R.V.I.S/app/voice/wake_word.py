"""
Wake Word Detection Subsystem for JARVIS.
Monitors background microphone audio for activation phrases like "Hey JARVIS" or "JARVIS".
"""

import threading
import time
from typing import Optional, Callable
import speech_recognition as sr
from app.config import Config
from app.utils.logger import get_logger

logger = get_logger("WakeWord")


class WakeWordDetector:
    """Listens continuously for wake phrase and triggers activation events."""

    def __init__(
        self,
        wake_word: str = Config.WAKE_WORD,
        device_index: Optional[int] = None,
        on_wake: Optional[Callable[[], None]] = None,
    ):
        self.wake_word = wake_word.strip().lower()
        self.device_index = device_index
        self.on_wake = on_wake
        self._is_running = False
        self._thread: Optional[threading.Thread] = None
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 400
        self.recognizer.dynamic_energy_threshold = True

    def start(self):
        """Starts the wake word background monitoring thread."""
        if self._is_running:
            return
        self._is_running = True
        self._thread = threading.Thread(target=self._listen_loop, daemon=True)
        self._thread.start()
        logger.info(f"Wake word detector started for phrase: '{self.wake_word}'")

    def stop(self):
        """Stops wake word monitoring."""
        self._is_running = False
        logger.info("Wake word detector stopped.")

    def _listen_loop(self):
        """Continuous background listening loop."""
        mic_kwargs = {}
        if self.device_index is not None:
            mic_kwargs["device_index"] = self.device_index

        try:
            mic = sr.Microphone(**mic_kwargs)
            with mic as source:
                self.recognizer.adjust_for_ambient_noise(source, duration=0.8)
        except Exception as e:
            logger.warning(f"Could not open microphone for wake word detector: {e}")
            return

        while self._is_running:
            try:
                with mic as source:
                    audio = self.recognizer.listen(source, timeout=3.0, phrase_time_limit=4.0)

                phrase = self.recognizer.recognize_google(audio).lower()
                logger.debug(f"Wake check audio heard: '{phrase}'")

                # Check if wake phrase is in the recognized text
                if self._matches_wake_word(phrase):
                    logger.info(f"Wake word detected in phrase: '{phrase}'")
                    if self.on_wake:
                        self.on_wake()
                    # Brief pause after triggering
                    time.sleep(1.0)

            except sr.WaitTimeoutError:
                continue
            except sr.UnknownValueError:
                continue
            except Exception as e:
                logger.debug(f"Wake word listener loop iteration error: {e}")
                time.sleep(1.0)

    def _matches_wake_word(self, recognized_text: str) -> bool:
        """Checks if text contains the wake word phrase."""
        rec = recognized_text.lower()
        # Direct phrase match
        if self.wake_word in rec:
            return True
        # Common phonetic variations for "jarvis"
        if "jarvis" in self.wake_word and ("jarvis" in rec or "jarves" in rec or "service" in rec or "hey jarvis" in rec):
            return True
        return False
