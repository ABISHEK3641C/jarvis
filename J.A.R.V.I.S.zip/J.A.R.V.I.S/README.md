# ◈ J.A.R.V.I.S — Advanced Personal AI Desktop Assistant for Windows ◈

> **Just A Rather Very Intelligent System**
> A fully functional, production-grade, modular, high-performance personal AI desktop assistant built natively for Windows using **PySide6**, **Ollama**, **Speech Recognition**, **Windows Automation**, **Persistent SQLite Memory**, and **Extensible Plugins**.

---

## ⚡ Key Highlights & Architecture

```
User Voice / Text
      ↓
PySide6 Cyberpunk HUD (60 FPS Animated Visualizer, System Telemetry, Chat Stream)
      ↓
App Coordinator / Controller
      ↓
AI Brain Engine (Local Ollama LLM / OpenAI-Compatible API / Offline Rule Engine)
      ↓
Intent & Structured Function Calling (JSON Schema)
      ↓
Security Safeguard Interceptor (Tiered: SAFE, MODERATE, DANGEROUS with UI Confirmation)
      ↓
Native Windows Automation, System Control, Files, Web Search, Weather, & Memory
      ↓
Voice Synthesis (TTS) & Real-time Visual Response
```

### 1. Modern Futuristic HUD Interface
* **Animated Holographic Visualizer**: Custom QPainter circular HUD with 6 dynamic states (`IDLE`, `LISTENING`, `THINKING`, `SPEAKING`, `EXECUTING`, `ERROR`) and live audio frequency waveforms.
* **System Telemetry Bar**: Live CPU load, RAM usage, Battery / AC status, Network connectivity, Date & Time, and Active AI Model badge.
* **Formatted Markdown Chat Stream**: Rich message bubbles with syntax-highlighted code blocks, copy actions, and expandable tool execution cards.
* **Multi-Session History Sidebar**: Search, switch, create, and delete conversation history.

### 2. Dual Voice & Chat Interaction
* **Real-time Speech-to-Text (STT)**: Microphone device selector with dynamic ambient noise calibration and automatic silence detection.
* **Text-to-Speech (TTS)**: Low-latency offline Windows SAPI5 voice engine with adjustable speech rate, volume, and **instant speech interruption** when the user speaks or gives a new command.
* **Wake Word Detection**: Background audio listener responding to `"Hey JARVIS"` or custom wake phrases.

### 3. Local & Cloud AI Brain
* **Ollama Integration**: Seamless local LLM support (`llama3.2`, `qwen`, `mistral`, `gemma`, `phi3`, etc.) with automatic model detection via the Ollama REST API.
* **OpenAI-Compatible Support**: Connects to OpenAI (`gpt-4o-mini`, `gpt-4o`), Groq, LM Studio, or local OpenAI-compatible endpoints with custom base URLs and secure key storage.
* **Smart Local Fallback**: If neither Ollama nor an API key is reachable, JARVIS automatically uses an offline natural-language intent router so all system automations, weather, files, and calculators continue working flawlessly!

### 4. Over 25+ Built-in Windows Tools & Automations
* **Application Launcher**: Auto-detects installed Windows Start Menu shortcuts, system binaries (`notepad`, `calc`, `chrome`, `code`, `cmd`, `explorer`, `settings`), and user-registered custom executable paths.
* **File System Assistant**: Search files by pattern/extension (`*.pdf`, `*.py`) across user directories without full-disk lag, read/write files, create folders, open Explorer, move, copy, and rename.
* **Security Safeguards**: High-risk actions (file/folder deletion, computer shutdown, reboot, process termination) trigger an interactive confirmation modal before execution.
* **Real-time Web Search & Weather**: Live web search with multi-tier fallback (DuckDuckGo, Wikipedia) and global weather with 7-day forecast via Open-Meteo (no API key required).
* **System Control & Automation**: Volume control (`volume_up`, `volume_down`, `mute`, `unmute`), media playback (`play_pause`, `next`, `prev`), lock workstation, screenshots, clipboard read/write, keyboard typing, and hotkeys.
* **Persistent Memory**: SQLite database storing categorized user facts, preferences, and instructions with automatic system prompt injection.
* **Dynamic Plugin Architecture**: Automatically discovers and loads custom tool extensions from `app/plugins/`.

---

## 📂 Project Structure

```text
J.A.R.V.I.S/
│
├── main.py                          # Application entry point & Qt event loop
├── requirements.txt                 # Python dependencies
├── .env.example                     # Environment variables template
├── README.md                        # Complete documentation & usage guide
│
├── app/
│   ├── __init__.py
│   ├── config.py                    # Configuration, constants, settings manager
│   │
│   ├── core/
│   │   ├── ai_engine.py             # LLM provider abstraction (Ollama, OpenAI, Fallback)
│   │   ├── tool_manager.py          # Tool schema builder, validation & execution engine
│   │   ├── security.py              # Permission tiers (SAFE, MODERATE, DANGEROUS)
│   │   ├── database.py              # SQLite connection, schemas, settings & app registry
│   │   ├── memory.py                # Persistent memory manager (CRUD & context retriever)
│   │   ├── conversation.py          # Multi-session conversation logs & history
│   │   └── plugin_base.py           # Extensible plugin interface
│   │
│   ├── voice/
│   │   ├── speech_to_text.py        # STT engine with microphone selection & calibration
│   │   ├── text_to_speech.py        # Interruptible TTS engine (pyttsx3 / Windows SAPI5)
│   │   ├── wake_word.py             # Wake word detector ("Hey JARVIS")
│   │   └── audio_utils.py           # Audio device discovery & enumerator
│   │
│   ├── tools/
│   │   ├── __init__.py              # Tool registry hub
│   │   ├── applications.py          # Windows app launcher, process terminator, custom paths
│   │   ├── system_control.py        # Volume, media keys, lock screen, battery, power
│   │   ├── files.py                 # File & folder search, read, write, move, delete
│   │   ├── web.py                   # Real web search (DDGS & Wikipedia) and URL launcher
│   │   ├── weather.py               # Live Open-Meteo weather & forecast
│   │   ├── screenshot.py            # Screen capture & vision preparation
│   │   ├── clipboard.py             # Clipboard read/write
│   │   ├── input_automation.py      # Typing into active windows & hotkey simulator
│   │   ├── calculator.py            # Safe mathematical AST evaluator
│   │   └── datetime_tools.py        # Date, time, timezone, human formatting
│   │
│   ├── plugins/
│   │   ├── note_taker.py            # Quick memo and scratchpad plugin
│   │   └── system_benchmark.py      # Diagnostic CPU compute benchmark plugin
│   │
│   ├── ui/
│   │   ├── main_window.py           # Primary JARVIS HUD Window
│   │   ├── styles.py                # Cyberpunk dark theme stylesheet
│   │   ├── widgets/
│   │   │   ├── status_visualizer.py # Animated holographic circular status visualizer
│   │   │   ├── system_hud.py        # Real-time CPU, RAM, Battery, Network stat chips
│   │   │   ├── chat_view.py         # Message bubbles, code blocks, tool badges
│   │   │   ├── history_sidebar.py   # Collapsible conversation session list
│   │   │   └── confirmation_dialog.py # Interactive modal for dangerous actions
│   │   └── dialogs/
│   │       └── settings_dialog.py   # Multi-tab Settings dialog
│   │
│   └── utils/
│       ├── logger.py                # Rotating file logger to logs/jarvis.log + console
│       ├── system_info.py           # psutil telemetry snapshot and QThread worker
│       └── helpers.py               # Formatting, sanitizers, and thread helpers
│
├── data/
│   ├── jarvis.db                    # Persistent SQLite database (auto-generated)
│   ├── screenshots/                 # Captured desktop screenshots
│   └── notes/                       # Saved user notes and memos
│
├── logs/
│   └── jarvis.log                   # Rotating application logs
│
└── tests/
    ├── test_ai_engine.py            # AI Engine & tool routing tests
    ├── test_tools.py                # File, App, System, Calc tool tests
    ├── test_memory.py               # Memory CRUD tests
    ├── test_database.py             # Database schema & settings tests
    ├── test_security.py             # Security confirmation tests
    ├── test_plugins.py              # Plugin loading tests
    └── test_gui.py                  # PySide6 UI lifecycle tests
```

---

## 🚀 Quick Start & Installation

### 1. Prerequisites
* **Windows 10 / 11**
* **Python 3.11+** installed and added to `PATH`
* *(Optional for local AI)* **Ollama**: [Download Ollama for Windows](https://ollama.com)

### 2. Setup Virtual Environment & Dependencies

Open PowerShell in the project directory:

```powershell
# 1. Create and activate a virtual environment
python -m venv .venv
.venv\Scripts\activate

# 2. Install all dependencies
pip install -r requirements.txt
```

### 3. (Optional) Setup Local Ollama Model
If you want to use local LLMs, pull your preferred model in a terminal:

```powershell
ollama pull llama3.2
```

*(You can also use `qwen2.5`, `mistral`, `gemma2`, or `phi3`)*.

### 4. Run JARVIS

```powershell
python main.py
```

---

## 🎙️ Natural Voice & Text Commands Examples

JARVIS understands natural language and routes commands to native tools:

| Category | Example Commands | Executed Tool |
| :--- | :--- | :--- |
| **System & Status** | *"What is my CPU and RAM usage?"*, *"System specs"*, *"Battery percentage"* | `get_cpu_usage`, `get_ram_usage`, `get_system_information` |
| **Time & Date** | *"What time is it?"*, *"Tell me today's date"* | `get_current_time`, `get_current_date` |
| **Applications** | *"Open Chrome"*, *"Launch VS Code"*, *"Open Notepad"*, *"Close Chrome"* | `open_application`, `close_application` |
| **Web & Search** | *"Search the web for Python decorators"*, *"Search YouTube for GTA 5"* | `search_web`, `search_youtube` |
| **Weather** | *"What's the weather in Tokyo?"*, *"Will it rain today?"* | `get_weather` |
| **File Management** | *"Find my PDF files"*, *"Find Python scripts in Downloads"*, *"Open Documents folder"* | `search_files`, `open_folder` |
| **Memory** | *"Remember that my project is called JARVIS"*, *"What is my project name?"* | `remember_information`, `retrieve_memory` |
| **Media & Volume** | *"Volume up"*, *"Mute sound"*, *"Pause music"*, *"Next track"* | `volume_up`, `mute_volume`, `media_play_pause` |
| **Screen & Clipboard**| *"Take a screenshot"*, *"What is in my clipboard?"* | `take_screenshot`, `clipboard_read` |
| **Math & Logic** | *"Calculate 45 * 92 + sqrt(256)"*, *"What is 2^16?"* | `calculate` |
| **Safe Danger Ops** | *"Delete file temp.txt"*, *"Shut down the computer"* | Triggers **Security Confirmation Modal** |

---

## ⚙️ Settings & Configuration

Click the **⚙️ Settings** button in the top right to customize:
* **🧠 AI Brain**: Switch between Ollama and OpenAI-compatible endpoints, live-detect installed Ollama models, set temperature, or configure API keys.
* **🎙️ Voice & Audio**: Select microphone device, choose TTS voice, adjust speech rate / volume, test voice output, and configure the wake word phrase.
* **🌐 Web & Weather**: Set your default city for weather and search providers.
* **💾 Memory Manager**: View, edit, add, or delete persistent facts from SQLite.
* **🛡️ Security & Custom Apps**: Register custom application paths (`.exe`, `.lnk`) and configure confirmation prompts.
* **📜 Live Logs**: View real-time application logs from `logs/jarvis.log`.

---

## 🧪 Automated Testing

Execute the complete test suite with `pytest`:

```powershell
pytest -v tests/
```

All 25 unit and UI integration tests verify database schemas, memory persistence, tool execution, safety confirmation interceptors, AI fallback routing, plugin discovery, and PySide6 UI rendering.
