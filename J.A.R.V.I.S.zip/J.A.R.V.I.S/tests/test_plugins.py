"""Unit tests for Dynamic Plugin Loading."""
import pytest
from app.core.tool_manager import ToolManager
from app.plugins.note_taker import NoteTakerPlugin
from app.plugins.system_benchmark import SystemBenchmarkPlugin


def test_plugin_registration():
    tm = ToolManager()
    note_plugin = NoteTakerPlugin()
    bench_plugin = SystemBenchmarkPlugin()

    tm.register_plugin(note_plugin)
    tm.register_plugin(bench_plugin)

    assert "take_note" in tm.tools
    assert "list_notes" in tm.tools
    assert "read_note" in tm.tools
    assert "run_cpu_benchmark" in tm.tools

    res = tm.execute_tool("run_cpu_benchmark", {"iterations": 50000})
    assert res["success"] is True
    assert "benchmark_score" in res["result"]


def test_plugin_directory_loader():
    tm = ToolManager()
    tm.load_plugins_from_directory()
    assert len(tm.plugins) >= 2
