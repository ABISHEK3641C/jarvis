"""Unit tests for JARVIS AI Brain and Rule-Based Fallback Routing."""
import pytest
from app.core.tool_manager import ToolManager
from app.core.memory import MemoryManager
from app.core.conversation import ConversationManager
from app.core.ai_engine import AIEngine
from app.tools import register_all_tools


@pytest.fixture
def ai_setup():
    tool_mgr = ToolManager()
    mem_mgr = MemoryManager()
    conv_mgr = ConversationManager()
    register_all_tools(tool_mgr, mem_mgr)
    engine = AIEngine(tool_mgr, mem_mgr, conv_mgr)
    return engine, tool_mgr, mem_mgr


def test_rule_fallback_weather(ai_setup):
    engine, _, _ = ai_setup
    resp, tools = engine._call_rule_fallback("What's the weather in Tokyo?")
    assert len(tools) == 1
    assert tools[0]["name"] == "get_weather"
    assert "Tokyo" in tools[0]["arguments"]["location"]


def test_rule_fallback_calc(ai_setup):
    engine, _, _ = ai_setup
    resp, tools = engine._call_rule_fallback("Calculate 120 * 4")
    assert len(tools) == 1
    assert tools[0]["name"] == "calculate"
    assert "120 * 4" in tools[0]["arguments"]["expression"]


def test_rule_fallback_time_and_cpu(ai_setup):
    engine, _, _ = ai_setup
    resp_time, tools_time = engine._call_rule_fallback("What is the current time?")
    assert tools_time[0]["name"] == "get_current_time"

    resp_cpu, tools_cpu = engine._call_rule_fallback("Show me my cpu usage")
    assert tools_cpu[0]["name"] == "get_cpu_usage"


def test_rule_fallback_app_launch(ai_setup):
    engine, _, _ = ai_setup
    resp, tools = engine._call_rule_fallback("Open Chrome")
    assert len(tools) == 1
    assert tools[0]["name"] == "open_application"
    assert tools[0]["arguments"]["app_name"] == "chrome"


def test_process_query_end_to_end_offline(ai_setup):
    engine, _, _ = ai_setup
    # Simulate an end-to-end query in offline fallback mode
    result = engine.process_query("What is 50 * 50?")
    assert "response" in result
    assert "2500" in result["response"]
    assert len(result["tool_calls"]) == 1
    assert result["tool_calls"][0]["name"] == "calculate"
