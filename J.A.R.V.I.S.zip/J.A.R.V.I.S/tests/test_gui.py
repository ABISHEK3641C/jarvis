"""Unit tests for PySide6 GUI Components and Window Lifecycle."""
import os
import pytest

# Ensure headless Qt for tests
os.environ["QT_QPA_PLATFORM"] = "offscreen"

from PySide6.QtWidgets import QApplication
from app.ui.main_window import JarvisMainWindow
from app.ui.widgets.status_visualizer import StatusVisualizer
from app.ui.widgets.system_hud import SystemHudWidget
from app.ui.widgets.chat_view import ChatViewWidget


@pytest.fixture(scope="session")
def qapp():
    app = QApplication.instance()
    if app is None:
        app = QApplication([])
    yield app


def test_status_visualizer_states(qapp):
    vis = StatusVisualizer()
    assert vis.state == "IDLE"

    vis.set_state("LISTENING")
    assert vis.state == "LISTENING"

    vis.set_state("THINKING")
    assert vis.state == "THINKING"

    vis.set_state("SPEAKING")
    assert vis.state == "SPEAKING"

    vis.set_state("EXECUTING")
    assert vis.state == "EXECUTING"

    vis.set_state("ERROR")
    assert vis.state == "ERROR"


def test_system_hud_widget(qapp):
    hud = SystemHudWidget()
    sample_metrics = {
        "cpu_percent": 15.4,
        "ram_percent": 42.1,
        "ram_used_bytes": 4 * 1024 * 1024 * 1024,
        "battery_percent": 85,
        "battery_power_plugged": True,
        "network_connected": True,
    }
    hud.update_metrics(sample_metrics)
    assert "15.4%" in hud.val_cpu.text()
    assert "42.1%" in hud.val_ram.text()
    assert "ONLINE" in hud.val_net.text()


def test_chat_view_widget(qapp):
    chat = ChatViewWidget()
    chat.add_message("user", "Hello JARVIS")
    chat.add_message("jarvis", "Hello sir, how may I help?", tool_calls=[{"name": "get_time", "arguments": {}}])
    assert chat.messages_layout.count() >= 3

    chat.clear_chat()
    assert chat.messages_layout.count() == 1  # only stretch remaining


def test_main_window_init(qapp):
    window = JarvisMainWindow()
    assert "J.A.R.V.I.S" in window.windowTitle()
    assert window.hud_bar is not None
    assert window.status_visualizer is not None
    assert window.lbl_user_spoken is not None
    assert window.lbl_jarvis_response is not None
    assert window.lbl_emotion_status is not None
    assert window.vision_panel is not None
    window.close()
