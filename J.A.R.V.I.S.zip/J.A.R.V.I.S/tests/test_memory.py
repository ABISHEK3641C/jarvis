"""Unit tests for JARVIS Memory operations."""
import os
import tempfile
import pytest
from app.core.database import Database
from app.core.memory import MemoryManager


@pytest.fixture
def memory_mgr():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    db = Database(db_path=path)
    mgr = MemoryManager(db=db)
    yield mgr
    db.close()
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass


def test_remember_and_retrieve(memory_mgr):
    res1 = memory_mgr.remember(key_fact="project name", content="Project JARVIS", category="projects")
    assert res1["status"] == "created"

    res2 = memory_mgr.remember(key_fact="favorite editor", content="VS Code", category="preferences")
    assert res2["status"] == "created"

    # Search retrieve
    retrieved = memory_mgr.retrieve("JARVIS")
    assert len(retrieved) >= 1
    assert retrieved[0]["content"] == "Project JARVIS"

    # Retrieve by category
    prefs = memory_mgr.retrieve("VS Code", category="preferences")
    assert len(prefs) == 1
    assert prefs[0]["key_fact"] == "favorite editor"


def test_update_and_forget(memory_mgr):
    res = memory_mgr.remember(key_fact="hobby", content="Coding", category="facts")
    mem_id = res["id"]

    assert memory_mgr.update(mem_id, content="Coding in Python")
    retrieved = memory_mgr.retrieve("hobby")
    assert retrieved[0]["content"] == "Coding in Python"

    # Forget
    assert memory_mgr.forget("hobby")
    assert len(memory_mgr.retrieve("hobby")) == 0


def test_context_generation(memory_mgr):
    memory_mgr.remember(key_fact="user pet", content="A golden retriever named Max", category="facts")
    memory_mgr.remember(key_fact="coding style", content="Clean and modular", category="preferences")

    ctx = memory_mgr.get_relevant_context("Tell me about my pet Max")
    assert "golden retriever" in ctx
    assert "user pet" in ctx
