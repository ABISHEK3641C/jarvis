"""Unit tests for JARVIS Security and Confirmation Subsystem."""
import pytest
from app.core.security import SecurityManager, PermissionLevel


def test_permission_safe():
    sec = SecurityManager()
    assert sec.check_permission("get_time", PermissionLevel.SAFE, {}) is True
    assert sec.check_permission("calculate", PermissionLevel.SAFE, {"expression": "2+2"}) is True


def test_permission_dangerous_approval():
    # Mock approval callback
    sec = SecurityManager(confirmation_callback=lambda name, args, desc: True)
    assert sec.check_permission("delete_file", PermissionLevel.DANGEROUS, {"file_path": "test.txt"}) is True


def test_permission_dangerous_denial():
    # Mock rejection callback
    sec = SecurityManager(confirmation_callback=lambda name, args, desc: False)
    assert sec.check_permission("delete_file", PermissionLevel.DANGEROUS, {"file_path": "test.txt"}) is False


def test_permission_dangerous_no_callback():
    sec = SecurityManager(confirmation_callback=None)
    # When no callback is registered, dangerous tools must be blocked safely
    assert sec.check_permission("delete_file", PermissionLevel.DANGEROUS, {"file_path": "test.txt"}) is False
