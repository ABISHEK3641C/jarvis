"""Unit tests for JARVIS Built-in Tools."""
import os
import tempfile
import pytest
from app.tools.calculator import calculate
from app.tools.datetime_tools import get_current_time, get_current_date
from app.tools.system_control import get_cpu_usage, get_ram_usage, get_system_information
from app.tools.files import (
    create_file,
    read_file,
    rename_file,
    copy_file,
    move_file,
    delete_file,
    create_folder,
    search_files,
)
from app.plugins.system_benchmark import SystemBenchmarkPlugin


def test_calculator_basic_and_functions():
    res = calculate("45 * 2 + 10")
    assert res.get("result") == 100

    res_pow = calculate("2 ^ 8")
    assert res_pow.get("result") == 256

    res_sqrt = calculate("sqrt(144) + 8")
    assert res_sqrt.get("result") == 20

    res_zero = calculate("10 / 0")
    assert "error" in res_zero


def test_datetime_tools():
    time_info = get_current_time()
    assert "time_12h" in time_info
    assert "summary" in time_info

    date_info = get_current_date()
    assert "date" in date_info
    assert "day_of_week" in date_info


def test_system_info_tools():
    cpu = get_cpu_usage()
    assert "cpu_percent" in cpu
    assert cpu["cores"] >= 1

    ram = get_ram_usage()
    assert "percent" in ram
    assert "total" in ram

    info = get_system_information()
    assert "os" in info


def test_file_operations():
    with tempfile.TemporaryDirectory() as tmpdir:
        test_file = os.path.join(tmpdir, "test_doc.txt")

        # 1. Create
        c_res = create_file(test_file, "Hello JARVIS Automation")
        assert c_res["status"] == "success"

        # 2. Read
        r_res = read_file(test_file)
        assert r_res["status"] == "success"
        assert "Hello JARVIS Automation" in r_res["content"]

        # 3. Search
        s_res = search_files("test_doc*", search_dir=tmpdir)
        assert s_res["count"] >= 1

        # 4. Rename
        renamed_res = rename_file(test_file, "renamed_doc.txt")
        assert renamed_res["status"] == "success"
        new_path = renamed_res["new_path"]

        # 5. Delete
        d_res = delete_file(new_path)
        assert d_res["status"] == "success"
        assert not os.path.exists(new_path)


def test_system_benchmark_plugin():
    plugin = SystemBenchmarkPlugin()
    res = plugin.run_benchmark(iterations=100000)
    assert res["iterations"] == 100000
    assert "duration_seconds" in res
    assert res["benchmark_score"] >= 0
