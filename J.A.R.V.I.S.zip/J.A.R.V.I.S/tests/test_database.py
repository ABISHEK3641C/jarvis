"""Unit tests for JARVIS Database operations."""
import os
import tempfile
import pytest
from app.core.database import Database


@pytest.fixture
def temp_db():
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    db = Database(db_path=path)
    yield db
    db.close()
    if os.path.exists(path):
        try:
            os.remove(path)
        except Exception:
            pass


def test_settings_persistence(temp_db):
    temp_db.set_setting("theme", "cyberpunk")
    temp_db.set_setting("rate", 190)
    temp_db.set_setting("complex_dict", {"a": 1, "b": 2})

    assert temp_db.get_setting("theme") == "cyberpunk"
    assert temp_db.get_setting("rate") == 190
    assert temp_db.get_setting("complex_dict") == {"a": 1, "b": 2}
    assert temp_db.get_setting("non_existent", default="default_val") == "default_val"


def test_custom_apps(temp_db):
    assert temp_db.add_custom_app("Photoshop", "C:\\Program Files\\Adobe\\Photoshop.exe")
    apps = temp_db.list_custom_apps()
    assert len(apps) == 1
    assert apps[0]["name"] == "Photoshop"
    assert apps[0]["path"] == "C:\\Program Files\\Adobe\\Photoshop.exe"

    assert temp_db.remove_custom_app("Photoshop")
    assert len(temp_db.list_custom_apps()) == 0
