export type AudioState = 'idle' | 'listening' | 'thinking' | 'speaking';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'BLOCKED';

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  timestamp: string;
  language?: string;
  riskLevel?: RiskLevel;
  toolCalls?: ToolCall[];
  toolResults?: ToolResult[];
}

export interface ToolCall {
  id: string;
  name: string;
  args: Record<string, any>;
}

export interface ToolResult {
  toolName: string;
  success: boolean;
  data?: any;
  error?: string;
  riskLevel: RiskLevel;
}

export interface PendingConfirmation {
  id: string;
  toolName: string;
  parameters: Record<string, any>;
  riskLevel: RiskLevel;
  reason: string;
  targetSummary: string;
  irreversible?: boolean;
}

export interface SystemMetrics {
  os: string;
  platform: string;
  cpu_model: string;
  cpu_cores: number;
  cpu_percent: number;
  ram_total_gb: string;
  ram_used_gb: string;
  ram_percent: number;
  disk_total_gb: number;
  disk_used_gb: number;
  disk_free_gb: number;
  battery_percent: number;
  is_charging: boolean;
  uptime_seconds: number;
}

export interface MemoryItem {
  id: number;
  category: string;
  content: string;
  tags: string;
  updated_at: string;
}

export interface ReminderItem {
  id: number;
  title: string;
  due_time: string;
  recurrence: string;
  is_completed: boolean;
}

export interface NoteItem {
  id: number;
  title: string;
  body: string;
  tags: string;
  created_at: string;
}

export interface AuditEntry {
  timestamp: string;
  tool_name: string;
  risk_level: RiskLevel;
  decision: string;
  parameters: string;
  details?: string;
}

export interface AssistantConfig {
  aiProvider: 'cloud' | 'local' | 'auto';
  cloudModel: string;
  language: 'en' | 'hi' | 'hinglish' | 'auto';
  voiceName: string;
  speechRate: number;
  speechPitch: number;
  wakeWord: string;
  wakeWordEnabled: boolean;
  continuousListening: boolean;
  handsFreeMode: boolean;
  autoSpeak: boolean;
  silenceThresholdMs: number;
  requireHighRiskConfirmation: boolean;
  requireMediumRiskConfirmation: boolean;
  allowScreenCapture: boolean;
  auditLogging: boolean;
  theme: 'dark' | 'light';
  offlineMode: boolean;
  approvedDirectories: string[];
}

