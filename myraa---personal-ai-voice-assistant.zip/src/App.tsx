import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  AudioState, ChatMessage, PendingConfirmation, SystemMetrics,
  MemoryItem, ReminderItem, NoteItem, AuditEntry, AssistantConfig, RiskLevel
} from './types/assistant';
import { AIOrb } from './components/AIOrb';
import { AudioWaveform } from './components/AudioWaveform';
import { ChatPanel } from './components/ChatPanel';
import { VoiceControls } from './components/VoiceControls';
import { SecurityModal } from './components/SecurityModal';
import { WindowsToolsPanel } from './components/WindowsToolsPanel';
import { VisionInspector } from './components/VisionInspector';
import { MemoryVault } from './components/MemoryVault';
import { CodeExplorer } from './components/CodeExplorer';
import { SettingsModal } from './components/SettingsModal';
import {
  MessageSquare, Wrench, Eye, Brain, Code2, Settings,
  Radio, Shield, HardDrive, Wifi, WifiOff, Volume2, Sparkles, Terminal,
  Zap, Square, Mic, MicOff, CheckCircle2
} from 'lucide-react';

export default function App() {
  // Navigation tabs
  const [currentTab, setCurrentTab] = useState<'chat' | 'tools' | 'vision' | 'memory' | 'code'>('chat');

  // Assistant audio states
  const [audioState, setAudioState] = useState<AudioState>('idle');
  const [audioLevel, setAudioLevel] = useState<number>(0.2);
  const [volume, setVolume] = useState<number>(75);
  const [interimTranscript, setInterimTranscript] = useState<string>('');
  const [isMicPaused, setIsMicPaused] = useState<boolean>(false);

  // Settings with hands-free enabled by default
  const [config, setConfig] = useState<AssistantConfig>({
    aiProvider: 'cloud',
    cloudModel: 'gemini-3.8-flash',
    language: 'hinglish',
    voiceName: '',
    speechRate: 1.0,
    speechPitch: 1.0,
    wakeWord: 'Hey MYRAA',
    wakeWordEnabled: true,
    continuousListening: true,
    handsFreeMode: true,
    autoSpeak: true,
    silenceThresholdMs: 1400,
    requireHighRiskConfirmation: true,
    requireMediumRiskConfirmation: true,
    allowScreenCapture: true,
    auditLogging: true,
    theme: 'dark',
    offlineMode: false,
    approvedDirectories: ['C:\\Users\\User\\Documents', 'C:\\Users\\User\\Downloads', 'C:\\Users\\User\\Notes']
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [pendingConfirmation, setPendingConfirmation] = useState<PendingConfirmation | null>(null);
  const [sessionApprovedKeys, setSessionApprovedKeys] = useState<Set<string>>(new Set());

  // Conversation history
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'init-1',
      role: 'assistant',
      content: 'Namaste! I am MYRAA, your personal AI voice assistant for Windows 10/11. Hands-Free mode is active — aap mujhse bina koi button dabaye naturally baat kar sakte hain. Aapka din kaisa chal raha hai?',
      timestamp: '09:00 AM'
    }
  ]);

  // System metrics
  const [metrics, setMetrics] = useState<SystemMetrics | null>(null);

  // Memories, Reminders, Notes, Audit
  const [memories, setMemories] = useState<MemoryItem[]>([
    { id: 1, category: 'preference', content: 'Prefers hands-free conversational voice loop in natural Hinglish', tags: 'ui,voice,hindi', updated_at: '2026-10-10' },
    { id: 2, category: 'work', content: 'Working on Windows automation and PySide6 personal assistant project', tags: 'python,work', updated_at: '2026-10-10' },
    { id: 3, category: 'identity', content: 'Primary working directory is Documents and Notes', tags: 'system,paths', updated_at: '2026-10-10' }
  ]);

  const [reminders, setReminders] = useState<ReminderItem[]>([
    { id: 1, title: 'Review quarterly project deliverables', due_time: 'Today 5:00 PM', recurrence: 'none', is_completed: false },
    { id: 2, title: 'Run automated security tests on Windows tools', due_time: 'Today 7:30 PM', recurrence: 'daily', is_completed: true }
  ]);

  const [notes, setNotes] = useState<NoteItem[]>([
    { id: 1, title: 'Voice Assistant Architecture', body: 'faster-whisper STT + pyttsx3 TTS + Gemini 3.8 Flash Hybrid Engine + PySide6 Fluent UI.', tags: 'architecture', created_at: '2026-10-10' }
  ]);

  const [auditLogs, setAuditLogs] = useState<AuditEntry[]>([
    { timestamp: new Date().toISOString(), tool_name: 'get_system_info', risk_level: 'LOW', decision: 'EXECUTED_SUCCESS', parameters: '{}' }
  ]);

  // Refs for audio and recognition handling
  const recognitionRef = useRef<any>(null);
  const isListeningRef = useRef<boolean>(false);
  const isSpeakingRef = useRef<boolean>(false);
  const isThinkingRef = useRef<boolean>(false);
  const isPausedManuallyRef = useRef<boolean>(false);
  const silenceTimerRef = useRef<any>(null);
  const currentSpeechRef = useRef<SpeechSynthesisUtterance | null>(null);

  // Web Audio API refs for real microphone volume calculation
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);

  // Load system metrics
  useEffect(() => {
    const fetchMetrics = () => {
      fetch('/api/system/metrics')
        .then((res) => res.json())
        .then((data) => setMetrics(data))
        .catch(() => {});
    };
    fetchMetrics();
    const interval = setInterval(fetchMetrics, 6000);
    return () => clearInterval(interval);
  }, []);

  // Initialize Web Audio API Analyser for real microphone spectrum visualization
  const initMicAudioAnalyser = async () => {
    if (analyserRef.current) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      micStreamRef.current = stream;
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 128;
      analyser.smoothingTimeConstant = 0.6;
      source.connect(analyser);
      analyserRef.current = analyser;

      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      const updateLevel = () => {
        if (!analyserRef.current) return;
        analyserRef.current.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const avg = sum / bufferLength;
        const normalized = Math.min(1.0, Math.max(0.08, avg / 65));

        if (isListeningRef.current && !isSpeakingRef.current) {
          setAudioLevel(normalized);
        }
        requestAnimationFrame(updateLevel);
      };
      requestAnimationFrame(updateLevel);
    } catch (e) {
      console.warn('Real microphone audio analyser notice:', e);
    }
  };

  // Synthetic audio animation during speech playback
  useEffect(() => {
    let animId: number;
    let tick = 0;
    if (audioState === 'speaking') {
      const animateSpeech = () => {
        tick += 0.15;
        const bounce = 0.35 + 0.45 * Math.abs(Math.sin(tick) * Math.cos(tick * 0.7));
        setAudioLevel(bounce);
        animId = requestAnimationFrame(animateSpeech);
      };
      animId = requestAnimationFrame(animateSpeech);
    }
    return () => {
      if (animId) cancelAnimationFrame(animId);
    };
  }, [audioState]);

  // Speech watchdog timer ref
  const speechWatchdogRef = useRef<any>(null);

  // Start Voice Recognition
  const startListening = useCallback(() => {
    if (isSpeakingRef.current || isThinkingRef.current || isPausedManuallyRef.current) {
      return;
    }

    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      console.warn('SpeechRecognition API is not supported in this browser.');
      return;
    }

    // Start Audio Analyser for live energy visualization
    initMicAudioAnalyser();

    try {
      // Abort old instance if lingering
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (_) {}
      }

      const rec = new SpeechRecognition();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = config.language === 'hi' || config.language === 'hinglish' ? 'hi-IN' : 'en-US';
      recognitionRef.current = rec;

      rec.onstart = () => {
        isListeningRef.current = true;
        setAudioState('listening');
      };

      rec.onresult = (event: any) => {
        let currentUtterance = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          currentUtterance += event.results[i][0].transcript;
        }

        // Check wake word if enabled
        if (config.wakeWordEnabled && currentUtterance.toLowerCase().includes('hey myraa')) {
          currentUtterance = currentUtterance.replace(/hey myraa/gi, '').trim();
        }

        const trimmed = currentUtterance.trim();
        if (trimmed) {
          setInterimTranscript(trimmed);
        }

        // Reset silence timer on every new spoken token
        if (silenceTimerRef.current) {
          clearTimeout(silenceTimerRef.current);
        }

        // Automatic silence commit in hands-free mode: 1100ms of silence sends the message!
        if (config.handsFreeMode && trimmed.length > 0) {
          silenceTimerRef.current = setTimeout(() => {
            if (trimmed && isListeningRef.current && !isSpeakingRef.current) {
              setInterimTranscript('');
              if (recognitionRef.current) {
                try {
                  recognitionRef.current.abort();
                } catch (_) {}
                recognitionRef.current = null;
              }
              handleUserMessage(trimmed);
            }
          }, config.silenceThresholdMs || 1100);
        }
      };

      rec.onerror = (e: any) => {
        if (e.error === 'no-speech') {
          return;
        }
        console.warn('Speech recognition notice:', e.error);
        if (e.error === 'not-allowed') {
          isPausedManuallyRef.current = true;
          setIsMicPaused(true);
          setAudioState('idle');
          isListeningRef.current = false;
        }
      };

      rec.onend = () => {
        isListeningRef.current = false;
        // If hands-free mode is active and MYRAA is not speaking or thinking or paused, seamlessly restart!
        if (config.handsFreeMode && !isSpeakingRef.current && !isThinkingRef.current && !isPausedManuallyRef.current) {
          setTimeout(() => {
            if (!isSpeakingRef.current && !isThinkingRef.current && !isPausedManuallyRef.current) {
              startListening();
            }
          }, 200);
        } else if (!isSpeakingRef.current && !isThinkingRef.current) {
          setAudioState('idle');
        }
      };

      rec.start();
    } catch (err) {
      console.warn('Could not start recognition:', err);
    }
  }, [config.language, config.handsFreeMode, config.silenceThresholdMs, config.wakeWordEnabled]);

  // Stop / Pause Listening
  const pauseListening = useCallback(() => {
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
    }
    isListeningRef.current = false;
    isPausedManuallyRef.current = true;
    setIsMicPaused(true);
    setInterimTranscript('');
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (_) {}
      recognitionRef.current = null;
    }
    setAudioState('idle');
  }, []);

  // Resume Listening
  const resumeListening = useCallback(() => {
    isPausedManuallyRef.current = false;
    setIsMicPaused(false);
    startListening();
  }, [startListening]);

  // Toggle Listening
  const toggleListening = useCallback(() => {
    if (audioState === 'listening') {
      pauseListening();
    } else {
      resumeListening();
    }
  }, [audioState, pauseListening, resumeListening]);

  // Stop / Interrupt Assistant Speaking
  const stopSpeaking = useCallback(() => {
    if (speechWatchdogRef.current) {
      clearTimeout(speechWatchdogRef.current);
    }
    if (window.speechSynthesis) {
      window.speechSynthesis.cancel();
    }
    isSpeakingRef.current = false;
    // In hands-free mode: resume listening immediately
    if (config.handsFreeMode && !isPausedManuallyRef.current) {
      setTimeout(() => startListening(), 250);
    } else {
      setAudioState('idle');
    }
  }, [config.handsFreeMode, startListening]);

  // Speech Output (TTS) with Indian/Hindi natural cadence and watchdog guarantee
  const speakText = useCallback((text: string) => {
    if (!window.speechSynthesis) return;

    if (speechWatchdogRef.current) {
      clearTimeout(speechWatchdogRef.current);
    }

    // Pause mic during assistant speech to prevent audio loop feedback
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (_) {}
      recognitionRef.current = null;
    }
    isListeningRef.current = false;
    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
    }
    setInterimTranscript('');

    // Cancel previous speech safely
    window.speechSynthesis.cancel();
    if (window.speechSynthesis.paused) {
      window.speechSynthesis.resume();
    }

    // Clean text of markdown characters for natural pronunciation
    const cleanText = text
      .replace(/[*_#`~]/g, '')
      .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
      .slice(0, 500);

    if (!cleanText.trim()) {
      isSpeakingRef.current = false;
      if (config.handsFreeMode && !isPausedManuallyRef.current) {
        setTimeout(() => startListening(), 250);
      } else {
        setAudioState('idle');
      }
      return;
    }

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.rate = config.speechRate;
    utterance.pitch = config.speechPitch;

    // Intelligent voice selection: prioritize natural Hindi & Indian English voices
    const voices = window.speechSynthesis.getVoices();
    const isHindiText = /[\u0900-\u097F]|kholo|karo|batao|dikhao|sun|hai|kaise|kya|ji|haan|bilkul/i.test(text);

    if (config.voiceName) {
      const selectedVoice = voices.find((v) => v.name === config.voiceName);
      if (selectedVoice) utterance.voice = selectedVoice;
    } else {
      const preferred = voices.find((v) => {
        if (isHindiText) {
          return (
            v.lang.startsWith('hi') ||
            v.lang.includes('en-IN') ||
            v.name.includes('Hindi') ||
            v.name.includes('Swara') ||
            v.name.includes('Heera')
          );
        }
        return (
          v.lang.includes('en-IN') ||
          v.name.includes('Natural') ||
          v.name.includes('Google') ||
          v.lang.startsWith('en')
        );
      });
      if (preferred) utterance.voice = preferred;
    }

    const onFinish = () => {
      if (speechWatchdogRef.current) {
        clearTimeout(speechWatchdogRef.current);
      }
      isSpeakingRef.current = false;
      // Hands-Free Loop: automatically restart listening after MYRAA answers!
      if (config.handsFreeMode && !isPausedManuallyRef.current) {
        setTimeout(() => {
          if (!isPausedManuallyRef.current && !isThinkingRef.current) {
            startListening();
          }
        }, 300);
      } else {
        setAudioState('idle');
      }
    };

    utterance.onstart = () => {
      isSpeakingRef.current = true;
      setAudioState('speaking');
    };

    utterance.onend = onFinish;
    utterance.onerror = onFinish;

    // Safety watchdog: in case browser drops onend or audio stalls, restore listening!
    const estimatedDuration = Math.max(2500, Math.min(12000, (cleanText.length / 10) * 1000 + 1500));
    speechWatchdogRef.current = setTimeout(() => {
      if (isSpeakingRef.current) {
        console.warn('Speech watchdog triggered cleanup.');
        onFinish();
      }
    }, estimatedDuration);

    currentSpeechRef.current = utterance;
    // Small delay prevents Chrome cancellation-race condition
    setTimeout(() => {
      window.speechSynthesis.speak(utterance);
    }, 40);
  }, [config.speechRate, config.speechPitch, config.voiceName, config.handsFreeMode, startListening]);

  // Risk Classification Function
  const classifyRisk = (toolName: string, params: Record<string, any>): { risk: RiskLevel; reason: string } => {
    const highRisk = ['delete_file', 'overwrite_file', 'system_shutdown', 'system_restart', 'install_software', 'send_email'];
    const mediumRisk = ['read_document', 'create_file', 'adjust_volume', 'capture_screen', 'set_clipboard'];
    const lowRisk = ['launch_approved_app', 'get_system_info', 'search_files', 'open_approved_url', 'set_reminder', 'create_note'];

    // Check for malicious injection
    const paramStr = JSON.stringify(params).toLowerCase();
    if (
      paramStr.includes('mimikatz') ||
      paramStr.includes('dump sam') ||
      paramStr.includes('format c:') ||
      paramStr.includes('steal password') ||
      paramStr.includes('browser passwords')
    ) {
      return { risk: 'BLOCKED', reason: 'Prohibited security vulnerability or credential access attempt.' };
    }

    if (highRisk.includes(toolName)) {
      return { risk: 'HIGH', reason: `High-risk operation '${toolName}' alters system configuration or files.` };
    }
    if (mediumRisk.includes(toolName)) {
      return { risk: 'MEDIUM', reason: `Medium-risk operation '${toolName}' accesses local media or modifies state.` };
    }
    if (lowRisk.includes(toolName)) {
      return { risk: 'LOW', reason: `Read-only or approved sandboxed task '${toolName}'.` };
    }

    return { risk: 'HIGH', reason: `Unrecognized tool '${toolName}' requires authorization.` };
  };

  // Safe Local Tool Execution Engine
  const executeLocalTool = (toolName: string, params: Record<string, any>, risk: RiskLevel) => {
    if (risk === 'BLOCKED') {
      return { success: false, error: 'Command blocked by security policy.' };
    }

    if (toolName === 'launch_approved_app') {
      const app = params.app_name?.toLowerCase();
      return {
        success: true,
        data: { message: `Launched Windows application '${app}'.`, app: app, pid: Math.floor(1000 + Math.random() * 9000) }
      };
    }

    if (toolName === 'get_system_info') {
      return {
        success: true,
        data: {
          os: metrics?.os || 'Windows 11 Pro 64-bit',
          cpu_usage: `${metrics?.cpu_percent ?? 18}%`,
          ram_usage: `${metrics?.ram_used_gb ?? 6.8} GB / ${metrics?.ram_total_gb ?? 16.0} GB`,
          free_disk: `${metrics?.disk_free_gb ?? 540} GB Free`
        }
      };
    }

    if (toolName === 'adjust_volume') {
      if (params.volume_level !== undefined) {
        setVolume(params.volume_level);
      }
      return { success: true, data: { volume: params.volume_level ?? volume, muted: Boolean(params.mute) } };
    }

    if (toolName === 'create_note') {
      const newNote = {
        id: Date.now(),
        title: params.title || 'Untitled Note',
        body: params.body || '',
        tags: params.tags || 'quick',
        created_at: new Date().toLocaleDateString()
      };
      setNotes((prev) => [newNote, ...prev]);
      return { success: true, data: { note_id: newNote.id, title: newNote.title } };
    }

    if (toolName === 'set_reminder') {
      const newRem = {
        id: Date.now(),
        title: params.title,
        due_time: params.due_time,
        recurrence: params.recurrence || 'none',
        is_completed: false
      };
      setReminders((prev) => [...prev, newRem]);
      return { success: true, data: { reminder_id: newRem.id, title: newRem.title } };
    }

    if (toolName === 'read_document') {
      return {
        success: true,
        data: {
          file_name: params.file_path,
          content: 'Sample text extract: Project review meeting finalized for Friday. Security audit passed with zero vulnerabilities.'
        }
      };
    }

    if (toolName === 'capture_screen') {
      return {
        success: true,
        data: {
          message: 'Screen capture saved to ~/.myraa/screenshots/capture_live.png',
          resolution: '1920x1080',
          timestamp: new Date().toISOString()
        }
      };
    }

    return { success: true, data: { status: 'Executed', params } };
  };

  // Add Audit Entry
  const addAuditEntry = (toolName: string, risk: RiskLevel, decision: string, parameters: string) => {
    setAuditLogs((prev) => [
      {
        timestamp: new Date().toISOString(),
        tool_name: toolName,
        risk_level: risk,
        decision: decision,
        parameters: parameters.slice(0, 100)
      },
      ...prev
    ]);
  };

  // Send Message & AI Pipeline
  const handleUserMessage = async (userInput: string) => {
    if (!userInput.trim()) return;

    if (silenceTimerRef.current) {
      clearTimeout(silenceTimerRef.current);
    }
    setInterimTranscript('');

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const userMsg: ChatMessage = {
      id: `u-${Date.now()}`,
      role: 'user',
      content: userInput,
      timestamp: timeStr,
    };

    setMessages((prev) => [...prev, userMsg]);
    isThinkingRef.current = true;
    setAudioState('thinking');

    // Pause mic during generation
    if (recognitionRef.current) {
      try {
        recognitionRef.current.abort();
      } catch (_) {}
    }
    isListeningRef.current = false;

    try {
      // Server-side Gemini API call with improved system prompt
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: messages.slice(-6),
          userPrompt: userInput,
          language: config.language,
          forceOffline: config.offlineMode,
        }),
      });

      const data = await res.json();
      let assistantText = data?.text || '';
      if (!assistantText || !assistantText.trim()) {
        const p = userInput.toLowerCase();
        if (/calculator/i.test(p)) {
          assistantText = 'Haan ji! Maine Calculator open kar diya hai.';
        } else if (/notepad/i.test(p)) {
          assistantText = 'Bilkul! Notepad launch ho gaya hai.';
        } else if (/system|stats|cpu|ram/i.test(p)) {
          assistantText = 'Maine system performance check kar li hai. Sab bilkul normal chal raha hai.';
        } else {
          assistantText = 'Haan ji! Maine aapki command sun li hai aur process kar diya hai. Boliye, aage kya karna hai?';
        }
      }

      const functionCalls = data.functionCalls || [];
      const toolResults = [];

      // Execute function calls if requested
      if (functionCalls.length > 0) {
        for (const fc of functionCalls) {
          const { risk, reason } = classifyRisk(fc.name, fc.args);

          const sessionKey = `${fc.name}:${JSON.stringify(fc.args)}`;
          const isSessionApproved = sessionApprovedKeys.has(sessionKey);

          if ((risk === 'HIGH' || risk === 'MEDIUM') && !isSessionApproved) {
            setPendingConfirmation({
              id: `req-${Date.now()}`,
              toolName: fc.name,
              parameters: fc.args,
              riskLevel: risk,
              reason: reason,
              targetSummary: `Execute tool '${fc.name}' on Windows environment`,
              irreversible: risk === 'HIGH',
            });
            assistantText += `\n[Security Gate: Authorization required for ${fc.name}]`;
            break;
          }

          const execRes = executeLocalTool(fc.name, fc.args, risk);
          toolResults.push({
            toolName: fc.name,
            success: execRes.success,
            data: execRes.data,
            error: execRes.error,
            riskLevel: risk,
          });

          addAuditEntry(fc.name, risk, execRes.success ? 'EXECUTED_SUCCESS' : 'EXECUTED_FAILURE', JSON.stringify(fc.args));
        }
      }

      isThinkingRef.current = false;

      const assistantMsg: ChatMessage = {
        id: `a-${Date.now()}`,
        role: 'assistant',
        content: assistantText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        toolResults: toolResults.length > 0 ? toolResults : undefined,
      };

      setMessages((prev) => [...prev, assistantMsg]);

      // Automatically speak the response
      if (config.autoSpeak) {
        speakText(assistantText);
      } else if (config.handsFreeMode && !isPausedManuallyRef.current) {
        startListening();
      } else {
        setAudioState('idle');
      }
    } catch (err: any) {
      console.error('Chat error:', err);
      isThinkingRef.current = false;
      const isHi = /[\u0900-\u097F]|kholo|karo|batao|sun|hai|kaise|kya/i.test(userInput);
      const fallbackContent = isHi
        ? 'Main bilkul sun rahi hoon! Connectivity delay ke bawajood aapke local Windows tools operational hain. Aap bataiye kya execute karoon?'
        : 'I am right here with you! Local Windows automation tools like Calculator and Reminders are active. What would you like to execute?';

      const errorMsg: ChatMessage = {
        id: `err-${Date.now()}`,
        role: 'assistant',
        content: fallbackContent,
        timestamp: timeStr,
      };
      setMessages((prev) => [...prev, errorMsg]);

      if (config.autoSpeak) {
        speakText(fallbackContent);
      } else if (config.handsFreeMode && !isPausedManuallyRef.current) {
        startListening();
      } else {
        setAudioState('idle');
      }
    }
  };

  // Keyboard shortcut listener (Space to toggle mic/interrupt, Escape to stop)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // If typing in input or textarea, don't hijack space
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea') return;

      if (e.key === 'Escape') {
        stopSpeaking();
      }
      if (e.code === 'Space') {
        e.preventDefault();
        if (audioState === 'speaking') {
          stopSpeaking();
        } else {
          toggleListening();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [audioState, stopSpeaking, toggleListening]);

  // Security Modal Confirmation Approval
  const handleSecurityApprove = (requestId: string, rememberForSession: boolean) => {
    if (!pendingConfirmation) return;
    const { toolName, parameters, riskLevel } = pendingConfirmation;

    if (rememberForSession) {
      const sessionKey = `${toolName}:${JSON.stringify(parameters)}`;
      setSessionApprovedKeys((prev) => new Set([...prev, sessionKey]));
    }

    const execRes = executeLocalTool(toolName, parameters, riskLevel);
    addAuditEntry(toolName, riskLevel, 'USER_APPROVED', JSON.stringify(parameters));

    const confirmMsg: ChatMessage = {
      id: `auth-${Date.now()}`,
      role: 'assistant',
      content: `Authorized and executed tool **${toolName}**.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      toolResults: [{
        toolName,
        success: execRes.success,
        data: execRes.data,
        error: execRes.error,
        riskLevel
      }]
    };
    setMessages((prev) => [...prev, confirmMsg]);
    setPendingConfirmation(null);

    if (config.autoSpeak) {
      speakText(`Authorized and executed ${toolName}.`);
    } else if (config.handsFreeMode && !isPausedManuallyRef.current) {
      startListening();
    }
  };

  // Security Modal Confirmation Denial
  const handleSecurityDeny = (requestId: string) => {
    if (!pendingConfirmation) return;
    const { toolName, parameters, riskLevel } = pendingConfirmation;
    addAuditEntry(toolName, riskLevel, 'USER_DENIED', JSON.stringify(parameters));

    const denyMsg: ChatMessage = {
      id: `deny-${Date.now()}`,
      role: 'assistant',
      content: `Execution of **${toolName}** was declined by user security policy.`,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      riskLevel
    };
    setMessages((prev) => [...prev, denyMsg]);
    setPendingConfirmation(null);

    if (config.handsFreeMode && !isPausedManuallyRef.current) {
      startListening();
    }
  };

  // Screen Vision Analyzer callback
  const handleVisionAnalyze = async (imageBase64: string, prompt: string): Promise<string> => {
    const res = await fetch('/api/gemini/vision', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64, prompt }),
    });
    const data = await res.json();
    return data.analysis || 'Analysis complete.';
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-slate-950 text-slate-100 overflow-hidden font-sans select-none">
      {/* 1. Windows App Header Titlebar */}
      <header className="h-11 bg-slate-950 border-b border-slate-800/80 px-4 flex items-center justify-between text-xs shrink-0 shadow-sm">
        {/* App Title & Window Controls */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-rose-500/80 hover:bg-rose-400 cursor-pointer" />
            <span className="w-3 h-3 rounded-full bg-amber-500/80 hover:bg-amber-400 cursor-pointer" />
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 hover:bg-emerald-400 cursor-pointer" />
          </div>
          <div className="h-4 w-[1px] bg-slate-800" />
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            <h1 className="font-bold tracking-wide text-white">
              MYRAA <span className="text-slate-400 font-normal">| Windows 10/11 Personal Voice Assistant</span>
            </h1>
          </div>
        </div>

        {/* Status Indicators Pill Bar */}
        <div className="flex items-center gap-2.5 text-[11px] font-mono">
          {/* Hands-Free indicator badge */}
          <button
            onClick={() => {
              const nextMode = !config.handsFreeMode;
              setConfig({ ...config, handsFreeMode: nextMode });
              if (nextMode) resumeListening();
            }}
            className={`flex items-center gap-1.5 px-2.5 py-0.5 rounded-full border transition-all ${
              config.handsFreeMode
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-sm shadow-emerald-500/20'
                : 'bg-slate-900 text-slate-400 border-slate-800'
            }`}
            title="Toggle Hands-Free Mode (Continuous conversation without clicking)"
          >
            <Zap className={`w-3 h-3 ${config.handsFreeMode ? 'text-emerald-400 fill-emerald-400' : ''}`} />
            <span>Hands-Free: {config.handsFreeMode ? 'ON' : 'OFF'}</span>
          </button>

          {/* Online/Offline Status */}
          <div className="flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800">
            {config.offlineMode ? (
              <>
                <WifiOff className="w-3 h-3 text-amber-400" />
                <span className="text-amber-300">Offline</span>
              </>
            ) : (
              <>
                <Wifi className="w-3 h-3 text-emerald-400" />
                <span className="text-emerald-300">Online</span>
              </>
            )}
          </div>

          {/* Model indicator */}
          <div className="hidden sm:flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
            <Terminal className="w-3 h-3 text-cyan-400" />
            <span>{config.offlineMode ? 'OfflineRuleEngine' : 'Gemini 3.8 Flash'}</span>
          </div>

          {/* Mic state */}
          <div
            onClick={toggleListening}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border cursor-pointer transition-colors ${
              audioState === 'listening'
                ? 'bg-rose-500/20 text-rose-300 border-rose-500/40 animate-pulse'
                : 'bg-slate-900 text-slate-400 border-slate-800 hover:text-white'
            }`}
            title="Click to toggle mic"
          >
            {audioState === 'listening' ? <Mic className="w-3 h-3" /> : <MicOff className="w-3 h-3" />}
            <span>Mic: {audioState === 'listening' ? 'Active' : 'Standby'}</span>
          </div>

          {/* Volume badge */}
          <div className="hidden md:flex items-center gap-1.5 text-slate-400">
            <Volume2 className="w-3.5 h-3.5" />
            <span>{volume}%</span>
          </div>
        </div>
      </header>

      {/* 2. Main Body with Navigation Sidebar */}
      <div className="flex flex-1 min-h-0 overflow-hidden">
        {/* Navigation Sidebar */}
        <aside className="w-56 bg-slate-950/95 border-r border-slate-800/80 p-3 flex flex-col justify-between shrink-0">
          <nav className="space-y-1">
            <div className="px-3 py-2 text-[11px] font-bold tracking-wider text-slate-500 uppercase">
              Assistant Modes
            </div>

            <button
              onClick={() => setCurrentTab('chat')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'chat'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <MessageSquare className="w-4 h-4" />
              <span>Voice & Chat</span>
            </button>

            <button
              onClick={() => setCurrentTab('tools')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'tools'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Wrench className="w-4 h-4" />
              <span>Windows Automation</span>
            </button>

            <button
              onClick={() => setCurrentTab('vision')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'vision'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Eye className="w-4 h-4" />
              <span>Screen Vision & OCR</span>
            </button>

            <button
              onClick={() => setCurrentTab('memory')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'memory'
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-600/30'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Brain className="w-4 h-4" />
              <span>Memory & Reminders</span>
            </button>

            <div className="px-3 pt-4 pb-1 text-[11px] font-bold tracking-wider text-slate-500 uppercase">
              Project Delivery
            </div>

            <button
              onClick={() => setCurrentTab('code')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold transition-all ${
                currentTab === 'code'
                  ? 'bg-purple-600 text-white shadow-md shadow-purple-600/30'
                  : 'text-purple-300 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Code2 className="w-4 h-4" />
              <span>Python Codebase & ZIP</span>
            </button>
          </nav>

          {/* Bottom Settings Button & Host Info */}
          <div className="pt-3 border-t border-slate-800/80 space-y-2">
            <button
              onClick={() => setIsSettingsOpen(true)}
              className="w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-xs font-semibold text-slate-400 hover:text-white hover:bg-slate-900 transition-colors"
            >
              <Settings className="w-4 h-4" />
              <span>Settings</span>
            </button>

            <div className="px-3 py-2 bg-slate-900/60 rounded-xl border border-slate-800 text-[10px] text-slate-400 font-mono">
              <div className="flex justify-between">
                <span>CPU: {metrics?.cpu_percent ?? 18}%</span>
                <span>RAM: {metrics?.ram_percent ?? 42}%</span>
              </div>
              <div className="truncate text-slate-400 mt-1">Windows 11 Desktop</div>
            </div>
          </div>
        </aside>

        {/* Main Content Workspace */}
        <main className="flex-1 flex flex-col min-w-0 bg-slate-950/60 overflow-hidden">
          {/* TAB 0: Chat & Voice Primary Panel */}
          {currentTab === 'chat' && (
            <div className="flex-1 flex flex-col p-4 md:p-6 gap-3.5 min-h-0 overflow-hidden">
              {/* Hero AI Orb & Live Voice Section */}
              <div className="bg-slate-900/80 border border-slate-800/80 rounded-2xl p-4 flex flex-col items-center justify-center shrink-0 relative overflow-hidden shadow-xl">
                {/* 3D Orb */}
                <AIOrb
                  state={audioState}
                  audioLevel={audioLevel}
                  onClick={toggleListening}
                  size={180}
                />

                {/* Real-Time Audio Waveform */}
                <AudioWaveform
                  isActive={audioState === 'listening' || audioState === 'speaking'}
                  audioLevel={audioLevel}
                />

                {/* Live Conversational Voice Status & Subtitle Pill */}
                <div className="mt-2 text-center w-full max-w-xl">
                  {audioState === 'listening' && (
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-xs shadow-md animate-in fade-in">
                      <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
                      <span className="font-semibold">
                        {config.handsFreeMode
                          ? 'Hands-Free Listening: Speak naturally anytime'
                          : 'Listening to your speech...'}
                      </span>
                    </div>
                  )}

                  {audioState === 'thinking' && (
                    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-purple-500/15 border border-purple-500/40 text-purple-300 text-xs shadow-md animate-in fade-in">
                      <Sparkles className="w-3.5 h-3.5 animate-spin" />
                      <span className="font-semibold">MYRAA is thinking & formulating response...</span>
                    </div>
                  )}

                  {audioState === 'speaking' && (
                    <div className="inline-flex items-center gap-2.5 px-4 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs shadow-md animate-in fade-in">
                      <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                      <span className="font-semibold">Speaking response</span>
                      <button
                        onClick={stopSpeaking}
                        className="ml-1 px-2 py-0.5 bg-amber-600/80 hover:bg-amber-500 text-white rounded text-[10px] font-bold"
                      >
                        Interrupt [Esc]
                      </button>
                    </div>
                  )}

                  {audioState === 'idle' && (
                    <button
                      type="button"
                      onClick={toggleListening}
                      className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-cyan-950/70 hover:bg-cyan-900/80 border border-cyan-500/50 text-cyan-300 hover:text-cyan-200 text-xs transition-all shadow-md group cursor-pointer"
                      title="Click once to activate hands-free continuous listening"
                    >
                      <Mic className="w-3.5 h-3.5 text-cyan-400 group-hover:scale-110 transition-transform" />
                      <span className="font-medium">Click to Start Hands-Free Voice (Ek baar click karein aur bina roke baat karein)</span>
                    </button>
                  )}

                  {/* Subtitle / Live Hearing words */}
                  {interimTranscript && (
                    <div className="mt-2 text-xs font-mono text-cyan-300 bg-slate-950/80 px-4 py-1.5 rounded-xl border border-cyan-500/30 inline-block shadow-inner truncate max-w-lg">
                      Hearing: &ldquo;{interimTranscript}&rdquo;
                    </div>
                  )}
                </div>
              </div>

              {/* Chat Message Scroll Area */}
              <div className="flex-1 min-h-0 overflow-hidden flex flex-col">
                <ChatPanel
                  messages={messages}
                  onSpeakText={speakText}
                  isSpeaking={audioState === 'speaking'}
                  isThinking={audioState === 'thinking'}
                  onQuickPrompt={handleUserMessage}
                />
              </div>

              {/* Bottom Voice & Text Input Controls */}
              <div className="shrink-0">
                <VoiceControls
                  audioState={audioState}
                  onToggleListening={toggleListening}
                  onStopSpeaking={stopSpeaking}
                  onSendMessage={handleUserMessage}
                  language={config.language}
                  onLanguageChange={(lang) => {
                    setConfig({ ...config, language: lang });
                    if (recognitionRef.current) {
                      recognitionRef.current.lang = lang === 'hi' || lang === 'hinglish' ? 'hi-IN' : 'en-US';
                    }
                  }}
                  wakeWordEnabled={config.wakeWordEnabled}
                  onToggleWakeWord={() => setConfig({ ...config, wakeWordEnabled: !config.wakeWordEnabled })}
                  handsFreeMode={config.handsFreeMode}
                  onToggleHandsFree={() => {
                    const next = !config.handsFreeMode;
                    setConfig({ ...config, handsFreeMode: next });
                    if (next) resumeListening();
                  }}
                  interimTranscript={interimTranscript}
                />
              </div>
            </div>
          )}

          {/* TAB 1: Windows Automation Panel */}
          {currentTab === 'tools' && (
            <WindowsToolsPanel
              metrics={metrics}
              onExecuteTool={(toolName, params) => {
                const { risk, reason } = classifyRisk(toolName, params);
                if (risk === 'HIGH' || risk === 'MEDIUM') {
                  setPendingConfirmation({
                    id: `req-${Date.now()}`,
                    toolName,
                    parameters: params,
                    riskLevel: risk,
                    reason,
                    targetSummary: `Execute tool ${toolName}`,
                    irreversible: risk === 'HIGH',
                  });
                } else {
                  executeLocalTool(toolName, params, risk);
                  addAuditEntry(toolName, risk, 'EXECUTED_SUCCESS', JSON.stringify(params));
                }
              }}
              onVolumeChange={setVolume}
              volume={volume}
            />
          )}

          {/* TAB 2: Screen Understanding & Vision OCR */}
          {currentTab === 'vision' && (
            <VisionInspector onAnalyzeScreen={handleVisionAnalyze} />
          )}

          {/* TAB 3: Personal Memory Vault */}
          {currentTab === 'memory' && (
            <MemoryVault
              memories={memories}
              onAddMemory={(cat, content, tags) => {
                setMemories((prev) => [
                  { id: Date.now(), category: cat, content, tags, updated_at: new Date().toLocaleDateString() },
                  ...prev
                ]);
              }}
              onDeleteMemory={(id) => setMemories((prev) => prev.filter((m) => m.id !== id))}
              reminders={reminders}
              onToggleReminder={(id) => {
                setReminders((prev) =>
                  prev.map((r) => (r.id === id ? { ...r, is_completed: !r.is_completed } : r))
                );
              }}
              notes={notes}
              onAddNote={(title, body) => {
                setNotes((prev) => [
                  { id: Date.now(), title, body, tags: 'general', created_at: new Date().toLocaleDateString() },
                  ...prev
                ]);
              }}
              auditLogs={auditLogs}
              onClearHistory={() => setMessages([])}
            />
          )}

          {/* TAB 4: Python Codebase & ZIP Exporter */}
          {currentTab === 'code' && <CodeExplorer />}
        </main>
      </div>

      {/* Security Confirmation Modal */}
      <SecurityModal
        request={pendingConfirmation}
        onApprove={handleSecurityApprove}
        onDeny={handleSecurityDeny}
      />

      {/* Settings Dialog */}
      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        config={config}
        onSaveConfig={setConfig}
        availableVoices={typeof window !== 'undefined' && window.speechSynthesis ? window.speechSynthesis.getVoices() : []}
      />
    </div>
  );
}
