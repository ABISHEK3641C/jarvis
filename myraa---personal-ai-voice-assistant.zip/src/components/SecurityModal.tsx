import React, { useState } from 'react';
import { PendingConfirmation } from '../types/assistant';
import { ShieldAlert, AlertTriangle, CheckCircle, XCircle, Info, Lock } from 'lucide-react';

interface SecurityModalProps {
  request: PendingConfirmation | null;
  onApprove: (requestId: string, rememberForSession: boolean) => void;
  onDeny: (requestId: string) => void;
}

export const SecurityModal: React.FC<SecurityModalProps> = ({
  request,
  onApprove,
  onDeny,
}) => {
  const [remember, setRemember] = useState(false);

  if (!request) return null;

  const isHighRisk = request.riskLevel === 'HIGH';
  const isBlocked = request.riskLevel === 'BLOCKED';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl overflow-hidden">
        {/* Top risk accent banner */}
        <div
          className={`h-2 w-full ${
            isBlocked
              ? 'bg-rose-600'
              : isHighRisk
              ? 'bg-amber-500'
              : 'bg-blue-500'
          }`}
        />

        <div className="p-6">
          {/* Header */}
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex items-center gap-3">
              <div
                className={`p-2.5 rounded-xl ${
                  isBlocked
                    ? 'bg-rose-500/20 text-rose-400'
                    : isHighRisk
                    ? 'bg-amber-500/20 text-amber-400'
                    : 'bg-blue-500/20 text-blue-400'
                }`}
              >
                {isBlocked ? (
                  <Lock className="w-6 h-6" />
                ) : isHighRisk ? (
                  <ShieldAlert className="w-6 h-6" />
                ) : (
                  <AlertTriangle className="w-6 h-6" />
                )}
              </div>
              <div>
                <h3 className="text-lg font-bold text-white tracking-tight">
                  Security Authorization Required
                </h3>
                <p className="text-xs text-slate-400">
                  MYRAA Zero-Trust Policy Engine
                </p>
              </div>
            </div>

            <span
              className={`text-xs font-bold px-2.5 py-1 rounded-md tracking-wider uppercase ${
                isBlocked
                  ? 'bg-rose-950 text-rose-300 border border-rose-700'
                  : isHighRisk
                  ? 'bg-amber-950 text-amber-300 border border-amber-700'
                  : 'bg-blue-950 text-blue-300 border border-blue-700'
              }`}
            >
              {request.riskLevel} RISK
            </span>
          </div>

          {/* Policy Description */}
          <p className="text-sm text-slate-300 mb-4 leading-relaxed">
            {request.reason}
          </p>

          {/* Action details inspection card */}
          <div className="p-4 bg-slate-950/80 border border-slate-800 rounded-xl space-y-2 mb-4 font-mono text-xs">
            <div className="flex justify-between items-center text-slate-400">
              <span>TOOL REQUESTED:</span>
              <span className="text-cyan-400 font-semibold">{request.toolName}</span>
            </div>
            <div className="text-slate-400">
              <span>TARGET / PARAMETERS:</span>
              <pre className="mt-1 p-2 bg-slate-900 rounded border border-slate-800 text-slate-200 overflow-x-auto whitespace-pre-wrap">
                {JSON.stringify(request.parameters, null, 2)}
              </pre>
            </div>
            {request.targetSummary && (
              <div className="text-slate-400">
                <span>INTENT SUMMARY:</span>
                <p className="mt-0.5 text-slate-300 font-sans text-xs">
                  {request.targetSummary}
                </p>
              </div>
            )}
          </div>

          {/* Warning for High Risk */}
          {isHighRisk && (
            <div className="flex items-start gap-2.5 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl mb-4 text-xs text-amber-300">
              <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
              <span>
                <strong>Irreversible Action Warning:</strong> This operation may delete files, modify system configuration, or affect running applications. Verify the target before continuing.
              </span>
            </div>
          )}

          {/* Session Whitelist Option */}
          {!isBlocked && (
            <label className="flex items-center gap-2 mb-6 cursor-pointer select-none text-xs text-slate-400 hover:text-slate-300">
              <input
                type="checkbox"
                checked={remember}
                onChange={(e) => setRemember(e.target.checked)}
                className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-cyan-600 focus:ring-cyan-500 focus:ring-offset-slate-900"
              />
              <span>Remember approval for this exact command for the rest of this session</span>
            </label>
          )}

          {/* Buttons */}
          <div className="flex items-center justify-end gap-3">
            <button
              onClick={() => onDeny(request.id)}
              className="px-4 py-2 text-xs font-semibold text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <XCircle className="w-4 h-4" />
              Deny & Block Action
            </button>

            {!isBlocked && (
              <button
                onClick={() => onApprove(request.id, remember)}
                className="px-5 py-2 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-md shadow-emerald-700/30 flex items-center gap-1.5"
              >
                <CheckCircle className="w-4 h-4" />
                Authorize Execution
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
