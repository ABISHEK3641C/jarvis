import React, { useEffect, useState } from 'react';

interface AudioWaveformProps {
  isActive: boolean;
  audioLevel?: number;
  barCount?: number;
}

export const AudioWaveform: React.FC<AudioWaveformProps> = ({
  isActive,
  audioLevel = 0.2,
  barCount = 36,
}) => {
  const [bars, setBars] = useState<number[]>(() => new Array(barCount).fill(0.08));

  useEffect(() => {
    let animId: number;
    let step = 0;

    const animate = () => {
      step += 0.08;
      setBars((prev) =>
        prev.map((val, idx) => {
          let target = 0.08;
          if (isActive) {
            // Harmonic wave modulated by audio level
            const wave1 = Math.sin(idx * 0.35 + step) * 0.4;
            const wave2 = Math.cos(idx * 0.2 - step * 1.2) * 0.3;
            const centerPeak = Math.sin((idx / barCount) * Math.PI);
            target = Math.max(
              0.08,
              Math.min(1.0, (0.2 + wave1 + wave2) * centerPeak * (0.6 + audioLevel * 1.4))
            );
          }
          // Smooth interpolation
          return val + (target - val) * 0.25;
        })
      );
      animId = requestAnimationFrame(animate);
    };

    animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, [isActive, audioLevel, barCount]);

  return (
    <div className="w-full flex items-center justify-center gap-[3px] h-10 px-4 py-1">
      {bars.map((height, i) => (
        <div
          key={i}
          className={`w-[3px] rounded-full transition-colors duration-200 ${
            isActive
              ? 'bg-gradient-to-t from-cyan-600 via-sky-400 to-indigo-300 shadow-[0_0_8px_rgba(56,189,248,0.5)]'
              : 'bg-slate-700/60'
          }`}
          style={{
            height: `${Math.max(4, height * 36)}px`,
          }}
        />
      ))}
    </div>
  );
};
