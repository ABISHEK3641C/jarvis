import React, { useState } from 'react';
import { Camera, Eye, AlertCircle, FileSearch, Sparkles, Check, Upload } from 'lucide-react';

interface VisionInspectorProps {
  onAnalyzeScreen: (imageBase64: string, prompt: string) => Promise<string>;
}

export const VisionInspector: React.FC<VisionInspectorProps> = ({
  onAnalyzeScreen,
}) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<string | null>(null);
  const [selectedPreset, setSelectedPreset] = useState<string>('error');

  // Simulated screenshot samples reflecting real Windows screens
  const presets = [
    {
      id: 'error',
      title: 'Python Traceback & ModuleNotFoundError',
      desc: 'Typical developer syntax or missing dependency dialog',
      renderCanvas: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(0, 0, 600, 340);
        // Window bar
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(0, 0, 600, 32);
        ctx.fillStyle = '#ef4444'; ctx.beginPath(); ctx.arc(20, 16, 5, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#f59e0b'; ctx.beginPath(); ctx.arc(36, 16, 5, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#10b981'; ctx.beginPath(); ctx.arc(52, 16, 5, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#94a3b8';
        ctx.font = '12px monospace';
        ctx.fillText('cmd.exe - python app.py', 75, 20);

        // Terminal error text
        ctx.fillStyle = '#f87171';
        ctx.font = '13px monospace';
        ctx.fillText('Traceback (most recent call last):', 24, 70);
        ctx.fillStyle = '#cbd5e1';
        ctx.fillText('  File "app.py", line 14, in <module>', 24, 95);
        ctx.fillText('    import faster_whisper', 24, 120);
        ctx.fillStyle = '#ef4444';
        ctx.font = 'bold 13px monospace';
        ctx.fillText('ModuleNotFoundError: No module named \'faster_whisper\'', 24, 150);
        ctx.fillStyle = '#64748b';
        ctx.font = '12px monospace';
        ctx.fillText('C:\\Users\\Developer\\MYRAA> _', 24, 190);
      }
    },
    {
      id: 'settings',
      title: 'Windows 11 Privacy & Microphone Settings',
      desc: 'Microphone permission disabled banner',
      renderCanvas: (ctx: CanvasRenderingContext2D) => {
        ctx.fillStyle = '#18181b';
        ctx.fillRect(0, 0, 600, 340);
        // Header
        ctx.fillStyle = '#27272a';
        ctx.fillRect(0, 0, 600, 48);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 15px sans-serif';
        ctx.fillText('Settings > Privacy & security > Microphone', 24, 30);

        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(24, 70, 552, 45);
        ctx.fillStyle = '#000000';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('Microphone access for this device is turned off.', 40, 96);

        ctx.fillStyle = '#a1a1aa';
        ctx.font = '13px sans-serif';
        ctx.fillText('Let apps access your microphone: OFF', 24, 150);
        ctx.fillText('Choose which desktop apps can access your microphone.', 24, 180);
      }
    }
  ];

  const handleCaptureAndAnalyze = async () => {
    setAnalyzing(true);
    setAnalysisResult(null);

    // Create screenshot data URL from active preset canvas
    const canvas = document.createElement('canvas');
    canvas.width = 600;
    canvas.height = 340;
    const ctx = canvas.getContext('2d')!;
    const active = presets.find(p => p.id === selectedPreset) || presets[0];
    active.renderCanvas(ctx);

    const dataUrl = canvas.toDataURL('image/png');

    try {
      const result = await onAnalyzeScreen(
        dataUrl,
        'Analyze the text in this screenshot, explain the exact error or issue shown, and provide the exact commands or steps to resolve it.'
      );
      setAnalysisResult(result);
    } catch (e: any) {
      setAnalysisResult(`Screen analysis error: ${e.message}`);
    } finally {
      setAnalyzing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      const base64 = reader.result as string;
      setAnalyzing(true);
      try {
        const result = await onAnalyzeScreen(
          base64,
          'Analyze this screenshot, extract any visible OCR text and errors, and suggest helpful next actions.'
        );
        setAnalysisResult(result);
      } catch (err: any) {
        setAnalysisResult(`Analysis failed: ${err.message}`);
      } finally {
        setAnalyzing(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6 max-w-4xl mx-auto">
      {/* Header */}
      <div className="pb-4 border-b border-slate-800">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Eye className="w-6 h-6 text-cyan-400" />
          Screen Understanding & Vision OCR Engine
        </h2>
        <p className="text-xs text-slate-400 mt-1">
          Explicit user-authorized screen inspection powered by Gemini Vision to detect error dialogs, traceback logs, and UI navigation suggestions.
        </p>
      </div>

      {/* Screen Selection & Capture Controls */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
        <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
          <Camera className="w-4 h-4 text-cyan-400" />
          Select Screen or Upload Screenshot:
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {presets.map((preset) => (
            <button
              key={preset.id}
              onClick={() => setSelectedPreset(preset.id)}
              className={`p-3 rounded-xl border text-left transition-all ${
                selectedPreset === preset.id
                  ? 'bg-cyan-950/40 border-cyan-500 text-white shadow-md'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-300'
              }`}
            >
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-semibold">{preset.title}</span>
                {selectedPreset === preset.id && <Check className="w-3.5 h-3.5 text-cyan-400" />}
              </div>
              <p className="text-[11px] text-slate-500">{preset.desc}</p>
            </button>
          ))}
        </div>

        {/* Action Bar */}
        <div className="flex flex-wrap items-center gap-3 pt-2">
          <button
            onClick={handleCaptureAndAnalyze}
            disabled={analyzing}
            className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-semibold text-xs rounded-xl transition-all shadow-md flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4" />
            {analyzing ? 'Analyzing Screen with Gemini Vision...' : 'Capture & Analyze Screen'}
          </button>

          <label className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-xl cursor-pointer border border-slate-700 flex items-center gap-2 transition-colors">
            <Upload className="w-3.5 h-3.5" />
            <span>Upload Screenshot PNG/JPG</span>
            <input
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>
      </div>

      {/* Analysis Results Display */}
      {analysisResult && (
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-3 animate-in fade-in">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-cyan-400 flex items-center gap-2">
              <FileSearch className="w-4 h-4" />
              Vision Diagnostic Report
            </h4>
            <span className="text-[10px] font-mono text-slate-400">Gemini 3.8 Flash Vision</span>
          </div>
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-850 text-sm text-slate-200 leading-relaxed whitespace-pre-wrap font-sans">
            {analysisResult}
          </div>
        </div>
      )}
    </div>
  );
};
