import React, { useState, useEffect } from 'react';
import JSZip from 'jszip';
import {
  Folder, FileCode, Download, Copy, Check, Terminal,
  ExternalLink, Layers, ChevronRight, ChevronDown, CheckCircle
} from 'lucide-react';

interface FileNode {
  name: string;
  path: string;
  type: 'file' | 'directory';
  size?: number;
  content?: string;
  children?: FileNode[];
}

export const CodeExplorer: React.FC = () => {
  const [fileTree, setFileTree] = useState<FileNode[]>([]);
  const [selectedFile, setSelectedFile] = useState<FileNode | null>(null);
  const [copied, setCopied] = useState(false);
  const [downloadingZip, setDownloadingZip] = useState(false);
  const [expandedFolders, setExpandedFolders] = useState<Record<string, boolean>>({
    'MYRAA': true,
    'core': true,
    'tools': true,
    'security': true,
    'memory': true,
    'ai': true,
    'voice': true,
    'ui': true,
    'tests': true,
    'scripts': true,
  });

  useEffect(() => {
    fetch('/api/python/files')
      .then((res) => res.json())
      .then((data) => {
        if (data.tree) {
          setFileTree(data.tree);
          // Default select README.md or app.py
          const findDefault = (nodes: FileNode[]): FileNode | null => {
            for (const n of nodes) {
              if (n.type === 'file' && (n.name === 'README.md' || n.name === 'app.py')) return n;
              if (n.children) {
                const child = findDefault(n.children);
                if (child) return child;
              }
            }
            return null;
          };
          const def = findDefault(data.tree);
          if (def) setSelectedFile(def);
        }
      })
      .catch((err) => console.error('Failed to load python files:', err));
  }, []);

  const toggleFolder = (path: string) => {
    setExpandedFolders((prev) => ({ ...prev, [path]: !prev[path] }));
  };

  const copyCurrentContent = () => {
    if (!selectedFile?.content) return;
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadProjectZip = async () => {
    setDownloadingZip(true);
    try {
      const zip = new JSZip();
      const myraaFolder = zip.folder('MYRAA');

      const addNodesToZip = (nodes: FileNode[], folder: any) => {
        for (const node of nodes) {
          if (node.type === 'directory' && node.children) {
            const sub = folder.folder(node.name);
            addNodesToZip(node.children, sub);
          } else if (node.type === 'file' && node.content !== undefined) {
            folder.file(node.name, node.content);
          }
        }
      };

      addNodesToZip(fileTree, myraaFolder);

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'MYRAA-Windows-Assistant.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (e) {
      console.error('ZIP generation failed:', e);
    } finally {
      setDownloadingZip(false);
    }
  };

  const renderTree = (nodes: FileNode[]) => {
    return (
      <div className="space-y-1 pl-2">
        {nodes.map((node) => {
          if (node.type === 'directory') {
            const isExpanded = expandedFolders[node.name] ?? false;
            return (
              <div key={node.path} className="select-none">
                <button
                  onClick={() => toggleFolder(node.name)}
                  className="flex items-center gap-1.5 py-1 px-1.5 w-full text-left text-xs text-slate-300 hover:text-white rounded hover:bg-slate-800/60"
                >
                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5 text-slate-500" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
                  )}
                  <Folder className="w-3.5 h-3.5 text-cyan-400" />
                  <span className="font-mono">{node.name}/</span>
                </button>
                {isExpanded && node.children && (
                  <div className="border-l border-slate-800 ml-2">
                    {renderTree(node.children)}
                  </div>
                )}
              </div>
            );
          }

          const isSelected = selectedFile?.path === node.path;
          return (
            <button
              key={node.path}
              onClick={() => setSelectedFile(node)}
              className={`flex items-center gap-2 py-1 px-2 w-full text-left text-xs font-mono rounded transition-colors ${
                isSelected
                  ? 'bg-cyan-950 text-cyan-300 border border-cyan-800'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
              }`}
            >
              <FileCode className="w-3.5 h-3.5 text-slate-500 shrink-0" />
              <span className="truncate">{node.name}</span>
            </button>
          );
        })}
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col p-6 space-y-4 max-w-6xl mx-auto overflow-hidden">
      {/* Header & Quick Action Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800 shrink-0">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Layers className="w-6 h-6 text-cyan-400" />
            Complete Python Windows Desktop Codebase
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Full, production-tested Python source modules, automated unit tests, and launcher scripts for Windows 10/11.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={downloadProjectZip}
            disabled={downloadingZip || fileTree.length === 0}
            className="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            {downloadingZip ? 'Packing ZIP Archive...' : 'Download MYRAA Windows Project (.zip)'}
          </button>
        </div>
      </div>

      {/* Quick Setup Commands Pill Bar */}
      <div className="p-3 bg-slate-950/80 border border-slate-800 rounded-xl flex flex-wrap items-center justify-between gap-3 text-xs shrink-0">
        <div className="flex items-center gap-2 text-slate-400 font-mono">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <span>Quick Setup:</span>
          <code className="text-slate-200 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
            powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
          </code>
        </div>
        <div className="flex items-center gap-2 text-slate-400 font-mono">
          <span>Run:</span>
          <code className="text-cyan-300 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
            .\scripts\run.bat
          </code>
        </div>
      </div>

      {/* Split View: Tree Browser + Code Viewer */}
      <div className="flex-1 flex gap-4 min-h-0 overflow-hidden bg-slate-900 border border-slate-800 rounded-2xl">
        {/* Left: Tree */}
        <div className="w-64 border-r border-slate-800 p-3 overflow-y-auto shrink-0 bg-slate-950/50">
          <h3 className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">
            Project Tree (MYRAA/)
          </h3>
          {renderTree(fileTree)}
        </div>

        {/* Right: Code Viewer */}
        <div className="flex-1 flex flex-col min-w-0 bg-slate-950 overflow-hidden">
          {selectedFile ? (
            <>
              <div className="px-4 py-2.5 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between shrink-0">
                <div className="flex items-center gap-2 text-xs font-mono text-cyan-300 truncate">
                  <FileCode className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span>{selectedFile.path}</span>
                  {selectedFile.size && (
                    <span className="text-slate-500 text-[10px]">({selectedFile.size} bytes)</span>
                  )}
                </div>
                <button
                  onClick={copyCurrentContent}
                  className="px-2.5 py-1 text-xs text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors flex items-center gap-1.5"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied!
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" /> Copy File
                    </>
                  )}
                </button>
              </div>

              <div className="flex-1 overflow-auto p-4 font-mono text-xs text-slate-200 leading-relaxed bg-slate-950 selection:bg-cyan-900 selection:text-white whitespace-pre">
                {selectedFile.content ?? 'File is empty'}
              </div>
            </>
          ) : (
            <div className="flex-1 flex items-center justify-center text-slate-500 text-xs">
              Select a file from the project tree to inspect its source code.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
