import React, { useEffect, useRef } from 'react';
import { AudioState } from '../types/assistant';

interface AIOrbProps {
  state: AudioState;
  audioLevel?: number;
  onClick?: () => void;
  size?: number;
}

export const AIOrb: React.FC<AIOrbProps> = ({
  state,
  audioLevel = 0.2,
  onClick,
  size = 220,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const tickRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let destroyed = false;

    const render = () => {
      if (destroyed) return;
      tickRef.current += 0.035;
      const t = tickRef.current;

      const w = canvas.width;
      const h = canvas.height;
      ctx.clearRect(0, 0, w, h);

      const cx = w / 2;
      const cy = h / 2;
      const baseRadius = (size * 0.28);

      // Dynamic pulse and color palettes based on state
      let pulse = Math.sin(t * 2) * 4;
      let primaryColor = 'rgba(0, 210, 255, ';
      let secondaryColor = 'rgba(31, 111, 235, ';
      let glowColor = 'rgba(0, 200, 255, ';
      let particleColor = 'rgba(180, 240, 255, ';
      let orbitSpeed = 1.0;

      if (state === 'listening') {
        pulse = Math.sin(t * 4) * 8 + audioLevel * 18;
        primaryColor = 'rgba(0, 245, 212, ';
        secondaryColor = 'rgba(0, 187, 249, ';
        glowColor = 'rgba(0, 245, 212, ';
        particleColor = 'rgba(150, 255, 235, ';
        orbitSpeed = 2.2;
      } else if (state === 'thinking') {
        pulse = Math.sin(t * 6) * 5;
        primaryColor = 'rgba(199, 125, 255, ';
        secondaryColor = 'rgba(114, 9, 183, ';
        glowColor = 'rgba(157, 78, 221, ';
        particleColor = 'rgba(235, 190, 255, ';
        orbitSpeed = 3.5;
      } else if (state === 'speaking') {
        pulse = Math.sin(t * 5) * 6 + audioLevel * 24;
        primaryColor = 'rgba(255, 170, 0, ';
        secondaryColor = 'rgba(0, 180, 216, ';
        glowColor = 'rgba(255, 140, 0, ';
        particleColor = 'rgba(255, 220, 150, ';
        orbitSpeed = 2.0;
      }

      const radius = Math.max(30, baseRadius + pulse);

      // 1. Ambient Outer Halo
      const outerGlow = ctx.createRadialGradient(cx, cy, radius * 0.5, cx, cy, radius * 2.2);
      outerGlow.addColorStop(0, `${glowColor}0.4)`);
      outerGlow.addColorStop(0.5, `${glowColor}0.12)`);
      outerGlow.addColorStop(1, 'rgba(0,0,0,0)');
      ctx.fillStyle = outerGlow;
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 2.2, 0, Math.PI * 2);
      ctx.fill();

      // 2. Gyroscopic Rotating Orbital Rings
      const ringCount = 3;
      for (let i = 0; i < ringCount; i++) {
        ctx.save();
        ctx.translate(cx, cy);
        const angleOffset = (i * Math.PI) / 3;
        ctx.rotate(t * orbitSpeed * 0.5 + angleOffset);
        
        ctx.beginPath();
        const rx = radius * (1.25 + i * 0.15);
        const ry = radius * (0.65 + i * 0.1);
        ctx.ellipse(0, 0, rx, ry, (i * Math.PI) / 4, 0, Math.PI * 2);
        ctx.strokeStyle = `${primaryColor}${0.35 - i * 0.08})`;
        ctx.lineWidth = 1.6;
        ctx.setLineDash([8, 12]);
        ctx.lineDashOffset = -t * 15 * (i % 2 === 0 ? 1 : -1);
        ctx.stroke();

        // Orbiting satellite particle dot
        const particleAngle = t * (orbitSpeed + 0.5 * i);
        const px = Math.cos(particleAngle) * rx;
        const py = Math.sin(particleAngle) * ry;
        ctx.fillStyle = `${particleColor}0.9)`;
        ctx.beginPath();
        ctx.arc(px, py, 2.5, 0, Math.PI * 2);
        ctx.fill();

        ctx.restore();
      }

      // 3. Central 3D Spherical Core
      const sphereGrad = ctx.createRadialGradient(
        cx - radius * 0.35,
        cy - radius * 0.35,
        radius * 0.05,
        cx,
        cy,
        radius * 1.05
      );
      sphereGrad.addColorStop(0, '#FFFFFF');
      sphereGrad.addColorStop(0.2, `${primaryColor}0.95)`);
      sphereGrad.addColorStop(0.65, `${secondaryColor}0.85)`);
      sphereGrad.addColorStop(1, 'rgba(10, 15, 30, 0.95)');

      ctx.fillStyle = sphereGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, radius, 0, Math.PI * 2);
      ctx.fill();

      // 4. Inner energetic plasma flares
      ctx.save();
      ctx.beginPath();
      ctx.arc(cx, cy, radius * 0.85, 0, Math.PI * 2);
      ctx.clip();

      const flareCount = 6;
      for (let j = 0; j < flareCount; j++) {
        const fAngle = t * 1.5 + (j * Math.PI * 2) / flareCount;
        const fx = cx + Math.cos(fAngle) * (radius * 0.4);
        const fy = cy + Math.sin(fAngle) * (radius * 0.4);
        const flareGrad = ctx.createRadialGradient(fx, fy, 2, fx, fy, radius * 0.5);
        flareGrad.addColorStop(0, `${particleColor}0.5)`);
        flareGrad.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = flareGrad;
        ctx.beginPath();
        ctx.arc(fx, fy, radius * 0.5, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();

      // 5. Specular Gloss Reflection Arch
      ctx.save();
      ctx.beginPath();
      ctx.ellipse(cx - radius * 0.28, cy - radius * 0.38, radius * 0.4, radius * 0.2, -Math.PI / 6, 0, Math.PI * 2);
      const specGrad = ctx.createLinearGradient(
        cx - radius * 0.4,
        cy - radius * 0.5,
        cx - radius * 0.1,
        cy - radius * 0.2
      );
      specGrad.addColorStop(0, 'rgba(255, 255, 255, 0.7)');
      specGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = specGrad;
      ctx.fill();
      ctx.restore();

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      destroyed = true;
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
    };
  }, [state, audioLevel, size]);

  return (
    <div
      onClick={onClick}
      className="relative flex flex-col items-center justify-center cursor-pointer select-none group"
      title={`MYRAA State: ${state.toUpperCase()} (Click to toggle listening)`}
    >
      <canvas
        ref={canvasRef}
        width={size}
        height={size}
        className="transition-transform duration-300 group-hover:scale-105"
      />
      <div className="absolute bottom-2 text-center">
        <span
          className={`text-[11px] font-mono tracking-widest uppercase px-2.5 py-0.5 rounded-full border transition-all duration-300 ${
            state === 'listening'
              ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/40 shadow-sm shadow-emerald-500/20'
              : state === 'thinking'
              ? 'bg-purple-500/20 text-purple-300 border-purple-500/40 shadow-sm shadow-purple-500/20'
              : state === 'speaking'
              ? 'bg-amber-500/20 text-amber-300 border-amber-500/40 shadow-sm shadow-amber-500/20'
              : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/20'
          }`}
        >
          {state}
        </span>
      </div>
    </div>
  );
};
