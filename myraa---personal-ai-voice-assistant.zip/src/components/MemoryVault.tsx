import React, { useState } from 'react';
import { MemoryItem, ReminderItem, NoteItem, AuditEntry } from '../types/assistant';
import {
  Brain, Plus, Trash2, Search, Calendar, FileText,
  Shield, CheckCircle, Clock
} from 'lucide-react';

interface MemoryVaultProps {
  memories: MemoryItem[];
  onAddMemory: (category: string, content: string, tags: string) => void;
  onDeleteMemory: (id: number) => void;
  reminders: ReminderItem[];
  onToggleReminder: (id: number) => void;
  notes: NoteItem[];
  onAddNote: (title: string, body: string) => void;
  auditLogs: AuditEntry[];
  onClearHistory: () => void;
}

export const MemoryVault: React.FC<MemoryVaultProps> = ({
  memories,
  onAddMemory,
  onDeleteMemory,
  reminders,
  onToggleReminder,
  notes,
  onAddNote,
  auditLogs,
  onClearHistory,
}) => {
  const [activeTab, setActiveTab] = useState<'memories' | 'reminders' | 'notes' | 'audit'>('memories');
  const [searchQuery, setSearchQuery] = useState('');

  // Add memory modal form
  const [newCategory, setNewCategory] = useState('preference');
  const [newContent, setNewContent] = useState('');
  const [newTags, setNewTags] = useState('');

  // Add note modal form
  const [newNoteTitle, setNewNoteTitle] = useState('');
  const [newNoteBody, setNewNoteBody] = useState('');

  const filteredMemories = memories.filter(
    (m) =>
      m.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.tags.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.category.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateMemory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newContent.trim()) return;
    onAddMemory(newCategory, newContent.trim(), newTags.trim());
    setNewContent('');
    setNewTags('');
  };

  const handleCreateNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteTitle.trim() || !newNoteBody.trim()) return;
    onAddNote(newNoteTitle.trim(), newNoteBody.trim());
    setNewNoteTitle('');
    setNewNoteBody('');
  };

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Brain className="w-6 h-6 text-purple-400" />
            Personal Memory Vault & Audit Trail
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            SQLite-backed persistent preferences, reminders, notes, and security audit log.
          </p>
        </div>
        <button
          onClick={onClearHistory}
          className="px-3 py-1.5 text-xs text-rose-400 hover:text-rose-300 bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/30 rounded-lg transition-colors flex items-center gap-1.5"
        >
          <Trash2 className="w-3.5 h-3.5" />
          Clear Conversation History
        </button>
      </div>

      {/* Tabs Selector */}
      <div className="flex border-b border-slate-800 gap-4 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('memories')}
          className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'memories'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Brain className="w-4 h-4" />
          Long-Term Memories ({memories.length})
        </button>
        <button
          onClick={() => setActiveTab('reminders')}
          className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'reminders'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Calendar className="w-4 h-4" />
          Reminders ({reminders.length})
        </button>
        <button
          onClick={() => setActiveTab('notes')}
          className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'notes'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          Notes ({notes.length})
        </button>
        <button
          onClick={() => setActiveTab('audit')}
          className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
            activeTab === 'audit'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          Security Audit Log ({auditLogs.length})
        </button>
      </div>

      {/* Tab 1: Memories */}
      {activeTab === 'memories' && (
        <div className="space-y-4">
          {/* Add Memory Form */}
          <form
            onSubmit={handleCreateMemory}
            className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3"
          >
            <h3 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-purple-400" />
              Add User-Approved Long-Term Memory
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-300 outline-none"
              >
                <option value="preference">User Preference</option>
                <option value="work">Work & Projects</option>
                <option value="identity">User Info / Language</option>
                <option value="system_fact">System Fact</option>
              </select>
              <input
                type="text"
                placeholder="Content: e.g. 'Prefers dark theme and concise answers in Hinglish'"
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                className="sm:col-span-2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
              />
            </div>
            <div className="flex items-center justify-between pt-1">
              <input
                type="text"
                placeholder="Tags: ui, style, hindi"
                value={newTags}
                onChange={(e) => setNewTags(e.target.value)}
                className="w-1/2 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-slate-300 outline-none"
              />
              <button
                type="submit"
                className="px-4 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Save Memory
              </button>
            </div>
          </form>

          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-slate-500" />
            <input
              type="text"
              placeholder="Search user memories..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-9 pr-4 py-2.5 text-xs text-slate-200 outline-none"
            />
          </div>

          {/* Memory List */}
          <div className="space-y-2">
            {filteredMemories.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">
                No memories match your query.
              </p>
            ) : (
              filteredMemories.map((mem) => (
                <div
                  key={mem.id}
                  className="p-3 bg-slate-900 border border-slate-800/80 rounded-xl flex items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 bg-purple-950/80 text-purple-300 border border-purple-800 rounded">
                        {mem.category}
                      </span>
                      {mem.tags && (
                        <span className="text-[11px] text-slate-500">#{mem.tags}</span>
                      )}
                    </div>
                    <p className="text-xs text-slate-200">{mem.content}</p>
                  </div>
                  <button
                    onClick={() => onDeleteMemory(mem.id)}
                    className="p-1.5 text-slate-500 hover:text-rose-400 rounded-lg transition-colors"
                    title="Delete Memory"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Reminders */}
      {activeTab === 'reminders' && (
        <div className="space-y-3">
          <div className="space-y-2">
            {reminders.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">
                No active reminders. Tell MYRAA &quot;Remind me at 5 PM to call team&quot;.
              </p>
            ) : (
              reminders.map((rem) => (
                <div
                  key={rem.id}
                  onClick={() => onToggleReminder(rem.id)}
                  className={`p-3.5 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                    rem.is_completed
                      ? 'bg-slate-950/60 border-slate-800/60 text-slate-500 line-through'
                      : 'bg-slate-900 border-slate-800 text-slate-200'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <CheckCircle
                      className={`w-4 h-4 ${
                        rem.is_completed ? 'text-emerald-500' : 'text-slate-600'
                      }`}
                    />
                    <div>
                      <p className="text-xs font-medium">{rem.title}</p>
                      <p className="text-[11px] text-slate-400 flex items-center gap-1 mt-0.5">
                        <Clock className="w-3 h-3" />
                        Due: {rem.due_time} ({rem.recurrence})
                      </p>
                    </div>
                  </div>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-mono ${
                      rem.is_completed
                        ? 'bg-emerald-950 text-emerald-400'
                        : 'bg-amber-950 text-amber-300'
                    }`}
                  >
                    {rem.is_completed ? 'COMPLETED' : 'PENDING'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Notes */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          <form
            onSubmit={handleCreateNote}
            className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-3"
          >
            <h3 className="text-xs font-bold text-slate-200 flex items-center gap-1.5">
              <Plus className="w-4 h-4 text-cyan-400" /> Create Note
            </h3>
            <input
              type="text"
              placeholder="Note Title"
              value={newNoteTitle}
              onChange={(e) => setNewNoteTitle(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
            />
            <textarea
              placeholder="Note body text..."
              rows={3}
              value={newNoteBody}
              onChange={(e) => setNewNoteBody(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-200 outline-none"
            />
            <div className="flex justify-end">
              <button
                type="submit"
                className="px-4 py-1.5 bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg text-xs font-semibold transition-colors"
              >
                Save Note
              </button>
            </div>
          </form>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {notes.map((note) => (
              <div
                key={note.id}
                className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2"
              >
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-cyan-300">{note.title}</h4>
                  <span className="text-[10px] text-slate-500">{note.created_at}</span>
                </div>
                <p className="text-xs text-slate-300 whitespace-pre-wrap">{note.body}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Security Audit Log */}
      {activeTab === 'audit' && (
        <div className="space-y-3">
          <div className="overflow-x-auto rounded-xl border border-slate-800">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-950 text-slate-400 border-b border-slate-800">
                <tr>
                  <th className="p-3">TIMESTAMP</th>
                  <th className="p-3">TOOL</th>
                  <th className="p-3">RISK</th>
                  <th className="p-3">DECISION</th>
                  <th className="p-3">DETAILS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 bg-slate-900/50">
                {auditLogs.map((log, i) => (
                  <tr key={i} className="hover:bg-slate-800/40">
                    <td className="p-3 text-slate-500">{log.timestamp.slice(11, 19)}</td>
                    <td className="p-3 text-cyan-300">{log.tool_name}</td>
                    <td className="p-3">
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-bold uppercase ${
                          log.risk_level === 'HIGH'
                            ? 'bg-amber-950 text-amber-300'
                            : log.risk_level === 'BLOCKED'
                            ? 'bg-rose-950 text-rose-300'
                            : 'bg-emerald-950 text-emerald-400'
                        }`}
                      >
                        {log.risk_level}
                      </span>
                    </td>
                    <td className="p-3 text-slate-300">{log.decision}</td>
                    <td className="p-3 text-slate-400 truncate max-w-xs">{log.parameters}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
