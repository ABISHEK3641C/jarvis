import React, { useState } from 'react';
import { AssistantConfig } from '../types/assistant';
import { Settings, X, Volume2, Cpu, Shield, Sliders } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  config: AssistantConfig;
  onSaveConfig: (updated: AssistantConfig) => void;
  availableVoices: SpeechSynthesisVoice[];
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  config,
  onSaveConfig,
  availableVoices,
}) => {
  const [formData, setFormData] = useState<AssistantConfig>({ ...config });
  const [activeTab, setActiveTab] = useState<'voice' | 'ai' | 'security'>('voice');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSaveConfig(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-slate-900 border border-slate-700 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Settings className="w-5 h-5 text-cyan-400" />
            <h3 className="text-base font-bold text-white">MYRAA Assistant Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Header */}
        <div className="flex border-b border-slate-800 px-6 pt-3 gap-6 text-xs font-semibold">
          <button
            onClick={() => setActiveTab('voice')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'voice'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Volume2 className="w-4 h-4" /> Voice & Language
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'ai'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Cpu className="w-4 h-4" /> AI Models & Offline
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`pb-2.5 border-b-2 transition-colors flex items-center gap-1.5 ${
              activeTab === 'security'
                ? 'border-cyan-500 text-cyan-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Shield className="w-4 h-4" /> Security & Privacy
          </button>
        </div>

        {/* Content Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4 flex-1">
          {activeTab === 'voice' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Primary Language:
                </label>
                <select
                  value={formData.language}
                  onChange={(e) => setFormData({ ...formData, language: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none"
                >
                  <option value="en">English (US/UK)</option>
                  <option value="hi">हिंदी (Hindi)</option>
                  <option value="hinglish">Hinglish (Hindi-English Blend)</option>
                  <option value="auto">Automatic Detection</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Text-to-Speech Voice:
                </label>
                <select
                  value={formData.voiceName}
                  onChange={(e) => setFormData({ ...formData, voiceName: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none"
                >
                  <option value="">Default System Natural Voice</option>
                  {availableVoices.map((v, i) => (
                    <option key={i} value={v.name}>
                      {v.name} ({v.lang})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex justify-between text-xs text-slate-300 mb-1">
                  <span>Speech Rate (Speed):</span>
                  <span className="font-mono text-cyan-400">{formData.speechRate}x</span>
                </div>
                <input
                  type="range"
                  min="0.7"
                  max="1.5"
                  step="0.05"
                  value={formData.speechRate}
                  onChange={(e) => setFormData({ ...formData, speechRate: parseFloat(e.target.value) })}
                  className="w-full accent-cyan-500 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Wake-Word Phrase:
                </label>
                <input
                  type="text"
                  value={formData.wakeWord}
                  onChange={(e) => setFormData({ ...formData, wakeWord: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none"
                />
              </div>

              {/* Hands-Free Voice Controls */}
              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2.5">
                <label className="flex items-center gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.handsFreeMode}
                    onChange={(e) => setFormData({ ...formData, handsFreeMode: e.target.checked })}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-emerald-500 focus:ring-emerald-500"
                  />
                  <div>
                    <span className="text-xs font-semibold text-white block">
                      Continuous Hands-Free Conversation Mode
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Auto-listens after replying so you never have to click the mic button repeatedly.
                    </span>
                  </div>
                </label>

                <div>
                  <div className="flex justify-between text-xs text-slate-400 mb-1">
                    <span>Silence Detection Auto-Send Delay:</span>
                    <span className="font-mono text-cyan-400">{(formData.silenceThresholdMs / 1000).toFixed(1)}s</span>
                  </div>
                  <input
                    type="range"
                    min="800"
                    max="2500"
                    step="100"
                    value={formData.silenceThresholdMs}
                    onChange={(e) => setFormData({ ...formData, silenceThresholdMs: parseInt(e.target.value) })}
                    className="w-full accent-cyan-500 cursor-pointer"
                  />
                  <span className="text-[10px] text-slate-500">
                    Auto-sends your speech after this duration of silence.
                  </span>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'ai' && (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  AI Provider Architecture:
                </label>
                <select
                  value={formData.aiProvider}
                  onChange={(e) => setFormData({ ...formData, aiProvider: e.target.value as any })}
                  className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-200 outline-none"
                >
                  <option value="cloud">Cloud AI (Gemini 3.8 Flash via Server)</option>
                  <option value="auto">Auto (Cloud with Offline Fallback)</option>
                  <option value="local">Local Inference (Ollama / vLLM)</option>
                </select>
              </div>

              <div className="p-3 bg-slate-950 rounded-xl border border-slate-800">
                <label className="flex items-center gap-2 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.offlineMode}
                    onChange={(e) => setFormData({ ...formData, offlineMode: e.target.checked })}
                    className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-cyan-500"
                  />
                  <div>
                    <span className="text-xs font-semibold text-white block">
                      Force Offline Mode
                    </span>
                    <span className="text-[11px] text-slate-400 block">
                      Restricts all requests to the local deterministic rule engine without internet.
                    </span>
                  </div>
                </label>
              </div>
            </div>
          )}

          {activeTab === 'security' && (
            <div className="space-y-3">
              <label className="flex items-start gap-2.5 p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.requireHighRiskConfirmation}
                  onChange={(e) => setFormData({ ...formData, requireHighRiskConfirmation: e.target.checked })}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-cyan-500 mt-0.5"
                />
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Require Confirmation for HIGH-RISK Actions
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Always prompt before deleting files, shutdown, restart, sending messages.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.requireMediumRiskConfirmation}
                  onChange={(e) => setFormData({ ...formData, requireMediumRiskConfirmation: e.target.checked })}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-cyan-500 mt-0.5"
                />
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Require Confirmation for MEDIUM-RISK Actions
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Always prompt before reading local files, taking screenshots, or volume adjustments.
                  </span>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-3 bg-slate-950 rounded-xl border border-slate-800 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.allowScreenCapture}
                  onChange={(e) => setFormData({ ...formData, allowScreenCapture: e.target.checked })}
                  className="w-4 h-4 rounded border-slate-700 bg-slate-800 text-cyan-500 mt-0.5"
                />
                <div>
                  <span className="text-xs font-semibold text-white block">
                    Allow Screen Capture for Vision OCR
                  </span>
                  <span className="text-[11px] text-slate-400">
                    Permits MYRAA to analyze visible screen contents when explicitly asked.
                  </span>
                </div>
              </label>
            </div>
          )}

          {/* Footer Save Button */}
          <div className="pt-4 flex justify-end gap-2 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-xl transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 text-xs font-bold text-white bg-cyan-600 hover:bg-cyan-500 rounded-xl transition-all shadow-md"
            >
              Save Preferences
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
