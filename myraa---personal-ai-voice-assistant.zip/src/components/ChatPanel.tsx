import React, { useRef, useEffect } from 'react';
import { ChatMessage, RiskLevel } from '../types/assistant';
import { Volume2, VolumeX, Shield, CheckCircle2, AlertCircle, Copy, Check } from 'lucide-react';

interface ChatPanelProps {
  messages: ChatMessage[];
  onSpeakText: (text: string) => void;
  isSpeaking: boolean;
  isThinking?: boolean;
  onQuickPrompt: (prompt: string) => void;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  onSpeakText,
  isSpeaking,
  isThinking = false,
  onQuickPrompt,
}) => {
  const scrollEndRef = useRef<HTMLDivElement | null>(null);
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  useEffect(() => {
    scrollEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const quickPrompts = [
    { label: 'Check System Stats', text: 'Check current system CPU, RAM, and disk metrics.' },
    { label: 'Open Calculator', text: 'Calculator kholo please.' },
    { label: 'Schedule Reminder', text: 'Remind me to submit project review today at 6 PM.' },
    { label: 'मेरी Reminders दिखाओ', text: 'मेरी आज की सारी reminders दिखाओ।' },
    { label: 'Screen OCR Error Check', text: 'Analyze the current screen and identify any errors.' },
    { label: 'Mute Audio', text: 'Mute system volume.' },
  ];

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-slate-900/60 rounded-2xl border border-slate-800">
      {/* Quick Prompts Bar */}
      <div className="px-4 py-2 border-b border-slate-800/80 bg-slate-950/40 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider shrink-0">
          Try saying:
        </span>
        {quickPrompts.map((qp, i) => (
          <button
            key={i}
            onClick={() => onQuickPrompt(qp.text)}
            className="text-xs px-2.5 py-1 rounded-lg bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors shrink-0 border border-slate-700/60"
          >
            {qp.label}
          </button>
        ))}
      </div>

      {/* Messages Scroll Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex flex-col ${isUser ? 'items-end' : 'items-start'} group`}
            >
              <div className="flex items-center gap-2 mb-1 px-1">
                <span className={`text-xs font-semibold ${isUser ? 'text-emerald-400' : 'text-cyan-400'}`}>
                  {isUser ? 'You' : 'MYRAA'}
                </span>
                <span className="text-[10px] text-slate-500">{msg.timestamp}</span>

                {msg.riskLevel && (
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.2 rounded font-bold uppercase ${
                      msg.riskLevel === 'HIGH'
                        ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                        : msg.riskLevel === 'MEDIUM'
                        ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30'
                        : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                    }`}
                  >
                    {msg.riskLevel}
                  </span>
                )}
              </div>

              <div
                className={`max-w-[85%] rounded-2xl p-4 text-sm leading-relaxed relative ${
                  isUser
                    ? 'bg-emerald-950/40 text-emerald-100 border border-emerald-800/50 rounded-tr-none'
                    : 'bg-slate-800/80 text-slate-100 border border-slate-700/60 rounded-tl-none shadow-lg'
                }`}
              >
                <div className="whitespace-pre-wrap">{msg.content}</div>

                {/* Tool Executions card inside bubble */}
                {msg.toolResults && msg.toolResults.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-slate-700/50 space-y-2">
                    {msg.toolResults.map((tr, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-900/80 border border-slate-800 text-xs font-mono"
                      >
                        <div className="flex items-center justify-between text-slate-400 mb-1">
                          <span className="flex items-center gap-1.5 text-cyan-400 font-semibold">
                            <Shield className="w-3.5 h-3.5" />
                            {tr.toolName}
                          </span>
                          <span
                            className={`flex items-center gap-1 ${
                              tr.success ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {tr.success ? (
                              <>
                                <CheckCircle2 className="w-3.5 h-3.5" /> Success
                              </>
                            ) : (
                              <>
                                <AlertCircle className="w-3.5 h-3.5" /> Failed
                              </>
                            )}
                          </span>
                        </div>
                        {tr.data && (
                          <pre className="text-[11px] text-slate-300 overflow-x-auto whitespace-pre-wrap">
                            {JSON.stringify(tr.data, null, 2)}
                          </pre>
                        )}
                        {tr.error && <p className="text-rose-300">{tr.error}</p>}
                      </div>
                    ))}
                  </div>
                )}

                {/* Bubble action toolbar */}
                {!isUser && (
                  <div className="mt-2.5 flex items-center justify-end gap-2 text-slate-400 text-xs">
                    <button
                      onClick={() => onSpeakText(msg.content)}
                      className="p-1 hover:text-cyan-300 transition-colors rounded hover:bg-slate-700/50"
                      title="Read aloud"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => copyToClipboard(msg.id, msg.content)}
                      className="p-1 hover:text-cyan-300 transition-colors rounded hover:bg-slate-700/50"
                      title="Copy message"
                    >
                      {copiedId === msg.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
        {/* Animated Thinking & Processing Bubble */}
        {isThinking && (
          <div className="flex flex-col items-start group animate-in fade-in duration-200">
            <div className="flex items-center gap-2 mb-1 px-1">
              <span className="text-xs font-semibold text-cyan-400">MYRAA</span>
              <span className="text-[10px] text-slate-500">Processing...</span>
            </div>
            <div className="bg-slate-800/90 text-slate-200 border border-cyan-500/30 rounded-2xl rounded-tl-none p-3.5 shadow-lg flex items-center gap-3">
              <div className="flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
              <span className="text-xs text-cyan-300 font-medium">Listening & formulating response...</span>
            </div>
          </div>
        )}

        <div ref={scrollEndRef} />
      </div>
    </div>
  );
};
