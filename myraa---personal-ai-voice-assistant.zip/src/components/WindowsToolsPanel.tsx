import React, { useState } from 'react';
import {
  Cpu, HardDrive, Battery, Volume2, Search, FileText,
  ExternalLink, Play, CheckCircle2, ShieldCheck, Monitor
} from 'lucide-react';
import { SystemMetrics } from '../types/assistant';

interface WindowsToolsPanelProps {
  metrics: SystemMetrics | null;
  onExecuteTool: (toolName: string, params: Record<string, any>) => void;
  onVolumeChange: (level: number) => void;
  volume: number;
}

export const WindowsToolsPanel: React.FC<WindowsToolsPanelProps> = ({
  metrics,
  onExecuteTool,
  onVolumeChange,
  volume,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedApp, setSelectedApp] = useState('calculator');

  const approvedApps = [
    { id: 'calculator', name: 'Calculator (calc.exe)', desc: 'Windows Built-in Calculator' },
    { id: 'notepad', name: 'Notepad (notepad.exe)', desc: 'Plain Text Editor' },
    { id: 'file explorer', name: 'File Explorer (explorer.exe)', desc: 'Windows File Browser' },
    { id: 'task manager', name: 'Task Manager (taskmgr.exe)', desc: 'System Process Monitor' },
    { id: 'paint', name: 'Paint (mspaint.exe)', desc: 'Drawing & Graphics Tool' },
    { id: 'chrome', name: 'Google Chrome (chrome.exe)', desc: 'Approved Web Browser' },
    { id: 'code', name: 'VS Code (code.exe)', desc: 'Developer IDE' },
  ];

  const approvedWebsites = [
    { name: 'Google Search', url: 'https://google.com' },
    { name: 'GitHub Developer', url: 'https://github.com' },
    { name: 'Wikipedia', url: 'https://wikipedia.org' },
    { name: 'Weather Portal', url: 'https://weather.com' },
  ];

  const sampleFiles = [
    { name: 'quarterly_financial_report.pdf', path: 'C:\\Users\\User\\Documents\\quarterly_financial_report.pdf', size: '2.4 MB' },
    { name: 'project_architecture_notes.md', path: 'C:\\Users\\User\\Documents\\project_architecture_notes.md', size: '14 KB' },
    { name: 'client_meeting_summary.txt', path: 'C:\\Users\\User\\Notes\\client_meeting_summary.txt', size: '6 KB' },
    { name: 'backup_script_automation.py', path: 'C:\\Users\\User\\Desktop\\backup_script_automation.py', size: '3.1 KB' },
  ];

  return (
    <div className="h-full overflow-y-auto p-6 space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-cyan-400" />
            Approved Windows Automation Control Center
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Least-privilege modular execution with independent risk validation and human confirmation gates.
          </p>
        </div>
        <span className="text-xs font-mono px-3 py-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 rounded-full">
          Sandboxed & Allowlisted
        </span>
      </div>

      {/* Live System Diagnostics Gauges */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* CPU */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold text-cyan-300">
              <Cpu className="w-4 h-4" /> CPU Utilization
            </span>
            <span className="font-mono text-white">{metrics?.cpu_percent ?? 18}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-cyan-500 h-full transition-all duration-500 rounded-full"
              style={{ width: `${metrics?.cpu_percent ?? 18}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-400 truncate">
            {metrics?.cpu_model ?? 'Intel Core i9 16-Core'}
          </p>
        </div>

        {/* RAM */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold text-purple-300">
              <Cpu className="w-4 h-4" /> RAM In Use
            </span>
            <span className="font-mono text-white">{metrics?.ram_percent ?? 42}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="bg-purple-500 h-full transition-all duration-500 rounded-full"
              style={{ width: `${metrics?.ram_percent ?? 42}%` }}
            />
          </div>
          <p className="text-[11px] text-slate-400">
            {metrics?.ram_used_gb ?? '6.8'} GB / {metrics?.ram_total_gb ?? '16.0'} GB
          </p>
        </div>

        {/* Disk */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold text-emerald-300">
              <HardDrive className="w-4 h-4" /> System Drive (C:)
            </span>
            <span className="font-mono text-white">43%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div className="bg-emerald-500 h-full rounded-full" style={{ width: '43%' }} />
          </div>
          <p className="text-[11px] text-slate-400">
            {metrics?.disk_free_gb ?? 540} GB Free of 953 GB
          </p>
        </div>

        {/* Battery & Power */}
        <div className="p-4 bg-slate-900 border border-slate-800 rounded-xl space-y-2">
          <div className="flex items-center justify-between text-slate-400 text-xs">
            <span className="flex items-center gap-1.5 font-semibold text-amber-300">
              <Battery className="w-4 h-4" /> Battery Status
            </span>
            <span className="font-mono text-white">{metrics?.battery_percent ?? 88}%</span>
          </div>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div className="bg-amber-500 h-full rounded-full" style={{ width: '88%' }} />
          </div>
          <p className="text-[11px] text-slate-400">
            {metrics?.is_charging ? 'Connected to AC Power' : 'Running on Battery'}
          </p>
        </div>
      </div>

      {/* Grid: App Launcher & System Audio Settings */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Approved App Launcher */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Play className="w-4 h-4 text-cyan-400" />
              Approved Application Launcher
            </h3>
            <span className="text-[10px] text-slate-400">LOW RISK</span>
          </div>

          <div className="space-y-2">
            {approvedApps.map((app) => (
              <div
                key={app.id}
                className="flex items-center justify-between p-2.5 bg-slate-950/60 border border-slate-800/80 rounded-xl hover:border-slate-700 transition-colors"
              >
                <div>
                  <h4 className="text-xs font-semibold text-slate-200">{app.name}</h4>
                  <p className="text-[11px] text-slate-400">{app.desc}</p>
                </div>
                <button
                  onClick={() => onExecuteTool('launch_approved_app', { app_name: app.id })}
                  className="px-3 py-1.5 text-xs font-semibold text-cyan-300 bg-cyan-950/80 hover:bg-cyan-900/90 border border-cyan-800 rounded-lg transition-colors flex items-center gap-1"
                >
                  <Play className="w-3 h-3 fill-cyan-400" /> Launch
                </button>
              </div>
            ))}
          </div>
        </div>

        {/* Audio Volume & Reversible Settings */}
        <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Volume2 className="w-4 h-4 text-amber-400" />
              System Audio Settings
            </h3>
            <span className="text-[10px] text-slate-400">MEDIUM RISK</span>
          </div>

          <div className="p-4 bg-slate-950/60 border border-slate-800/80 rounded-xl space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>Master Volume Level:</span>
              <span className="font-mono font-bold text-amber-400">{volume}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={volume}
              onChange={(e) => onVolumeChange(parseInt(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer"
            />
            <div className="flex gap-2 pt-2">
              <button
                onClick={() => onExecuteTool('adjust_volume', { mute: true })}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-slate-300 transition-colors"
              >
                Mute Audio
              </button>
              <button
                onClick={() => onVolumeChange(50)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-slate-300 transition-colors"
              >
                Set to 50%
              </button>
              <button
                onClick={() => onVolumeChange(100)}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs rounded-lg text-slate-300 transition-colors"
              >
                Set to 100%
              </button>
            </div>
          </div>

          {/* Approved Browser Sites */}
          <div className="space-y-2 pt-2">
            <h4 className="text-xs font-semibold text-slate-300">Approved Web Shortcuts:</h4>
            <div className="grid grid-cols-2 gap-2">
              {approvedWebsites.map((site, i) => (
                <button
                  key={i}
                  onClick={() => onExecuteTool('open_approved_url', { url: site.url })}
                  className="p-2 bg-slate-950/60 border border-slate-800 hover:border-slate-700 rounded-lg text-left text-xs text-slate-300 flex items-center justify-between"
                >
                  <span>{site.name}</span>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Approved Documents & File Search */}
      <div className="p-5 bg-slate-900 border border-slate-800 rounded-2xl space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">
              Approved Directory File Access (Documents, Downloads, Notes)
            </h3>
          </div>
          <span className="text-[10px] text-slate-400">MEDIUM RISK (Requires Confirmation to Read)</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {sampleFiles.map((file, i) => (
            <div
              key={i}
              className="p-3 bg-slate-950/60 border border-slate-800 rounded-xl flex items-center justify-between gap-3"
            >
              <div className="overflow-hidden">
                <p className="text-xs font-semibold text-slate-200 truncate">{file.name}</p>
                <p className="text-[11px] text-slate-400 truncate">{file.path}</p>
              </div>
              <button
                onClick={() => onExecuteTool('read_document', { file_path: file.path })}
                className="px-3 py-1.5 text-xs font-medium bg-slate-800 hover:bg-slate-700 text-cyan-300 rounded-lg shrink-0 transition-colors"
              >
                Read
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
