import React, { useState, useEffect, useRef } from 'react';
import {
  Mic, MicOff, Square, Send, Globe, Radio, Sparkles,
  Zap, Volume2, ArrowRight
} from 'lucide-react';
import { AudioState } from '../types/assistant';

interface VoiceControlsProps {
  audioState: AudioState;
  onToggleListening: () => void;
  onStopSpeaking: () => void;
  onSendMessage: (text: string) => void;
  language: string;
  onLanguageChange: (lang: any) => void;
  wakeWordEnabled: boolean;
  onToggleWakeWord: () => void;
  handsFreeMode: boolean;
  onToggleHandsFree: () => void;
  interimTranscript: string;
}

export const VoiceControls: React.FC<VoiceControlsProps> = ({
  audioState,
  onToggleListening,
  onStopSpeaking,
  onSendMessage,
  language,
  onLanguageChange,
  wakeWordEnabled,
  onToggleWakeWord,
  handsFreeMode,
  onToggleHandsFree,
  interimTranscript,
}) => {
  const [inputText, setInputText] = useState('');
  const isListening = audioState === 'listening';
  const isSpeaking = audioState === 'speaking';
  const isThinking = audioState === 'thinking';
  const inputRef = useRef<HTMLInputElement | null>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  return (
    <div className="w-full bg-slate-900/95 border border-slate-800 rounded-2xl p-3 shadow-2xl space-y-2.5">
      {/* Live Interim Speech Preview Banner (Visible while hearing words in real-time) */}
      {interimTranscript && isListening && (
        <div className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-950/80 via-emerald-950/60 to-slate-900 border border-cyan-500/40 flex items-center justify-between gap-3 animate-in fade-in duration-150">
          <div className="flex items-center gap-2.5 min-w-0">
            <span className="relative flex h-2.5 w-2.5 shrink-0">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-cyan-400 opacity-75" />
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-cyan-500" />
            </span>
            <div className="min-w-0">
              <span className="text-[10px] font-mono tracking-wider uppercase text-cyan-400 block font-semibold">
                Hearing You Live:
              </span>
              <p className="text-xs text-white font-medium truncate italic">
                &ldquo;{interimTranscript}&rdquo;
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => onSendMessage(interimTranscript)}
            className="px-2.5 py-1 text-[11px] font-semibold bg-cyan-600 hover:bg-cyan-500 text-white rounded-lg shrink-0 flex items-center gap-1 transition-colors"
          >
            <span>Send Now</span>
            <ArrowRight className="w-3 h-3" />
          </button>
        </div>
      )}

      {/* Top Toolbar: Hands-Free Switch, Wake Word & Language Selector */}
      <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-xs">
        <div className="flex items-center gap-2">
          {/* Hands-Free Auto-Listen Button */}
          <button
            type="button"
            onClick={onToggleHandsFree}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border font-medium transition-all ${
              handsFreeMode
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 shadow-sm shadow-emerald-900/30'
                : 'bg-slate-800 text-slate-400 border-slate-700/80 hover:text-slate-200'
            }`}
            title="Hands-Free Mode: Speak continuously without clicking the mic button repeatedly!"
          >
            <Zap className={`w-3.5 h-3.5 ${handsFreeMode ? 'text-emerald-400 fill-emerald-400' : ''}`} />
            <span>
              Hands-Free Auto-Listen: {handsFreeMode ? 'ON' : 'OFF'}
            </span>
          </button>

          {/* Wake Word detector */}
          <button
            type="button"
            onClick={onToggleWakeWord}
            className={`hidden sm:flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border transition-all ${
              wakeWordEnabled
                ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                : 'bg-slate-800 text-slate-400 border-slate-700/80'
            }`}
            title="Wake word detection ('Hey MYRAA')"
          >
            <Radio className={`w-3.5 h-3.5 ${wakeWordEnabled ? 'animate-pulse text-cyan-400' : ''}`} />
            <span>&ldquo;Hey MYRAA&rdquo;</span>
          </button>
        </div>

        {/* Language selector & quick hints */}
        <div className="flex items-center gap-2">
          <Globe className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={language}
            onChange={(e) => onLanguageChange(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-slate-200 text-xs rounded-xl px-2.5 py-1.5 focus:ring-1 focus:ring-cyan-500 outline-none cursor-pointer"
          >
            <option value="hinglish">Hinglish (हिंदी + English)</option>
            <option value="hi">हिंदी (Hindi)</option>
            <option value="en">English (US/UK)</option>
            <option value="auto">Auto Detect</option>
          </select>
        </div>
      </div>

      {/* Main input & mic controls bar */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2 pt-0.5">
        {/* Animated Mic Button */}
        <button
          type="button"
          onClick={onToggleListening}
          className={`relative p-3 rounded-xl transition-all duration-300 flex items-center justify-center shrink-0 ${
            isListening
              ? 'bg-rose-600 text-white shadow-lg shadow-rose-600/40 ring-4 ring-rose-500/20'
              : handsFreeMode
              ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-md shadow-emerald-600/20'
              : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-md shadow-cyan-600/20'
          }`}
          title={
            isListening
              ? 'Microphone Active: Click to pause/mute'
              : 'Click to start voice recognition'
          }
        >
          {isListening ? (
            <Mic className="w-5 h-5 animate-pulse" />
          ) : handsFreeMode ? (
            <Mic className="w-5 h-5" />
          ) : (
            <MicOff className="w-5 h-5 opacity-80" />
          )}
        </button>

        {/* Text Input */}
        <div className="relative flex-1">
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              isListening
                ? handsFreeMode
                  ? 'Hands-Free Active: Speak naturally anytime in Hindi or English...'
                  : 'Listening... (Speak now in Hindi, Hinglish, or English)'
                : isThinking
                ? 'MYRAA is thinking...'
                : isSpeaking
                ? 'MYRAA is speaking (Press Escape or Interrupt to stop)...'
                : 'Ask MYRAA or type a Windows command (English, हिंदी, Hinglish)...'
            }
            className="w-full bg-slate-950 border border-slate-800 rounded-xl px-4 py-3 text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-cyan-500/80 transition-colors"
          />
        </div>

        {/* Stop Voice Interrupt Button (Visible during speech playback) */}
        {isSpeaking && (
          <button
            type="button"
            onClick={onStopSpeaking}
            className="p-3 bg-amber-600 hover:bg-amber-500 text-white rounded-xl transition-colors shadow-md flex items-center gap-1.5 shrink-0 text-xs font-semibold"
            title="Interrupt MYRAA speech playback (Escape / Space)"
          >
            <Square className="w-4 h-4 fill-white" />
            <span className="hidden sm:inline">Interrupt</span>
          </button>
        )}

        {/* Send Button */}
        <button
          type="submit"
          disabled={!inputText.trim()}
          className="p-3 bg-slate-800 hover:bg-cyan-600 disabled:opacity-40 disabled:hover:bg-slate-800 text-white rounded-xl transition-colors shrink-0"
          title="Send message (Enter)"
        >
          <Send className="w-5 h-5" />
        </button>
      </form>

      {/* Bottom Hint */}
      <div className="flex items-center justify-between px-2 text-[10px] text-slate-500">
        <span>
          {handsFreeMode
            ? '⚡ Hands-Free Loop: Speaks back and automatically listens for follow-ups.'
            : '💡 Push-to-Talk Mode: Click the mic or press Space to speak.'}
        </span>
        <span className="hidden md:inline">Shortcuts: [Space] Mic · [Esc] Stop</span>
      </div>
    </div>
  );
};
