# MYRAA — Personal AI Voice Assistant for Windows 10/11

**MYRAA** is a production-oriented, secure, multilingual personal AI desktop assistant built with **Python 3.10+**, **PySide6**, **faster-whisper**, and a **Hybrid Cloud/Local AI Engine**. It provides hands-free voice automation, screen understanding with OCR, persistent SQLite memory, and an independent security authorization gateway for Windows.

---

## 🌟 Key Features

1. **Multilingual Voice System**
   - Natural speech interaction in **English**, **Hindi (हिंदी)**, and **Hinglish**.
   - Offline Speech-to-Text via `faster-whisper` with automatic language detection.
   - Text-to-Speech via `pyttsx3` (Windows SAPI5) and Google GenAI with selectable voices, rate, and volume.
   - Continuous wake-word detection for *"Hey MYRAA"*.
   - Instant voice interruption (`Escape` key, Spacebar, or UI stop button).

2. **Modern Fluent Desktop Interface (PySide6)**
   - **3D Animated AI Orb**: Real-time rendering with 4 distinct states:
     - 🔵 **IDLE**: Gentle pulsing cyan/indigo sphere.
     - 🟢 **LISTENING**: Audio-reactive expanding neon rings.
     - 🟣 **THINKING**: Dynamic particle vortex during AI reasoning.
     - 🟠 **SPEAKING**: Rhythmic acoustic wave oscillations.
   - **Real-Time Audio Waveform**: Equalizer bar visualizer synced to microphone and speech.
   - **Navigation Sidebar**: Switch between Chat, Windows Tools, Reminders, Memory Vault, and Settings.
   - **Dark & Light Themes**: Accessible high-contrast Fluent styling.

3. **Hybrid AI Engine & Offline Fallback**
   - **Cloud**: Google Gemini 3.8 Flash via `@google/genai` or server proxy.
   - **Local**: Ollama / vLLM / LM Studio via OpenAI-compatible endpoints (`http://localhost:11434/v1`).
   - **Deterministic Offline Rule Engine**: Operates with zero network connectivity for app launching, volume control, system info, date/time, and notes.

4. **Independent Security & Confirmation Subsystem**
   - **Risk Classification Tiers**:
     - 🟢 **LOW RISK**: Simple queries, read-only system metrics, allowlisted app launch.
     - 🟡 **MEDIUM RISK**: Reading local documents, taking authorized screenshots, volume changes.
     - 🔴 **HIGH RISK**: Deleting files, system shutdown/restart, software installation.
     - 🚫 **BLOCKED**: Credential theft, shellcode injection, bulk deletions, disabling Defender.
   - **Human-in-the-Loop Confirmation**: Displays exact action, target path, and risk level before execution.
   - **Tamper-Evident Audit Log**: Logs every operation into `~/.myraa/audit/audit.jsonl`.

5. **Personal Memory & Productivity (SQLite)**
   - Long-term memory store for user-approved preferences and facts.
   - Reminders with due timestamps and recurring alarms.
   - Notes and memo manager.
   - Screen understanding & OCR error diagnostics.

---

## 🚀 Installation & Setup

### Prerequisites
- Windows 10 or Windows 11 (64-bit).
- Python 3.10, 3.11, or 3.12 installed ([Download from python.org](https://www.python.org/downloads/)).
  - *Ensure "Add python.exe to PATH" is checked during installation.*
- Microphone and speakers/headphones connected.

### Step 1: Clone or Extract the Project
```powershell
cd MYRAA
```

### Step 2: Automatic Setup via PowerShell
Run the setup wizard:
```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1
```

*Note: If PowerShell script execution is restricted on your machine, run these standard commands directly without activating scripts:*
```cmd
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

### Step 3: Configure Environment Variables
Copy `.env.example` to `.env`:
```cmd
copy .env.example .env
```
Open `.env` in Notepad and add your Gemini API Key:
```ini
GEMINI_API_KEY=AIzaSyYourGeminiApiKeyHere
AI_PROVIDER_MODE=cloud
DEFAULT_CLOUD_MODEL=gemini-3.8-flash
WAKE_WORD=Hey MYRAA
```

---

## 🎮 Running MYRAA

### Option A: Using the Windows Launcher
Double-click `scripts\run.bat` or run:
```cmd
.\scripts\run.bat
```

### Option B: Direct Python Execution
```cmd
.\.venv\Scripts\python.exe app.py
```

### Option C: Headless / Terminal CLI Mode
If PySide6 is not available or you are testing in a Linux / server container:
```cmd
python app.py
```

---

## 🛠️ Windows Automation Allowlists

Tools are strictly sandboxed. By default, MYRAA only accesses:
- **Approved Applications**: `calculator`, `notepad`, `file explorer`, `cmd`, `powershell`, `chrome`, `edge`, `code`, `spotify`, `paint`, `task manager`.
- **Approved Directories**: `%USERPROFILE%\Documents`, `%USERPROFILE%\Downloads`, `%USERPROFILE%\Desktop`, `%USERPROFILE%\Notes`.
- **Approved Web Domains**: `google.com`, `youtube.com`, `github.com`, `wikipedia.org`, `weather.com`, `gmail.com`.

You can customize these lists in `Settings > Security & Permissions` or via `~/.myraa/config.json`.

---

## 📦 Building a Standalone Windows Executable (.exe)

To bundle MYRAA into a distributable Windows application:
```cmd
.\scripts\build_exe.bat
```
The output executable will be created in `dist\MYRAA\MYRAA.exe`.

---

## 🧪 Running Automated Tests

Run the complete test suite:
```cmd
python -m unittest discover -s tests -v
```

---

## 🔒 Security Architecture

MYRAA enforces zero-trust execution against prompt injections and untrusted inputs:
1. Spoken audio and screen OCR are treated as untrusted text.
2. Even if an AI model outputs a destructive instruction, the **RiskClassifier** intercepts the tool call.
3. High and medium-risk operations trigger a modal dialog showing:
   - Tool Name
   - Exact Parameters and File Paths
   - Risk Tier Badge
   - Options to Approve Once, Remember for Session, or Deny.
4. Blocked actions (e.g. credential harvesting or registry tampering) are immediately rejected and logged.
