"""
MYRAA Reminders and Scheduling Store
Tracks due dates, recurring reminders, and task completion.
"""
from dataclasses import dataclass
import datetime
from typing import List, Optional
from .database import get_db


@dataclass
class ReminderItem:
    id: Optional[int]
    title: str
    due_time: str
    recurrence: str = "none"  # none, daily, weekly
    is_completed: bool = False
    created_at: Optional[str] = None


class RemindersStore:
    def __init__(self, db=None):
        self.db = db or get_db()

    def add_reminder(self, title: str, due_time: str, recurrence: str = "none") -> int:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO reminders (title, due_time, recurrence, is_completed)
            VALUES (?, ?, ?, 0)
            """,
            (title, due_time, recurrence)
        )
        conn.commit()
        return cursor.lastrowid

    def list_reminders(self, include_completed: bool = False) -> List[ReminderItem]:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        if include_completed:
            cursor.execute("SELECT id, title, due_time, recurrence, is_completed, created_at FROM reminders ORDER BY due_time ASC")
        else:
            cursor.execute("SELECT id, title, due_time, recurrence, is_completed, created_at FROM reminders WHERE is_completed = 0 ORDER BY due_time ASC")
        rows = cursor.fetchall()
        return [
            ReminderItem(
                id=r["id"],
                title=r["title"],
                due_time=r["due_time"],
                recurrence=r["recurrence"],
                is_completed=bool(r["is_completed"]),
                created_at=r["created_at"]
            )
            for r in rows
        ]

    def mark_completed(self, reminder_id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE reminders SET is_completed = 1 WHERE id = ?", (reminder_id,))
        conn.commit()

    def delete_reminder(self, reminder_id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM reminders WHERE id = ?", (reminder_id,))
        conn.commit()
