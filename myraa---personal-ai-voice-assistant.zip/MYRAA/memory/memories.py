"""
MYRAA Long-Term Memory Store
Stores user-approved preferences, facts, and persistent profile information.
"""
from dataclasses import dataclass
import datetime
from typing import List, Optional
from .database import get_db


@dataclass
class MemoryItem:
    id: Optional[int]
    category: str  # preference, user_info, system_fact, work, custom
    content: str
    tags: str = ""
    confidence: float = 1.0
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class MemoryStore:
    def __init__(self, db=None):
        self.db = db or get_db()

    def add_memory(self, category: str, content: str, tags: str = "") -> int:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO memories (category, content, tags, confidence)
            VALUES (?, ?, ?, 1.0)
            """,
            (category, content, tags)
        )
        conn.commit()
        return cursor.lastrowid

    def update_memory(self, memory_id: int, content: str, category: Optional[str] = None, tags: Optional[str] = None):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        now = datetime.datetime.now().isoformat()
        if category and tags:
            cursor.execute(
                "UPDATE memories SET content = ?, category = ?, tags = ?, updated_at = ? WHERE id = ?",
                (content, category, tags, now, memory_id)
            )
        else:
            cursor.execute(
                "UPDATE memories SET content = ?, updated_at = ? WHERE id = ?",
                (content, now, memory_id)
            )
        conn.commit()

    def delete_memory(self, memory_id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        conn.commit()

    def search_memories(self, query: str = "", limit: int = 20) -> List[MemoryItem]:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        if query:
            param = f"%{query}%"
            cursor.execute(
                """
                SELECT id, category, content, tags, confidence, created_at, updated_at
                FROM memories
                WHERE content LIKE ? OR tags LIKE ? OR category LIKE ?
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (param, param, param, limit)
            )
        else:
            cursor.execute(
                """
                SELECT id, category, content, tags, confidence, created_at, updated_at
                FROM memories
                ORDER BY updated_at DESC
                LIMIT ?
                """,
                (limit,)
            )
        rows = cursor.fetchall()
        return [
            MemoryItem(
                id=r["id"],
                category=r["category"],
                content=r["content"],
                tags=r["tags"] or "",
                confidence=r["confidence"],
                created_at=r["created_at"],
                updated_at=r["updated_at"]
            )
            for r in rows
        ]

    def clear_all(self):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM memories")
        conn.commit()
