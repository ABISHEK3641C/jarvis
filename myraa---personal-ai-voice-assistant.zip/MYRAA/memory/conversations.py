"""
MYRAA Conversation Storage
Handles message history, sessions, and context window truncation.
"""
from dataclasses import dataclass
import json
from typing import Any, Dict, List, Optional
from .database import get_db


@dataclass
class ChatMessage:
    role: str
    content: str
    session_id: str = "default"
    timestamp: Optional[str] = None
    language: str = "en"
    tool_calls: Optional[List[Dict[str, Any]]] = None
    id: Optional[int] = None


class ConversationStore:
    def __init__(self, db=None):
        self.db = db or get_db()

    def add_message(self, message: ChatMessage) -> int:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        tool_json = json.dumps(message.tool_calls) if message.tool_calls else None
        cursor.execute(
            """
            INSERT INTO conversations (session_id, role, content, language, tool_calls)
            VALUES (?, ?, ?, ?, ?)
            """,
            (message.session_id, message.role, message.content, message.language, tool_json)
        )
        conn.commit()
        return cursor.lastrowid

    def get_recent_messages(self, session_id: str = "default", limit: int = 20) -> List[ChatMessage]:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            SELECT id, session_id, role, content, timestamp, language, tool_calls
            FROM conversations
            WHERE session_id = ?
            ORDER BY id DESC
            LIMIT ?
            """,
            (session_id, limit)
        )
        rows = cursor.fetchall()
        messages = []
        for r in reversed(rows):
            tools = json.loads(r["tool_calls"]) if r["tool_calls"] else None
            messages.append(ChatMessage(
                id=r["id"],
                session_id=r["session_id"],
                role=r["role"],
                content=r["content"],
                timestamp=r["timestamp"],
                language=r["language"],
                tool_calls=tools
            ))
        return messages

    def clear_session(self, session_id: str = "default"):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM conversations WHERE session_id = ?", (session_id,))
        conn.commit()

    def clear_all(self):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM conversations")
        conn.commit()
