"""
MYRAA Notes Store
Stores markdown notes and to-do lists.
"""
from dataclasses import dataclass
import datetime
from typing import List, Optional
from .database import get_db


@dataclass
class NoteItem:
    id: Optional[int]
    title: str
    body: str
    tags: str = ""
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class NotesStore:
    def __init__(self, db=None):
        self.db = db or get_db()

    def add_note(self, title: str, body: str, tags: str = "") -> int:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO notes (title, body, tags)
            VALUES (?, ?, ?)
            """,
            (title, body, tags)
        )
        conn.commit()
        return cursor.lastrowid

    def list_notes(self) -> List[NoteItem]:
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, title, body, tags, created_at, updated_at FROM notes ORDER BY updated_at DESC")
        rows = cursor.fetchall()
        return [
            NoteItem(
                id=r["id"],
                title=r["title"],
                body=r["body"],
                tags=r["tags"] or "",
                created_at=r["created_at"],
                updated_at=r["updated_at"]
            )
            for r in rows
        ]

    def delete_note(self, note_id: int):
        conn = self.db.get_connection()
        cursor = conn.cursor()
        cursor.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        conn.commit()
