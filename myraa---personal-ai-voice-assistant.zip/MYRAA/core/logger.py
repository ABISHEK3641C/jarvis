"""
MYRAA Structured Logging and Privacy Masking
Provides secure, structured logging that scrubs API keys and sensitive tokens.
"""
import logging
import os
from pathlib import Path
import re
import sys
from typing import Optional

SENSITIVE_PATTERNS = [
    re.compile(r"(AIza[0-9A-Za-z-_]{35})"),                      # Google API Key
    re.compile(r"(sk-[a-zA-Z0-9]{20,48})"),                      # OpenAI Key
    re.compile(r"(password\s*[:=]\s*)([^\s,]+)", re.IGNORECASE),
    re.compile(r"(token\s*[:=]\s*)([^\s,]+)", re.IGNORECASE),
]


class RedactingFormatter(logging.Formatter):
    """Custom log formatter that scrubs credentials before emitting logs."""
    def format(self, record: logging.LogRecord) -> str:
        msg = super().format(record)
        for pattern in SENSITIVE_PATTERNS:
            msg = pattern.sub(r"[REDACTED_CREDENTIAL]", msg)
        return msg


def setup_logger(name: str = "MYRAA", level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger

    logger.setLevel(level)

    # Console Handler
    c_handler = logging.StreamHandler(sys.stdout)
    formatter = RedactingFormatter(
        "[%(asctime)s] [%(levelname)s] [%(name)s]: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    c_handler.setFormatter(formatter)
    logger.addHandler(c_handler)

    # File Handler
    log_dir = Path.home() / ".myraa" / "logs"
    try:
        log_dir.mkdir(parents=True, exist_ok=True)
        f_handler = logging.FileHandler(log_dir / "myraa.log", encoding="utf-8")
        f_handler.setFormatter(formatter)
        logger.addHandler(f_handler)
    except Exception:
        pass

    return logger


def get_logger(name: str = "MYRAA") -> logging.Logger:
    return logging.getLogger(name)
