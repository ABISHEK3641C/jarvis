"""
MYRAA Event Dispatcher
Decoupled pub/sub event bus for UI, voice, AI, and security events.
"""
from dataclasses import dataclass
from typing import Any, Callable, Dict, List


@dataclass
class Event:
    name: str
    data: Any = None


class EventBus:
    _instance = None
    _listeners: Dict[str, List[Callable[[Event], None]]] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(EventBus, cls).__new__(cls)
            cls._listeners = {}
        return cls._instance

    def subscribe(self, event_name: str, callback: Callable[[Event], None]):
        if event_name not in self._listeners:
            self._listeners[event_name] = []
        if callback not in self._listeners[event_name]:
            self._listeners[event_name].append(callback)

    def unsubscribe(self, event_name: str, callback: Callable[[Event], None]):
        if event_name in self._listeners and callback in self._listeners[event_name]:
            self._listeners[event_name].remove(callback)

    def publish(self, event_name: str, data: Any = None):
        event = Event(name=event_name, data=data)
        for cb in self._listeners.get(event_name, []):
            try:
                cb(event)
            except Exception as e:
                import logging
                logging.getLogger("MYRAA").error(f"Error dispatching event {event_name}: {e}")

    def clear(self):
        self._listeners.clear()


# Global Singleton instance
event_bus = EventBus()
