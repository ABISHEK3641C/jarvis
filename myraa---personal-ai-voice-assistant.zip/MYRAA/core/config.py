"""
MYRAA Application Configuration
Manages runtime configuration, environment variables, security flags, and defaults.
"""
from dataclasses import dataclass, field
import json
import os
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class AppConfig:
    # Application Info
    app_name: str = "MYRAA"
    app_version: str = "1.0.0"
    base_dir: Path = field(default_factory=lambda: Path(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
    data_dir: Path = field(default_factory=lambda: Path.home() / ".myraa")
    
    # AI Configuration
    ai_provider: str = "cloud"  # "cloud", "local", "auto"
    cloud_model: str = "gemini-3.8-flash"
    local_llm_url: str = "http://localhost:11434/v1"
    local_llm_model: str = "llama3:8b"
    gemini_api_key: str = ""
    openai_api_key: str = ""
    temperature: float = 0.7
    max_tokens: int = 2048
    system_prompt: str = (
        "You are MYRAA, a helpful, precise, and secure personal AI desktop assistant for Windows. "
        "You speak naturally in English, Hindi, and Hinglish. "
        "Always confirm before performing destructive actions. Be concise, polite, and helpful."
    )

    # Voice Configuration
    wake_word: str = "Hey MYRAA"
    wake_word_enabled: bool = True
    stt_model_size: str = "small"  # tiny, base, small, medium
    stt_device: str = "cpu"        # cpu or cuda
    default_language: str = "en"   # en, hi, hinglish, auto
    tts_voice_id: str = "default"
    tts_rate: int = 175
    tts_volume: float = 1.0
    continuous_listening: bool = False

    # Security & Policy Settings
    require_confirmation_high_risk: bool = True
    require_confirmation_medium_risk: bool = True
    audit_logging: bool = True
    allow_screen_capture: bool = True
    strict_sandbox: bool = True

    # Windows Automation Allowlists
    approved_apps: Dict[str, str] = field(default_factory=lambda: {
        "calculator": "calc.exe",
        "notepad": "notepad.exe",
        "file explorer": "explorer.exe",
        "command prompt": "cmd.exe",
        "powershell": "powershell.exe",
        "settings": "start ms-settings:",
        "chrome": "chrome.exe",
        "edge": "msedge.exe",
        "code": "code.exe",
        "spotify": "spotify.exe",
        "paint": "mspaint.exe",
        "task manager": "taskmgr.exe"
    })
    
    approved_urls: List[str] = field(default_factory=lambda: [
        "https://google.com",
        "https://youtube.com",
        "https://github.com",
        "https://wikipedia.org",
        "https://reddit.com",
        "https://weather.com",
        "https://gmail.com",
        "https://linkedin.com"
    ])

    approved_directories: List[str] = field(default_factory=lambda: [
        str(Path.home() / "Documents"),
        str(Path.home() / "Downloads"),
        str(Path.home() / "Desktop"),
        str(Path.home() / "Notes")
    ])

    # UI Preferences
    theme: str = "dark"  # "dark" or "light"
    sound_effects: bool = True
    minimize_to_tray: bool = True

    def __post_init__(self):
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.load_from_env()
        self.load_user_preferences()

    def load_from_env(self):
        """Load API keys and settings from environment variables or .env file."""
        env_path = self.base_dir / ".env"
        if env_path.exists():
            try:
                from dotenv import load_dotenv
                load_dotenv(dotenv_path=env_path)
            except ImportError:
                pass

        self.gemini_api_key = os.getenv("GEMINI_API_KEY", self.gemini_api_key)
        self.openai_api_key = os.getenv("OPENAI_API_KEY", self.openai_api_key)
        self.local_llm_url = os.getenv("LOCAL_LLM_URL", self.local_llm_url)
        self.local_llm_model = os.getenv("LOCAL_LLM_MODEL", self.local_llm_model)
        self.ai_provider = os.getenv("AI_PROVIDER_MODE", self.ai_provider)
        self.wake_word = os.getenv("WAKE_WORD", self.wake_word)

    @property
    def config_file_path(self) -> Path:
        return self.data_dir / "config.json"

    def load_user_preferences(self):
        """Loads persistent user customizations from config.json."""
        if self.config_file_path.exists():
            try:
                with open(self.config_file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    for k, v in data.items():
                        if hasattr(self, k) and not isinstance(getattr(self, k), Path):
                            setattr(self, k, v)
            except Exception:
                pass

    def save_user_preferences(self):
        """Saves current state into config.json."""
        data = {
            "ai_provider": self.ai_provider,
            "cloud_model": self.cloud_model,
            "local_llm_url": self.local_llm_url,
            "local_llm_model": self.local_llm_model,
            "wake_word": self.wake_word,
            "wake_word_enabled": self.wake_word_enabled,
            "default_language": self.default_language,
            "tts_rate": self.tts_rate,
            "tts_volume": self.tts_volume,
            "require_confirmation_high_risk": self.require_confirmation_high_risk,
            "require_confirmation_medium_risk": self.require_confirmation_medium_risk,
            "allow_screen_capture": self.allow_screen_capture,
            "theme": self.theme,
            "approved_directories": self.approved_directories
        }
        try:
            with open(self.config_file_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)
        except Exception:
            pass


_GLOBAL_CONFIG: Optional[AppConfig] = None


def get_config() -> AppConfig:
    global _GLOBAL_CONFIG
    if _GLOBAL_CONFIG is None:
        _GLOBAL_CONFIG = AppConfig()
    return _GLOBAL_CONFIG
