"""
MYRAA Chat Message History Widget
Renders conversation bubbles for user queries, assistant speech, tool execution badges, and errors.
"""
from typing import List, Optional

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (
        QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTextBrowser, QScrollArea, QFrame
    )
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    class QWidget: pass


if HAVE_QT:
    class ChatBubble(QFrame):
        def __init__(self, role: str, text: str, timestamp: str = "", risk_level: Optional[str] = None, parent=None):
            super().__init__(parent)
            self.setObjectName("ChatBubble")
            layout = QVBoxLayout(self)
            layout.setContentsMargins(14, 10, 14, 10)
            layout.setSpacing(4)

            # Header with role and timestamp
            header_layout = QHBoxLayout()
            role_label = QLabel("MYRAA" if role == "assistant" else "You")
            role_label.setStyleSheet("font-weight: bold; color: #58a6ff;" if role == "assistant" else "font-weight: bold; color: #3fb950;")
            header_layout.addWidget(role_label)

            if risk_level:
                risk_badge = QLabel(f"[{risk_level}]")
                risk_color = "#f85149" if risk_level == "HIGH" else "#d29922" if risk_level == "MEDIUM" else "#3fb950"
                risk_badge.setStyleSheet(f"color: {risk_color}; font-weight: 600; font-size: 11px;")
                header_layout.addWidget(risk_badge)

            header_layout.addStretch()

            if timestamp:
                time_label = QLabel(timestamp)
                time_label.setStyleSheet("color: #8b949e; font-size: 11px;")
                header_layout.addWidget(time_label)

            layout.addLayout(header_layout)

            # Message content
            body_label = QLabel(text)
            body_label.setWordWrap(True)
            body_label.setTextInteractionFlags(Qt.TextSelectableByMouse)
            body_label.setStyleSheet("color: #f0f6fc; font-size: 13px; line-height: 1.4;")
            layout.addWidget(body_label)

            # Bubble background styling
            bg = "#161b22" if role == "assistant" else "#1f242c"
            border = "#30363d"
            self.setStyleSheet(f"""
                QFrame#ChatBubble {{
                    background-color: {bg};
                    border: 1px solid {border};
                    border-radius: 12px;
                    margin: 4px 8px;
                }}
            """)


    class ChatHistoryWidget(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            main_layout = QVBoxLayout(self)
            main_layout.setContentsMargins(0, 0, 0, 0)

            self.scroll_area = QScrollArea(self)
            self.scroll_area.setWidgetResizable(True)
            self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)

            self.container = QWidget()
            self.container_layout = QVBoxLayout(self.container)
            self.container_layout.setAlignment(Qt.AlignTop)
            self.container_layout.setSpacing(6)
            self.container_layout.setContentsMargins(12, 12, 12, 12)

            self.scroll_area.setWidget(self.container)
            main_layout.addWidget(self.scroll_area)

        def add_message(self, role: str, text: str, timestamp: str = "", risk_level: Optional[str] = None):
            bubble = ChatBubble(role, text, timestamp, risk_level, self.container)
            self.container_layout.addWidget(bubble)
            QTimer.singleShot(50, self._scroll_to_bottom)

        def _scroll_to_bottom(self):
            scrollbar = self.scroll_area.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())

        def clear(self):
            while self.container_layout.count():
                item = self.container_layout.takeAt(0)
                widget = item.widget()
                if widget:
                    widget.deleteLater()
else:
    class ChatHistoryWidget:
        def __init__(self, *args, **kwargs): pass
        def add_message(self, *args, **kwargs): pass
        def clear(self): pass
