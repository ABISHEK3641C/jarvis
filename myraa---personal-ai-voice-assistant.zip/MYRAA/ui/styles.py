"""
MYRAA PySide6 Modern Stylesheets
Provides premium Fluent / macOS-grade dark and light stylesheets with neon accents and accessible contrast.
"""

DARK_THEME_QSS = """
QMainWindow, QDialog {
    background-color: #0d1117;
    color: #e6edf3;
    font-family: 'Segoe UI', 'Segoe UI Variable', system-ui, -apple-system, sans-serif;
    font-size: 13px;
}

QWidget {
    color: #e6edf3;
}

/* Sidebar styling */
#SidebarWidget {
    background-color: #161b22;
    border-right: 1px solid #30363d;
}

#SidebarTitle {
    font-size: 16px;
    font-weight: 700;
    color: #58a6ff;
    padding: 12px 8px;
}

QPushButton.nav-button {
    background-color: transparent;
    color: #8b949e;
    border: none;
    border-radius: 8px;
    padding: 10px 14px;
    text-align: left;
    font-weight: 500;
    font-size: 13px;
}

QPushButton.nav-button:hover {
    background-color: #21262d;
    color: #f0f6fc;
}

QPushButton.nav-button:checked, QPushButton.nav-button.active {
    background-color: #1f6feb;
    color: #ffffff;
    font-weight: 600;
}

/* Chat History */
QScrollArea {
    border: none;
    background-color: transparent;
}

#ChatContainer {
    background-color: transparent;
}

/* Input Bar */
#InputContainer {
    background-color: #161b22;
    border-top: 1px solid #30363d;
    padding: 12px;
}

QLineEdit {
    background-color: #0d1117;
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 10px 14px;
    color: #f0f6fc;
    font-size: 14px;
    selection-background-color: #1f6feb;
}

QLineEdit:focus {
    border: 1px solid #58a6ff;
}

/* Action Buttons */
QPushButton.primary-btn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #238636, stop:1 #2ea043);
    color: #ffffff;
    font-weight: 600;
    border: none;
    border-radius: 10px;
    padding: 10px 18px;
}

QPushButton.primary-btn:hover {
    background: #2ea043;
}

QPushButton.danger-btn {
    background-color: #da3633;
    color: #ffffff;
    font-weight: 600;
    border: none;
    border-radius: 8px;
    padding: 8px 14px;
}

QPushButton.danger-btn:hover {
    background-color: #f85149;
}

/* Status Bar */
#StatusBar {
    background-color: #090d13;
    border-top: 1px solid #21262d;
    color: #8b949e;
    font-size: 11px;
    padding: 4px 12px;
}

/* Status Indicator Dots */
QLabel.status-online {
    color: #3fb950;
    font-weight: 600;
}

QLabel.status-offline {
    color: #e3b341;
    font-weight: 600;
}

/* Scrollbars */
QScrollBar:vertical {
    border: none;
    background: #161b22;
    width: 8px;
    border-radius: 4px;
}

QScrollBar::handle:vertical {
    background: #30363d;
    min-height: 20px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #8b949e;
}
"""

LIGHT_THEME_QSS = """
QMainWindow, QDialog {
    background-color: #f6f8fa;
    color: #1f2328;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    font-size: 13px;
}

QWidget {
    color: #1f2328;
}

#SidebarWidget {
    background-color: #ffffff;
    border-right: 1px solid #d0d7de;
}

#SidebarTitle {
    font-size: 16px;
    font-weight: 700;
    color: #0969da;
    padding: 12px 8px;
}

QPushButton.nav-button {
    background-color: transparent;
    color: #656d76;
    border: none;
    border-radius: 8px;
    padding: 10px 14px;
    text-align: left;
    font-weight: 500;
}

QPushButton.nav-button:hover {
    background-color: #eaeef2;
    color: #1f2328;
}

QPushButton.nav-button:checked, QPushButton.nav-button.active {
    background-color: #0969da;
    color: #ffffff;
    font-weight: 600;
}

#InputContainer {
    background-color: #ffffff;
    border-top: 1px solid #d0d7de;
    padding: 12px;
}

QLineEdit {
    background-color: #ffffff;
    border: 1px solid #d0d7de;
    border-radius: 10px;
    padding: 10px 14px;
    color: #1f2328;
    font-size: 14px;
}

QLineEdit:focus {
    border: 1px solid #0969da;
}

QPushButton.primary-btn {
    background-color: #1f883d;
    color: #ffffff;
    font-weight: 600;
    border: none;
    border-radius: 10px;
    padding: 10px 18px;
}

#StatusBar {
    background-color: #eaeef2;
    border-top: 1px solid #d0d7de;
    color: #656d76;
    font-size: 11px;
}
"""


def get_stylesheet(theme: str = "dark") -> str:
    return DARK_THEME_QSS if theme == "dark" else LIGHT_THEME_QSS
