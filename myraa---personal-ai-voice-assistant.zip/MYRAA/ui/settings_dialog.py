"""
MYRAA Settings Dialog
Controls language, speech speed, AI model selection, permissions, and security allowlists.
"""
from typing import Optional
from ..core.config import get_config

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QTabWidget, QWidget, QLabel,
        QLineEdit, QComboBox, QSlider, QCheckBox, QPushButton, QSpinBox
    )
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    class QDialog: pass


if HAVE_QT:
    class SettingsDialog(QDialog):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.config = get_config()
            self.setWindowTitle("MYRAA Settings & Preferences")
            self.setMinimumSize(540, 480)

            main_layout = QVBoxLayout(self)
            self.tabs = QTabWidget(self)

            # Tab 1: Voice & Language
            voice_tab = QWidget()
            v_layout = QVBoxLayout(voice_tab)

            v_layout.addWidget(QLabel("Primary Assistant Language:"))
            self.lang_combo = QComboBox()
            self.lang_combo.addItems(["en (English)", "hi (Hindi / हिंदी)", "hinglish (Hinglish)", "auto (Detect)"])
            v_layout.addWidget(self.lang_combo)

            v_layout.addWidget(QLabel("Wake Word Trigger:"))
            self.wake_edit = QLineEdit(self.config.wake_word)
            v_layout.addWidget(self.wake_edit)

            self.wake_toggle = QCheckBox("Enable Wake Word continuous detection ('Hey MYRAA')")
            self.wake_toggle.setChecked(self.config.wake_word_enabled)
            v_layout.addWidget(self.wake_toggle)

            v_layout.addWidget(QLabel(f"Speech Speed Rate (WPM):"))
            self.rate_slider = QSlider(Qt.Horizontal)
            self.rate_slider.setRange(100, 250)
            self.rate_slider.setValue(self.config.tts_rate)
            v_layout.addWidget(self.rate_slider)
            v_layout.addStretch()
            self.tabs.addTab(voice_tab, "Voice & Language")

            # Tab 2: AI & Models
            ai_tab = QWidget()
            ai_layout = QVBoxLayout(ai_tab)

            ai_layout.addWidget(QLabel("AI Provider Mode:"))
            self.ai_mode_combo = QComboBox()
            self.ai_mode_combo.addItems(["cloud (Google Gemini)", "local (Ollama / Local Server)", "auto (Cloud with offline fallback)"])
            ai_layout.addWidget(self.ai_mode_combo)

            ai_layout.addWidget(QLabel("Local Inference URL:"))
            self.local_url_edit = QLineEdit(self.config.local_llm_url)
            ai_layout.addWidget(self.local_url_edit)

            ai_layout.addWidget(QLabel("Local Model Identifier:"))
            self.local_model_edit = QLineEdit(self.config.local_llm_model)
            ai_layout.addWidget(self.local_model_edit)
            ai_layout.addStretch()
            self.tabs.addTab(ai_tab, "AI Engine")

            # Tab 3: Security & Permissions
            sec_tab = QWidget()
            sec_layout = QVBoxLayout(sec_tab)

            self.high_risk_cb = QCheckBox("Require Confirmation for HIGH Risk actions (files, shutdown)")
            self.high_risk_cb.setChecked(self.config.require_confirmation_high_risk)
            sec_layout.addWidget(self.high_risk_cb)

            self.med_risk_cb = QCheckBox("Require Confirmation for MEDIUM Risk actions (read documents, volume)")
            self.med_risk_cb.setChecked(self.config.require_confirmation_medium_risk)
            sec_layout.addWidget(self.med_risk_cb)

            self.screen_perm_cb = QCheckBox("Allow explicit desktop screenshot capture for Vision OCR")
            self.screen_perm_cb.setChecked(self.config.allow_screen_capture)
            sec_layout.addWidget(self.screen_perm_cb)

            self.audit_cb = QCheckBox("Enable security audit logging to disk")
            self.audit_cb.setChecked(self.config.audit_logging)
            sec_layout.addWidget(self.audit_cb)
            sec_layout.addStretch()
            self.tabs.addTab(sec_tab, "Security & Privacy")

            # Tab 4: Appearance
            theme_tab = QWidget()
            t_layout = QVBoxLayout(theme_tab)
            t_layout.addWidget(QLabel("Interface Theme:"))
            self.theme_combo = QComboBox()
            self.theme_combo.addItems(["dark", "light"])
            self.theme_combo.setCurrentText(self.config.theme)
            t_layout.addWidget(self.theme_combo)
            t_layout.addStretch()
            self.tabs.addTab(theme_tab, "Appearance")

            main_layout.addWidget(self.tabs)

            # Save / Cancel Buttons
            btn_box = QHBoxLayout()
            btn_box.addStretch()
            cancel_btn = QPushButton("Cancel")
            cancel_btn.clicked.connect(self.reject)
            btn_box.addWidget(cancel_btn)

            save_btn = QPushButton("Save Settings")
            save_btn.setStyleSheet("background-color: #238636; color: white; font-weight: bold; padding: 6px 14px; border-radius: 6px;")
            save_btn.clicked.connect(self._save_settings)
            btn_box.addWidget(save_btn)
            main_layout.addLayout(btn_box)

        def _save_settings(self):
            self.config.wake_word = self.wake_edit.text().strip()
            self.config.wake_word_enabled = self.wake_toggle.isChecked()
            self.config.tts_rate = self.rate_slider.value()
            self.config.local_llm_url = self.local_url_edit.text().strip()
            self.config.local_llm_model = self.local_model_edit.text().strip()
            self.config.require_confirmation_high_risk = self.high_risk_cb.isChecked()
            self.config.require_confirmation_medium_risk = self.med_risk_cb.isChecked()
            self.config.allow_screen_capture = self.screen_perm_cb.isChecked()
            self.config.audit_logging = self.audit_cb.isChecked()
            self.config.theme = self.theme_combo.currentText()
            self.config.save_user_preferences()
            self.accept()
else:
    class SettingsDialog:
        def __init__(self, *args, **kwargs): pass
        def exec(self): return 1
