"""
MYRAA Desktop Main Window (PySide6)
Combines the Animated 3D Orb, Real-time Waveform, Chat History, Navigation Sidebar,
Microphone controls, Voice Interruption, and Security Dialogs into a unified desktop app.
"""
import datetime
import os
import sys
from typing import Optional

try:
    from PySide6.QtCore import Qt, QTimer, Signal, QObject
    from PySide6.QtGui import QIcon, QKeySequence, QShortcut
    from PySide6.QtWidgets import (
        QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QPushButton,
        QLineEdit, QLabel, QStackedWidget, QSplitter, QStatusBar, QFrame
    )
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    class QMainWindow: pass
    class QObject: pass
    def Signal(*args): return None

from ..core.config import get_config
from ..core.logger import get_logger
from ..ai.router import ai_router
from ..voice.tts import tts_engine
from ..voice.audio_manager import audio_manager, AudioState
from ..security.confirmation import confirmation_manager, ConfirmationRequest
from ..memory.conversations import ConversationStore, ChatMessage
from ..memory.memories import MemoryStore
from ..memory.reminders import RemindersStore
from .orb_widget import AIOrbWidget
from .waveform_widget import AudioWaveformWidget
from .chat_widget import ChatHistoryWidget
from .confirmation_dialog import SecurityConfirmationDialog
from .settings_dialog import SettingsDialog
from .styles import get_stylesheet

logger = get_logger("MYRAA.UI.MainWindow")


if HAVE_QT:
    class WorkerSignals(QObject):
        ai_response_ready = Signal(str, str, str)  # role, text, model_name
        tool_status_ready = Signal(str, str)        # tool_name, result_str
        audio_state_changed = Signal(str)           # new_state


    class MainWindow(QMainWindow):
        def __init__(self):
            super().__init__()
            self.config = get_config()
            self.conv_store = ConversationStore()
            self.memory_store = MemoryStore()
            self.reminders_store = RemindersStore()

            self.setWindowTitle(f"{self.config.app_name} - Personal AI Voice Assistant")
            self.resize(1120, 780)
            self.setMinimumSize(850, 600)

            self.signals = WorkerSignals()
            self.signals.ai_response_ready.connect(self._on_ai_response_ready)
            self.signals.audio_state_changed.connect(self._on_audio_state_changed)

            # Register UI confirmation callback into Security system
            confirmation_manager.set_ui_callback(self._show_confirmation_dialog)

            self._init_ui()
            self._apply_theme()
            self._load_conversation_history()

            # Periodic status checker (online/offline & internet)
            self.status_timer = QTimer(self)
            self.status_timer.timeout.connect(self._refresh_status_bar)
            self.status_timer.start(5000)

            # Keyboard shortcut: Ctrl+M to toggle mic, Space or Escape to stop speaking
            QShortcut(QKeySequence("Ctrl+M"), self, self._toggle_microphone)
            QShortcut(QKeySequence("Escape"), self, self._stop_speaking)

        def _init_ui(self):
            central_widget = QWidget(self)
            self.setCentralWidget(central_widget)
            root_layout = QHBoxLayout(central_widget)
            root_layout.setContentsMargins(0, 0, 0, 0)
            root_layout.setSpacing(0)

            # 1. Left Navigation Sidebar
            self.sidebar = QWidget()
            self.sidebar.setObjectName("SidebarWidget")
            self.sidebar.setFixedWidth(220)
            sidebar_layout = QVBoxLayout(self.sidebar)
            sidebar_layout.setContentsMargins(12, 16, 12, 16)
            sidebar_layout.setSpacing(6)

            title_lbl = QLabel(f"✨ {self.config.app_name}")
            title_lbl.setObjectName("SidebarTitle")
            sidebar_layout.addWidget(title_lbl)

            # Nav buttons
            self.btn_chat = QPushButton("💬 Chat & Voice")
            self.btn_chat.setProperty("class", "nav-button active")
            self.btn_chat.clicked.connect(lambda: self.stack.setCurrentIndex(0))
            sidebar_layout.addWidget(self.btn_chat)

            self.btn_tools = QPushButton("🛠️ Windows Tools")
            self.btn_tools.setProperty("class", "nav-button")
            self.btn_tools.clicked.connect(lambda: self.stack.setCurrentIndex(1))
            sidebar_layout.addWidget(self.btn_tools)

            self.btn_reminders = QPushButton("⏰ Reminders & Notes")
            self.btn_reminders.setProperty("class", "nav-button")
            self.btn_reminders.clicked.connect(lambda: self.stack.setCurrentIndex(2))
            sidebar_layout.addWidget(self.btn_reminders)

            self.btn_memory = QPushButton("🧠 Personal Memory")
            self.btn_memory.setProperty("class", "nav-button")
            self.btn_memory.clicked.connect(lambda: self.stack.setCurrentIndex(3))
            sidebar_layout.addWidget(self.btn_memory)

            sidebar_layout.addStretch()

            self.btn_settings = QPushButton("⚙️ Settings")
            self.btn_settings.setProperty("class", "nav-button")
            self.btn_settings.clicked.connect(self._open_settings)
            sidebar_layout.addWidget(self.btn_settings)

            root_layout.addWidget(self.sidebar)

            # 2. Main Content Area (QStackedWidget)
            self.stack = QStackedWidget()

            # Page 0: Chat & Voice Primary Panel
            chat_page = QWidget()
            cp_layout = QVBoxLayout(chat_page)
            cp_layout.setContentsMargins(16, 16, 16, 16)
            cp_layout.setSpacing(12)

            # Orb & Waveform Hero Section
            hero_box = QFrame()
            hero_box.setStyleSheet("background-color: #161b22; border-radius: 14px; border: 1px solid #30363d;")
            hero_layout = QVBoxLayout(hero_box)
            hero_layout.setContentsMargins(16, 12, 16, 12)
            hero_layout.setAlignment(Qt.AlignCenter)

            self.orb_widget = AIOrbWidget(self)
            hero_layout.addWidget(self.orb_widget, alignment=Qt.AlignCenter)

            self.waveform_widget = AudioWaveformWidget(self)
            hero_layout.addWidget(self.waveform_widget)

            cp_layout.addWidget(hero_box)

            # Chat History
            self.chat_history = ChatHistoryWidget(self)
            cp_layout.addWidget(self.chat_history, stretch=1)

            # Bottom Input & Voice Controls Bar
            input_box = QFrame()
            input_box.setObjectName("InputContainer")
            ib_layout = QHBoxLayout(input_box)
            ib_layout.setContentsMargins(8, 8, 8, 8)
            ib_layout.setSpacing(8)

            # Mic button
            self.mic_btn = QPushButton("🎙️ Listen")
            self.mic_btn.setObjectName("MicButton")
            self.mic_btn.setStyleSheet("background-color: #1f6feb; color: white; font-weight: bold; padding: 10px 16px; border-radius: 10px;")
            self.mic_btn.clicked.connect(self._toggle_microphone)
            ib_layout.addWidget(self.mic_btn)

            # Text input
            self.text_input = QLineEdit()
            self.text_input.setPlaceholderText("Type a message or command (English, हिंदी, Hinglish)... Press Enter")
            self.text_input.returnPressed.connect(self._on_send_text)
            ib_layout.addWidget(self.text_input, stretch=1)

            # Stop / Interrupt Speaking Button
            self.stop_btn = QPushButton("⏹️ Stop")
            self.stop_btn.setStyleSheet("background-color: #da3633; color: white; font-weight: bold; padding: 10px 14px; border-radius: 10px;")
            self.stop_btn.clicked.connect(self._stop_speaking)
            ib_layout.addWidget(self.stop_btn)

            # Send button
            self.send_btn = QPushButton("Send")
            self.send_btn.setProperty("class", "primary-btn")
            self.send_btn.clicked.connect(self._on_send_text)
            ib_layout.addWidget(self.send_btn)

            cp_layout.addWidget(input_box)
            self.stack.addWidget(chat_page)

            # Page 1: Windows Tools Panel
            tools_page = self._create_tools_panel()
            self.stack.addWidget(tools_page)

            # Page 2: Reminders & Notes Panel
            reminders_page = self._create_reminders_panel()
            self.stack.addWidget(reminders_page)

            # Page 3: Memory Vault Panel
            memory_page = self._create_memory_panel()
            self.stack.addWidget(memory_page)

            root_layout.addWidget(self.stack, stretch=1)

            # 3. Status Bar
            self.status_bar = QStatusBar(self)
            self.status_bar.setObjectName("StatusBar")
            self.setStatusBar(self.status_bar)

            self.lbl_mic_status = QLabel("Mic: Standby")
            self.lbl_net_status = QLabel("● Online")
            self.lbl_net_status.setProperty("class", "status-online")
            self.lbl_model_status = QLabel(f"AI: {self.config.cloud_model}")

            self.status_bar.addWidget(self.lbl_mic_status)
            self.status_bar.addWidget(QLabel(" | "))
            self.status_bar.addWidget(self.lbl_model_status)
            self.status_bar.addPermanentWidget(self.lbl_net_status)

        def _create_tools_panel(self) -> QWidget:
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(24, 24, 24, 24)
            layout.setSpacing(16)

            title = QLabel("Approved Windows Automation Tools")
            title.setStyleSheet("font-size: 18px; font-weight: bold; color: #58a6ff;")
            layout.addWidget(title)

            desc = QLabel("Only explicitly allowlisted Windows tools can be invoked. High-impact operations require confirmation.")
            desc.setStyleSheet("color: #8b949e;")
            layout.addWidget(desc)

            # Quick Action buttons
            grid_frame = QFrame()
            g_layout = QVBoxLayout(grid_frame)

            btn_calc = QPushButton("Open Calculator (calc.exe)")
            btn_calc.clicked.connect(lambda: self._run_quick_tool("launch_approved_app", {"app_name": "calculator"}))
            g_layout.addWidget(btn_calc)

            btn_sys = QPushButton("Check System Health (CPU, RAM, Disk)")
            btn_sys.clicked.connect(lambda: self._run_quick_tool("get_system_info", {}))
            g_layout.addWidget(btn_sys)

            btn_screen = QPushButton("Capture Screen for Vision OCR Analysis")
            btn_screen.clicked.connect(lambda: self._run_quick_tool("capture_screen", {"reason": "User manual test"}))
            g_layout.addWidget(btn_screen)

            layout.addWidget(grid_frame)
            layout.addStretch()
            return panel

        def _create_reminders_panel(self) -> QWidget:
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(24, 24, 24, 24)
            title = QLabel("Reminders & Daily Schedule")
            title.setStyleSheet("font-size: 18px; font-weight: bold; color: #58a6ff;")
            layout.addWidget(title)
            # Fetch reminders
            rems = self.reminders_store.list_reminders()
            if not rems:
                layout.addWidget(QLabel("No active reminders scheduled. Say 'remind me to check email at 5pm' to create one."))
            for r in rems:
                layout.addWidget(QLabel(f"• {r.title} (Due: {r.due_time})"))
            layout.addStretch()
            return panel

        def _create_memory_panel(self) -> QWidget:
            panel = QWidget()
            layout = QVBoxLayout(panel)
            layout.setContentsMargins(24, 24, 24, 24)
            title = QLabel("User Memory Vault (SQLite)")
            title.setStyleSheet("font-size: 18px; font-weight: bold; color: #58a6ff;")
            layout.addWidget(title)
            mems = self.memory_store.search_memories()
            if not mems:
                layout.addWidget(QLabel("No persistent memories stored yet. Tell MYRAA your preferences to remember them."))
            for m in mems:
                layout.addWidget(QLabel(f"[{m.category}] {m.content}"))
            layout.addStretch()
            return panel

        def _load_conversation_history(self):
            history = self.conv_store.get_recent_messages(limit=10)
            if not history:
                self.chat_history.add_message(
                    "assistant",
                    "Hello! I am MYRAA, your personal AI voice assistant for Windows. "
                    "How can I help you today? आप मुझसे हिंदी या English में बात कर सकते हैं।"
                )
            else:
                for msg in history:
                    self.chat_history.add_message(msg.role, msg.content, msg.timestamp or "")

        def _on_send_text(self):
            text = self.text_input.text().strip()
            if not text:
                return
            self.text_input.clear()

            # Record in UI and DB
            now_str = datetime.datetime.now().strftime("%I:%M %p")
            self.chat_history.add_message("user", text, now_str)
            self.conv_store.add_message(ChatMessage(role="user", content=text))

            # Update orb to THINKING
            self.orb_widget.set_state("THINKING")
            self.waveform_widget.set_active(True)

            # Asynchronous query routing
            import threading
            def process_query():
                resp = ai_router.route_query(text)
                self.signals.ai_response_ready.emit("assistant", resp.text, resp.model_name)

            threading.Thread(target=process_query, daemon=True).start()

        def _on_ai_response_ready(self, role: str, text: str, model_name: str):
            now_str = datetime.datetime.now().strftime("%I:%M %p")
            self.chat_history.add_message(role, text, now_str)
            self.conv_store.add_message(ChatMessage(role=role, content=text))

            # Update Orb to SPEAKING and trigger TTS
            self.orb_widget.set_state("SPEAKING")
            tts_engine.speak(text, on_complete=lambda: self.signals.audio_state_changed.emit("IDLE"))

        def _on_audio_state_changed(self, state: str):
            self.orb_widget.set_state(state)
            self.waveform_widget.set_active(state != "IDLE")

        def _toggle_microphone(self):
            current = self.orb_widget._state
            if current != "LISTENING":
                self.orb_widget.set_state("LISTENING")
                self.waveform_widget.set_active(True)
                self.mic_btn.setText("🔴 Listening...")
                self.lbl_mic_status.setText("Mic: Active Recording")
            else:
                self.orb_widget.set_state("IDLE")
                self.waveform_widget.set_active(False)
                self.mic_btn.setText("🎙️ Listen")
                self.lbl_mic_status.setText("Mic: Standby")

        def _stop_speaking(self):
            tts_engine.stop()
            self.orb_widget.set_state("IDLE")
            self.waveform_widget.set_active(False)

        def _show_confirmation_dialog(self, req: ConfirmationRequest) -> bool:
            dialog = SecurityConfirmationDialog(req, self)
            result = dialog.exec()
            is_approved = (result == 1)
            if is_approved and dialog.remember_choice:
                confirmation_manager.whitelist_for_session(req.tool_name, req.parameters)
            return is_approved

        def _run_quick_tool(self, tool_name: str, params: dict):
            from ..tools.registry import tool_registry
            res = tool_registry.execute_tool(tool_name, params)
            if res.get("success"):
                self.chat_history.add_message("assistant", f"Tool executed: {res.get('data')}")
            else:
                self.chat_history.add_message("assistant", f"Tool failed or blocked: {res.get('error')}", risk_level="HIGH")

        def _open_settings(self):
            dialog = SettingsDialog(self)
            if dialog.exec() == 1:
                self._apply_theme()
                self._refresh_status_bar()

        def _apply_theme(self):
            self.setStyleSheet(get_stylesheet(self.config.theme))

        def _refresh_status_bar(self):
            online = ai_router.is_online()
            if online:
                self.lbl_net_status.setText("● Online")
                self.lbl_net_status.setProperty("class", "status-online")
            else:
                self.lbl_net_status.setText("○ Offline Mode")
                self.lbl_net_status.setProperty("class", "status-offline")
            self.lbl_model_status.setText(f"AI: {self.config.cloud_model if online else 'Offline Engine'}")
else:
    class MainWindow:
        def __init__(self, *args, **kwargs): pass
        def show(self): pass
