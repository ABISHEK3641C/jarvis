"""
MYRAA Real-Time Audio Waveform Widget
Displays animated audio equalizer bars and wave lines reflecting microphone or TTS audio levels.
"""
import math
import random
from typing import List

try:
    from PySide6.QtCore import Qt, QTimer, QRectF
    from PySide6.QtGui import QPainter, QColor, QLinearGradient, QBrush, QPen
    from PySide6.QtWidgets import QWidget
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    class QWidget:
        pass


if HAVE_QT:
    class AudioWaveformWidget(QWidget):
        def __init__(self, parent=None, bar_count: int = 36):
            super().__init__(parent)
            self.setMinimumHeight(44)
            self.bar_count = bar_count
            self._bars = [0.1] * self.bar_count
            self._target_bars = [0.1] * self.bar_count
            self._is_active = False

            self._timer = QTimer(self)
            self._timer.timeout.connect(self._update_animation)
            self._timer.start(30)

        def set_active(self, active: bool):
            self._is_active = active
            if not active:
                self._target_bars = [0.08] * self.bar_count

        def set_levels(self, levels: List[float]):
            for i in range(min(len(levels), self.bar_count)):
                self._target_bars[i] = max(0.08, min(1.0, levels[i]))

        def _update_animation(self):
            if self._is_active and all(t <= 0.1 for t in self._target_bars):
                # Idle synthetic wave movement
                for i in range(self.bar_count):
                    self._target_bars[i] = 0.15 + 0.15 * math.sin(i * 0.4 + QTimer().remainingTime() * 0.01)

            # Smooth lerp
            for i in range(self.bar_count):
                self._bars[i] += (self._target_bars[i] - self._bars[i]) * 0.3
            self.update()

        def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)

            w = self.width()
            h = self.height()
            gap = 3.0
            total_gaps = gap * (self.bar_count - 1)
            bar_w = max(2.0, (w - total_gaps) / self.bar_count)
            mid_y = h / 2.0

            grad = QLinearGradient(0, 0, 0, h)
            grad.setColorAt(0.0, QColor(0, 210, 255, 230))
            grad.setColorAt(0.5, QColor(88, 166, 255, 200))
            grad.setColorAt(1.0, QColor(31, 111, 235, 120))
            painter.setBrush(QBrush(grad))
            painter.setPen(Qt.NoPen)

            for i in range(self.bar_count):
                bar_h = max(4.0, self._bars[i] * (h - 8))
                x = i * (bar_w + gap)
                y = mid_y - (bar_h / 2.0)
                painter.drawRoundedRect(QRectF(x, y, bar_w, bar_h), bar_w / 2.0, bar_w / 2.0)
else:
    class AudioWaveformWidget:
        def __init__(self, *args, **kwargs):
            pass
        def set_active(self, active: bool):
            pass
        def set_levels(self, levels: List[float]):
            pass
