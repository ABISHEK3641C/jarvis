"""
MYRAA Security Confirmation Dialog
Presents an explicit human-in-the-loop modal before executing Medium and High risk tools.
"""
from typing import Optional

try:
    from PySide6.QtCore import Qt
    from PySide6.QtWidgets import (
        QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QTextEdit, QCheckBox, QFrame
    )
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    class QDialog: pass


if HAVE_QT:
    class SecurityConfirmationDialog(QDialog):
        def __init__(self, request, parent=None):
            super().__init__(parent)
            self.request = request
            self.setWindowTitle("MYRAA Security Authorization")
            self.setMinimumWidth(480)
            self.setModal(True)

            layout = QVBoxLayout(self)
            layout.setSpacing(14)
            layout.setContentsMargins(20, 20, 20, 20)

            # Risk Header
            header_layout = QHBoxLayout()
            title_label = QLabel("Permission Required")
            title_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #f0f6fc;")
            header_layout.addWidget(title_label)
            header_layout.addStretch()

            risk_name = request.risk_level.value
            badge_color = "#f85149" if risk_name == "HIGH" else "#d29922"
            risk_badge = QLabel(f" {risk_name} RISK ")
            risk_badge.setStyleSheet(f"background-color: {badge_color}; color: white; border-radius: 4px; font-weight: bold; padding: 3px 8px;")
            header_layout.addWidget(risk_badge)
            layout.addLayout(header_layout)

            # Reason & Description
            reason_label = QLabel(request.reason)
            reason_label.setStyleSheet("color: #8b949e; font-size: 13px;")
            reason_label.setWordWrap(True)
            layout.addWidget(reason_label)

            # Action Summary box
            box = QFrame()
            box.setStyleSheet("background-color: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 10px;")
            box_layout = QVBoxLayout(box)

            tool_label = QLabel(f"Tool: <b>{request.tool_name}</b>")
            tool_label.setStyleSheet("color: #58a6ff;")
            box_layout.addWidget(tool_label)

            target_label = QLabel(f"Target: {request.target_summary}")
            target_label.setStyleSheet("color: #e6edf3; font-family: monospace;")
            target_label.setWordWrap(True)
            box_layout.addWidget(target_label)

            layout.addWidget(box)

            # Irreversible Warning if High Risk
            if risk_name == "HIGH":
                warn = QLabel("⚠️ Warning: This operation modifies files or system settings and cannot be easily undone.")
                warn.setStyleSheet("color: #f85149; font-weight: bold; font-size: 12px;")
                warn.setWordWrap(True)
                layout.addWidget(warn)

            # Remember for session checkbox
            self.remember_cb = QCheckBox("Remember this approval for the rest of this session")
            self.remember_cb.setStyleSheet("color: #8b949e;")
            layout.addWidget(self.remember_cb)

            # Action Buttons
            btn_layout = QHBoxLayout()
            btn_layout.addStretch()

            self.deny_btn = QPushButton("Deny & Block")
            self.deny_btn.setStyleSheet("background-color: #21262d; color: #f85149; border: 1px solid #30363d; border-radius: 6px; padding: 8px 16px; font-weight: bold;")
            self.deny_btn.clicked.connect(self.reject)
            btn_layout.addWidget(self.deny_btn)

            self.allow_btn = QPushButton("Authorize Action")
            self.allow_btn.setStyleSheet("background-color: #238636; color: white; border: none; border-radius: 6px; padding: 8px 18px; font-weight: bold;")
            self.allow_btn.clicked.connect(self.accept)
            btn_layout.addWidget(self.allow_btn)

            layout.addLayout(btn_layout)

        @property
        def remember_choice(self) -> bool:
            return self.remember_cb.isChecked()
else:
    class SecurityConfirmationDialog:
        def __init__(self, *args, **kwargs): pass
        def exec(self): return 1
