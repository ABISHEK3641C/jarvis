"""
MYRAA Desktop UI Subsystem (PySide6)
Provides modern dark/light themes, 3D animated orb, real-time waveform, and chat views.
"""
from .styles import get_stylesheet
from .orb_widget import AIOrbWidget
from .waveform_widget import AudioWaveformWidget
from .chat_widget import ChatHistoryWidget, ChatBubble
from .confirmation_dialog import SecurityConfirmationDialog
from .settings_dialog import SettingsDialog
from .main_window import MainWindow

__all__ = [
    "get_stylesheet",
    "AIOrbWidget",
    "AudioWaveformWidget",
    "ChatHistoryWidget",
    "ChatBubble",
    "SecurityConfirmationDialog",
    "SettingsDialog",
    "MainWindow",
]
