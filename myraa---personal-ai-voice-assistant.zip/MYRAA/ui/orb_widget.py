"""
MYRAA Animated 3D-Style AI Orb Widget
Renders a glowing 3D spherical orb with particle rings and 4 distinct visual states:
IDLE, LISTENING, THINKING, SPEAKING.
"""
import math
from typing import Optional

try:
    from PySide6.QtCore import Qt, QTimer, QRectF, QPointF
    from PySide6.QtGui import QPainter, QColor, QRadialGradient, QLinearGradient, QPen, QBrush
    from PySide6.QtWidgets import QWidget
    HAVE_QT = True
except ImportError:
    HAVE_QT = False
    # Fallback dummy class if Qt is not installed on testing environment
    class QWidget:
        pass


if HAVE_QT:
    class AIOrbWidget(QWidget):
        def __init__(self, parent=None):
            super().__init__(parent)
            self.setMinimumSize(180, 180)
            self._state = "IDLE"  # IDLE, LISTENING, THINKING, SPEAKING
            self._tick = 0.0
            self._audio_level = 0.2

            # 60 FPS animation timer
            self._timer = QTimer(self)
            self._timer.timeout.connect(self._animate_step)
            self._timer.start(16)

        def set_state(self, state: str):
            self._state = state.upper()
            self.update()

        def set_audio_level(self, level: float):
            self._audio_level = max(0.0, min(1.0, level))

        def _animate_step(self):
            self._tick += 0.04
            if self._tick > 1000.0:
                self._tick = 0.0
            self.update()

        def paintEvent(self, event):
            painter = QPainter(self)
            painter.setRenderHint(QPainter.Antialiasing)

            w = self.width()
            h = self.height()
            center_x = w / 2.0
            center_y = h / 2.0
            base_radius = min(w, h) * 0.28

            # Calculate dynamic pulse according to state
            if self._state == "LISTENING":
                pulse = math.sin(self._tick * 4) * 8.0 + (self._audio_level * 15.0)
                core_c1 = QColor(0, 210, 255, 230)
                core_c2 = QColor(0, 110, 255, 180)
                glow_color = QColor(0, 220, 255, 60)
            elif self._state == "THINKING":
                pulse = math.sin(self._tick * 6) * 4.0
                core_c1 = QColor(180, 80, 255, 240)
                core_c2 = QColor(90, 40, 220, 190)
                glow_color = QColor(160, 50, 255, 60)
            elif self._state == "SPEAKING":
                pulse = math.sin(self._tick * 5) * 6.0 + (self._audio_level * 22.0)
                core_c1 = QColor(255, 140, 0, 230)
                core_c2 = QColor(0, 200, 255, 180)
                glow_color = QColor(255, 170, 50, 60)
            else:  # IDLE
                pulse = math.sin(self._tick * 1.5) * 4.0
                core_c1 = QColor(56, 139, 253, 210)
                core_c2 = QColor(31, 111, 235, 160)
                glow_color = QColor(56, 139, 253, 40)

            radius = base_radius + pulse

            # 1. Outer Diffuse Glow Ring
            outer_grad = QRadialGradient(center_x, center_y, radius * 1.7)
            outer_grad.setColorAt(0.0, glow_color)
            outer_grad.setColorAt(0.6, QColor(glow_color.red(), glow_color.green(), glow_color.blue(), 20))
            outer_grad.setColorAt(1.0, QColor(0, 0, 0, 0))
            painter.setBrush(QBrush(outer_grad))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(QPointF(center_x, center_y), radius * 1.7, radius * 1.7)

            # 2. Revolving Orbit Rings
            painter.setPen(QPen(QColor(core_c1.red(), core_c1.green(), core_c1.blue(), 110), 1.5))
            orbit_a = radius * 1.25
            orbit_b = radius * 0.75
            painter.save()
            painter.translate(center_x, center_y)
            painter.rotate(math.degrees(self._tick * 0.8))
            painter.drawEllipse(QRectF(-orbit_a, -orbit_b, orbit_a * 2, orbit_b * 2))
            painter.restore()

            # 3. Main 3D Spherical Orb with Highlight
            sphere_grad = QRadialGradient(
                center_x - radius * 0.35,
                center_y - radius * 0.35,
                radius * 1.2
            )
            sphere_grad.setColorAt(0.0, QColor(255, 255, 255, 240))
            sphere_grad.setColorAt(0.25, core_c1)
            sphere_grad.setColorAt(0.85, core_c2)
            sphere_grad.setColorAt(1.0, QColor(10, 15, 30, 220))

            painter.setBrush(QBrush(sphere_grad))
            painter.setPen(Qt.NoPen)
            painter.drawEllipse(QPointF(center_x, center_y), radius, radius)

            # 4. State Label overlay
            painter.setPen(QColor(240, 246, 252, 180))
            font = painter.font()
            font.setPointSize(9)
            font.setBold(True)
            painter.setFont(font)
            painter.drawText(
                QRectF(0, h - 25, w, 20),
                Qt.AlignCenter,
                self._state
            )
else:
    class AIOrbWidget:
        def __init__(self, *args, **kwargs):
            pass
        def set_state(self, state: str):
            pass
        def set_audio_level(self, level: float):
            pass
