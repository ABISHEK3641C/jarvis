"""
MYRAA Text-to-Speech Engine
Features selectable voices, speech speed rate, Windows SAPI5 / pyttsx3 backend, and instant interruption.
"""
import threading
from typing import List, Optional
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.Voice.TTS")


class TextToSpeechEngine:
    def __init__(self):
        self.config = get_config()
        self._engine = None
        self._is_speaking = False
        self._stop_requested = False
        self._lock = threading.Lock()
        self._init_engine()

    def _init_engine(self):
        try:
            import pyttsx3
            self._engine = pyttsx3.init()
            self._engine.setProperty("rate", self.config.tts_rate)
            self._engine.setProperty("volume", self.config.tts_volume)
        except Exception as e:
            logger.warning(f"pyttsx3 initialization note: {e}")
            self._engine = None

    def get_available_voices(self) -> List[dict]:
        voices_list = []
        if self._engine:
            try:
                for v in self._engine.getProperty("voices"):
                    voices_list.append({
                        "id": v.id,
                        "name": v.name,
                        "languages": getattr(v, "languages", []),
                        "gender": getattr(v, "gender", "unknown")
                    })
            except Exception:
                pass
        if not voices_list:
            voices_list.append({"id": "default", "name": "Default Windows Voice", "languages": ["en-US"], "gender": "female"})
        return voices_list

    def speak(self, text: str, on_complete: Optional[callable] = None):
        """Asynchronously speaks text without freezing the PySide6 UI thread."""
        def run_speech():
            with self._lock:
                self._is_speaking = True
                self._stop_requested = False

            try:
                if self._engine:
                    self._engine.setProperty("rate", self.config.tts_rate)
                    self._engine.say(text)
                    self._engine.runAndWait()
            except Exception as e:
                logger.error(f"TTS playback error: {e}")
            finally:
                with self._lock:
                    self._is_speaking = False
                if on_complete:
                    on_complete()

        t = threading.Thread(target=run_speech, daemon=True)
        t.start()

    def stop(self):
        """Interrupts current voice speech immediately."""
        self._stop_requested = True
        if self._engine and self._is_speaking:
            try:
                self._engine.stop()
            except Exception:
                pass
        self._is_speaking = False

    @property
    def is_speaking(self) -> bool:
        return self._is_speaking


tts_engine = TextToSpeechEngine()
