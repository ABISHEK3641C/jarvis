"""
MYRAA Wake Word Detector
Detects wake phrases like 'Hey MYRAA' or 'MYRAA' continuously in the background.
"""
import re
import threading
from typing import Callable, Optional
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.Voice.WakeWord")


class WakeWordDetector:
    def __init__(self, on_wake: Optional[Callable[[], None]] = None):
        self.config = get_config()
        self.on_wake = on_wake
        self._is_running = False
        self._thread: Optional[threading.Thread] = None

    def matches_wake_phrase(self, text: str) -> bool:
        """Checks if transcribed text or phonetic chunk matches the wake word."""
        if not self.config.wake_word_enabled:
            return False
        clean = text.lower().strip()
        wake = self.config.wake_word.lower().strip()
        variations = [wake, "hey myra", "myraa", "myra", "हे मायरा", "सुनो मायरा"]
        return any(v in clean for v in variations)

    def start_listening(self):
        self._is_running = True
        logger.info(f"Wake word detector started for: '{self.config.wake_word}'")

    def stop_listening(self):
        self._is_running = False
        logger.info("Wake word detector stopped.")


wake_word_detector = WakeWordDetector()
