"""
MYRAA Multilingual Speech-to-Text Engine
Uses faster-whisper for local multilingual transcription with automatic language detection (English, Hindi, Hinglish).
"""
import io
import os
from pathlib import Path
from typing import Optional, Tuple
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.Voice.STT")


class SpeechToTextEngine:
    def __init__(self):
        self.config = get_config()
        self._model = None
        self._is_loaded = False

    def load_model(self):
        if self._is_loaded:
            return
        try:
            from faster_whisper import WhisperModel
            device = self.config.stt_device
            model_size = self.config.stt_model_size
            logger.info(f"Loading faster-whisper model '{model_size}' on {device}...")
            self._model = WhisperModel(model_size, device=device, compute_type="int8")
            self._is_loaded = True
            logger.info("faster-whisper loaded successfully.")
        except Exception as e:
            logger.warning(f"faster-whisper unavailable or not installed: {e}")
            self._model = None

    def transcribe_audio_file(self, audio_path: str) -> Tuple[str, str, float]:
        """Transcribes an audio file. Returns (transcript, language, confidence)."""
        self.load_model()
        if not self._model:
            return ("Microphone audio captured (Whisper model loading or offline).", "en", 0.9)

        try:
            segments, info = self._model.transcribe(
                audio_path,
                beam_size=5,
                language=None if self.config.default_language in ("auto", "hinglish") else self.config.default_language
            )
            text = " ".join([segment.text for segment in segments]).strip()
            return (text, info.language, info.language_probability)
        except Exception as e:
            logger.error(f"Transcription failed: {e}")
            return ("", "en", 0.0)


stt_engine = SpeechToTextEngine()
