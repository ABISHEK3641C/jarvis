"""
MYRAA Audio Stream Manager
Coordinates audio capture, waveform calculations, playback, and voice interrupts.
"""
from enum import Enum
import math
import threading
from typing import Callable, List, Optional


class AudioState(Enum):
    IDLE = "IDLE"
    LISTENING = "LISTENING"
    THINKING = "THINKING"
    SPEAKING = "SPEAKING"


class AudioManager:
    def __init__(self):
        self._state = AudioState.IDLE
        self._listeners: List[Callable[[AudioState], None]] = []
        self._waveform_listeners: List[Callable[[List[float]], None]] = []
        self._lock = threading.Lock()

    @property
    def state(self) -> AudioState:
        return self._state

    def set_state(self, new_state: AudioState):
        with self._lock:
            self._state = new_state
        for cb in self._listeners:
            try:
                cb(new_state)
            except Exception:
                pass

    def add_state_listener(self, cb: Callable[[AudioState], None]):
        self._listeners.append(cb)

    def add_waveform_listener(self, cb: Callable[[List[float]], None]):
        self._waveform_listeners.append(cb)

    def emit_waveform(self, levels: List[float]):
        for cb in self._waveform_listeners:
            try:
                cb(levels)
            except Exception:
                pass


audio_manager = AudioManager()
