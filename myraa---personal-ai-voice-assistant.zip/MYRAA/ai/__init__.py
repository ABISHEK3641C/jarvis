"""
MYRAA AI Subsystem
Provides model abstraction, hybrid cloud/local inference, and offline command routing.
"""
from .provider import BaseAIProvider, AIResponse
from .cloud_provider import GeminiProvider
from .local_provider import LocalLLMProvider
from .offline_rule_engine import OfflineRuleEngine
from .router import AIRouter, ai_router

__all__ = [
    "BaseAIProvider",
    "AIResponse",
    "GeminiProvider",
    "LocalLLMProvider",
    "OfflineRuleEngine",
    "AIRouter",
    "ai_router",
]
