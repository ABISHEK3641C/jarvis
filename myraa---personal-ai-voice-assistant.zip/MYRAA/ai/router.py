"""
MYRAA AI Router
Manages intelligent routing between Cloud AI, Local LLM, and the Offline Rule Engine.
"""
from typing import Any, Dict, Generator, List, Optional
import urllib.request
from .provider import BaseAIProvider, AIResponse
from .cloud_provider import GeminiProvider
from .local_provider import LocalLLMProvider
from .offline_rule_engine import OfflineRuleEngine
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.AI.Router")


class AIRouter:
    def __init__(self):
        self.config = get_config()
        self.cloud_provider = GeminiProvider()
        self.local_provider = LocalLLMProvider()

    def is_online(self) -> bool:
        """Checks internet connectivity with low latency."""
        try:
            urllib.request.urlopen("https://www.google.com", timeout=2)
            return True
        except Exception:
            return False

    def route_query(
        self,
        user_text: str,
        history: Optional[List[Dict[str, str]]] = None,
        force_offline: bool = False
    ) -> AIResponse:
        messages = list(history or [])
        messages.append({"role": "user", "content": user_text})

        # 1. Offline Check / Force Offline
        online = self.is_online() if not force_offline else False

        # If offline or explicit local command: try offline rule engine
        if not online or force_offline:
            offline_result = OfflineRuleEngine.process_command(user_text)
            if offline_result:
                resp_text, metadata = offline_result
                return AIResponse(text=resp_text, model_name="OfflineRuleEngine")
            elif not online:
                return AIResponse(
                    text="You are currently offline. Basic commands like 'what time is it', 'open calculator', "
                         "'system info', 'volume 50', and 'save note' are available offline.",
                    model_name="OfflineRuleEngine"
                )

        # 2. Check Provider Mode
        mode = self.config.ai_provider.lower()

        if mode == "local":
            return self.local_provider.generate(messages)

        # Cloud Mode (Gemini) with automatic local/offline fallback
        try:
            res = self.cloud_provider.generate(messages)
            if res.text and "network error" not in res.text.lower():
                return res
        except Exception as e:
            logger.warning(f"Cloud provider failure: {e}. Falling back to local.")

        # Try Local Provider as fallback
        try:
            local_res = self.local_provider.generate(messages)
            if local_res.text and "Could not connect" not in local_res.text:
                return local_res
        except Exception:
            pass

        # Fallback to offline rule engine
        offline_result = OfflineRuleEngine.process_command(user_text)
        if offline_result:
            return AIResponse(text=offline_result[0], model_name="OfflineRuleEngine")

        return AIResponse(
            text="I'm having trouble connecting to the cloud AI service. Please verify your GEMINI_API_KEY in settings or start a local Ollama server.",
            model_name="fallback"
        )


ai_router = AIRouter()
