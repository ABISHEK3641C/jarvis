"""
MYRAA Local AI Provider
Connects to local inference servers such as Ollama, vLLM, or LM Studio via OpenAI-compatible endpoints.
"""
from typing import Any, Dict, Generator, List, Optional
from .provider import BaseAIProvider, AIResponse
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.AI.Local")


class LocalLLMProvider(BaseAIProvider):
    def __init__(self, endpoint_url: Optional[str] = None, model_name: Optional[str] = None):
        config = get_config()
        self.endpoint_url = endpoint_url or config.local_llm_url
        self.model_name = model_name or config.local_llm_model

    def generate(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> AIResponse:
        import requests
        config = get_config()
        url = f"{self.endpoint_url.rstrip('/')}/chat/completions"

        full_msgs = []
        if system_prompt or config.system_prompt:
            full_msgs.append({"role": "system", "content": system_prompt or config.system_prompt})
        full_msgs.extend(messages)

        payload = {
            "model": self.model_name,
            "messages": full_msgs,
            "temperature": config.temperature,
            "max_tokens": config.max_tokens
        }

        try:
            resp = requests.post(url, json=payload, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                choice = data.get("choices", [{}])[0]
                content = choice.get("message", {}).get("content", "")
                return AIResponse(text=content, model_name=self.model_name)
            else:
                return AIResponse(
                    text=f"Local LLM Error ({resp.status_code}): Ensure Ollama or local server is running on {self.endpoint_url}.",
                    model_name=self.model_name
                )
        except Exception as e:
            return AIResponse(
                text=f"Could not connect to local LLM server ({self.endpoint_url}). Is it started?",
                model_name=self.model_name
            )

    def generate_stream(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> Generator[str, None, None]:
        res = self.generate(messages, tools, system_prompt)
        for chunk in res.text.split(" "):
            yield chunk + " "
