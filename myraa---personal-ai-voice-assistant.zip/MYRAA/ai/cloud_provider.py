"""
MYRAA Cloud AI Provider (Gemini 3.8 Flash)
Connects to Google GenAI for multilingual reasoning, tool calling, and screen understanding.
"""
import json
import os
from typing import Any, Dict, Generator, List, Optional
from .provider import BaseAIProvider, AIResponse
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.AI.Cloud")


class GeminiProvider(BaseAIProvider):
    def __init__(self, api_key: Optional[str] = None, model_name: Optional[str] = None):
        config = get_config()
        self.api_key = api_key or config.gemini_api_key or os.getenv("GEMINI_API_KEY", "")
        self.model_name = model_name or config.cloud_model or "gemini-3.8-flash"
        self._client = None
        self._init_client()

    def _init_client(self):
        if not self.api_key:
            return
        try:
            from google import genai
            self._client = genai.Client(api_key=self.api_key)
        except ImportError:
            self._client = None

    def generate(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> AIResponse:
        if not self.api_key:
            return AIResponse(
                text="Gemini API Key is not configured. Please set GEMINI_API_KEY in Settings or your .env file.",
                model_name=self.model_name
            )

        config = get_config()
        sys_instruction = system_prompt or config.system_prompt

        # Attempt with google.genai Client
        if self._client:
            try:
                contents = []
                for m in messages:
                    contents.append(f"{m.get('role', 'user')}: {m.get('content', '')}")
                full_prompt = "\n".join(contents)

                response = self._client.models.generate_content(
                    model=self.model_name,
                    contents=full_prompt,
                    config={
                        "system_instruction": sys_instruction,
                        "temperature": config.temperature,
                    }
                )
                text = getattr(response, "text", "") or ""
                return AIResponse(text=text, model_name=self.model_name)
            except Exception as e:
                logger.error(f"Gemini SDK error: {e}")

        # Fallback to direct HTTPS request via requests
        try:
            import requests
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{self.model_name}:generateContent?key={self.api_key}"
            contents = []
            for m in messages:
                role = "model" if m.get("role") in ("assistant", "model") else "user"
                contents.append({"role": role, "parts": [{"text": m.get("content", "")}]})

            payload = {
                "contents": contents,
                "systemInstruction": {"parts": [{"text": sys_instruction}]},
                "generationConfig": {"temperature": config.temperature, "maxOutputTokens": config.max_tokens}
            }

            resp = requests.post(url, json=payload, timeout=25)
            if resp.status_code == 200:
                data = resp.json()
                cand = data.get("candidates", [{}])[0]
                text = cand.get("content", {}).get("parts", [{}])[0].get("text", "")
                return AIResponse(text=text, model_name=self.model_name)
            else:
                return AIResponse(text=f"AI Request Error ({resp.status_code}): {resp.text[:200]}", model_name=self.model_name)
        except Exception as ex:
            return AIResponse(text=f"Network error communicating with AI service: {str(ex)}", model_name=self.model_name)

    def generate_stream(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> Generator[str, None, None]:
        # Unary fallback generator
        res = self.generate(messages, tools, system_prompt)
        words = res.text.split(" ")
        for w in words:
            yield w + " "
