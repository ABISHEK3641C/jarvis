"""
MYRAA Offline Rule Engine
Provides zero-network offline command understanding for English, Hindi, and Hinglish.
"""
import datetime
import re
from typing import Any, Dict, Optional, Tuple
from ..tools.registry import tool_registry


class OfflineRuleEngine:
    """Deterministic offline parser for local commands when network/cloud AI is disconnected."""

    @classmethod
    def process_command(cls, text: str) -> Optional[Tuple[str, Dict[str, Any]]]:
        t = text.lower().strip()

        # 1. Date & Time queries (English, Hindi, Hinglish)
        if any(p in t for p in ["time", "samay", "kitne baje", "kya time hai", "current time"]):
            now_str = datetime.datetime.now().strftime("%I:%M %p")
            return f"The current time is {now_str} (अभी {now_str} हुआ है).", {}

        if any(p in t for p in ["date", "tarikh", "aaj kaun sa din", "today's date", "kaunsi date"]):
            date_str = datetime.datetime.now().strftime("%A, %B %d, %Y")
            return f"Today is {date_str} (आज की तारीख {date_str} है).", {}

        # 2. System Info / Battery / CPU / Status
        if any(p in t for p in ["system info", "system status", "status", "cpu", "ram", "battery", "storage", "disk", "hardware"]):
            res = tool_registry.execute_tool("get_system_info", {})
            if res.get("success"):
                d = res["data"]
                return (
                    f"System Status: CPU: {d.get('cpu_percent', 'N/A')}%, RAM: {d.get('ram_percent', 'N/A')}%, "
                    f"Free Disk: {d.get('disk_free_gb', 'N/A')} GB, OS: {d.get('os', 'Windows')}.",
                    {"tool": "get_system_info", "result": d}
                )

        # 3. App Launching (English: "open calculator", Hindi: "calculator kholo")
        open_match = re.search(r"\b(open|launch|start)\s+([a-zA-Z0-9_\s]+)", t)
        if not open_match:
            # Hindi word order: "<app_name> kholo / chalu karo"
            open_match_hi = re.search(r"([a-zA-Z0-9_]+)\s*(?:ko)?\s*(kholo|chalu karo)", t)
            if open_match_hi:
                app_candidate = open_match_hi.group(1).strip()
            else:
                app_candidate = ""
        else:
            app_candidate = open_match.group(2).replace("kholo", "").replace("ko", "").strip()

        if app_candidate:
            # check if in tool registry
            res = tool_registry.execute_tool("launch_approved_app", {"app_name": app_candidate})
            if res.get("success"):
                return f"Opening {app_candidate} for you.", {"tool": "launch_approved_app", "app": app_candidate}
            elif "not in the approved" in str(res.get("error", "")):
                return f"Sorry, '{app_candidate}' is not in your approved applications allowlist.", {}

        # 4. Volume controls ("volume 50 karo", "mute sound", "increase volume")
        if "mute" in t:
            tool_registry.execute_tool("adjust_volume", {"mute": True})
            return "System audio muted (आवाज़ बंद कर दी गई है).", {"tool": "adjust_volume"}

        vol_match = re.search(r"volume\s*(?:to|pe|set to)?\s*(\d{1,3})", t)
        if vol_match:
            vol_val = int(vol_match.group(1))
            tool_registry.execute_tool("adjust_volume", {"volume_level": vol_val})
            return f"Volume adjusted to {vol_val}% (वॉल्यूम {vol_val}% कर दिया गया है).", {"tool": "adjust_volume"}

        # 5. Notes creation ("take a note", "note likho")
        note_match = re.search(r"(?:take a note|note likho|save note|write note)\s*(?:that|ki|:)?\s*(.+)", t)
        if note_match:
            body = note_match.group(1).strip()
            res = tool_registry.execute_tool("create_note", {"title": f"Note {datetime.date.today()}", "body": body})
            if res.get("success"):
                return f"Note saved successfully: '{body}' (नोट सेव हो गया).", {"tool": "create_note"}

        # Fallback offline guidance
        return None
