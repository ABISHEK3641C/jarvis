"""
MYRAA AI Provider Abstraction
Common interface for Cloud (Gemini), Local (Ollama/vLLM), and Offline providers.
"""
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Generator, List, Optional


@dataclass
class AIResponse:
    text: str
    tool_calls: Optional[List[Dict[str, Any]]] = None
    finish_reason: str = "stop"
    usage_tokens: Optional[int] = None
    model_name: str = ""


class BaseAIProvider(ABC):
    @abstractmethod
    def generate(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> AIResponse:
        """Generates a synchronous response."""
        pass

    @abstractmethod
    def generate_stream(
        self,
        messages: List[Dict[str, str]],
        tools: Optional[List[Dict[str, Any]]] = None,
        system_prompt: Optional[str] = None
    ) -> Generator[str, None, None]:
        """Streams text chunks."""
        pass
