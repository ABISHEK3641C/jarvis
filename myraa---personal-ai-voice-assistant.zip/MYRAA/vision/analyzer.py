"""
MYRAA Screen Vision Analyzer
Combines screenshot capture, OCR, and AI reasoning to explain visible UI issues.
"""
from typing import Any, Dict
from .screen_capture import screen_capture_service
from .ocr import ocr_engine
from ..ai.router import ai_router


class VisionAnalyzer:
    def analyze_current_screen(self, query: str = "Explain any errors or visible interface elements") -> Dict[str, Any]:
        # 1. Take authorized screenshot
        cap = screen_capture_service.capture_screen()
        if not cap.get("success"):
            return cap

        filepath = cap["file_path"]

        # 2. Extract OCR text
        ocr_res = ocr_engine.extract_text(filepath)
        extracted_text = ocr_res.get("text", "") if ocr_res.get("success") else ""

        # 3. Analyze with AI Router
        prompt = (
            f"User query about screen: '{query}'.\n"
            f"Extracted visible text from screen:\n{extracted_text}\n"
            "Analyze what is displayed, point out error messages if any, and suggest helpful next steps."
        )
        ai_resp = ai_router.route_query(prompt)

        return {
            "success": True,
            "screenshot_path": filepath,
            "ocr_text_preview": extracted_text[:400],
            "analysis": ai_resp.text,
            "model_used": ai_resp.model_name
        }


vision_analyzer = VisionAnalyzer()
