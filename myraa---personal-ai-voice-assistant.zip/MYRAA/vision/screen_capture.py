"""
MYRAA Screen Capture Service
Explicit user-authorized screen grabbing with privacy safeguards.
"""
import datetime
from pathlib import Path
from typing import Any, Dict
from ..core.config import get_config
from ..core.logger import get_logger

logger = get_logger("MYRAA.Vision.Capture")


class ScreenCaptureService:
    def __init__(self):
        self.config = get_config()
        self.screenshots_dir = self.config.data_dir / "screenshots"
        self.screenshots_dir.mkdir(parents=True, exist_ok=True)

    def capture_screen(self) -> Dict[str, Any]:
        """Captures the primary monitor image safely if permitted."""
        if not self.config.allow_screen_capture:
            return {
                "success": False,
                "error": "Screen capture is disabled in MYRAA Privacy Settings."
            }

        filename = f"capture_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        filepath = self.screenshots_dir / filename

        try:
            from PIL import ImageGrab
            screenshot = ImageGrab.grab()
            screenshot.save(filepath, format="PNG")
            return {
                "success": True,
                "file_path": str(filepath),
                "width": screenshot.width,
                "height": screenshot.height,
                "timestamp": datetime.datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Screen grab failed: {e}")
            return {
                "success": False,
                "error": f"Failed to capture screen: {str(e)}"
            }


screen_capture_service = ScreenCaptureService()
