"""
MYRAA OCR Engine
Extracts visible text and error logs from screenshots using pytesseract.
"""
from pathlib import Path
from typing import Dict, Any
from ..core.logger import get_logger

logger = get_logger("MYRAA.Vision.OCR")


class OCREngine:
    def extract_text(self, image_path: str) -> Dict[str, Any]:
        p = Path(image_path)
        if not p.exists():
            return {"success": False, "error": f"Image '{image_path}' not found."}

        try:
            from PIL import Image
            import pytesseract
            img = Image.open(str(p))
            text = pytesseract.image_to_string(img)
            return {
                "success": True,
                "text": text.strip(),
                "character_count": len(text)
            }
        except ImportError:
            return {
                "success": False,
                "error": "pytesseract or PIL is not installed. Text OCR requires Tesseract OCR engine."
            }
        except Exception as e:
            return {"success": False, "error": f"OCR processing error: {str(e)}"}


ocr_engine = OCREngine()
