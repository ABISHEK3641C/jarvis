"""
MYRAA Security Allowlist Validator
Ensures tool execution is strictly confined to approved apps, URLs, and directory trees.
"""
import os
from pathlib import Path
from typing import List
from urllib.parse import urlparse
from ..core.config import get_config


class SecurityAllowlist:
    """Verifies paths, applications, and URLs against strict allowlists."""

    @classmethod
    def is_app_allowed(cls, app_identifier: str) -> bool:
        config = get_config()
        clean = app_identifier.lower().strip()
        return clean in config.approved_apps or any(
            clean == val.lower().strip() for val in config.approved_apps.values()
        )

    @classmethod
    def get_app_command(cls, app_identifier: str) -> str:
        config = get_config()
        clean = app_identifier.lower().strip()
        if clean in config.approved_apps:
            return config.approved_apps[clean]
        for key, val in config.approved_apps.items():
            if clean == val.lower().strip():
                return val
        return ""

    @classmethod
    def is_url_allowed(cls, url: str) -> bool:
        config = get_config()
        try:
            parsed = urlparse(url)
            if parsed.scheme not in ("http", "https"):
                return False
            domain = parsed.netloc.lower()
            # Compare with approved URLs
            for approved in config.approved_urls:
                approved_domain = urlparse(approved).netloc.lower()
                if domain == approved_domain or domain.endswith("." + approved_domain):
                    return True
        except Exception:
            return False
        return False

    @classmethod
    def is_path_in_approved_directories(cls, target_path: str) -> bool:
        config = get_config()
        try:
            resolved_target = Path(target_path).expanduser().resolve()
            for approved_dir in config.approved_directories:
                resolved_approved = Path(approved_dir).expanduser().resolve()
                if resolved_approved in resolved_target.parents or resolved_target == resolved_approved:
                    return True
        except Exception:
            return False
        return False
