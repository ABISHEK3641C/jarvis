"""
MYRAA Security Audit Logger
Maintains tamper-evident structured logs of all tool executions and confirmation events.
"""
from dataclasses import dataclass, field
import datetime
import json
from pathlib import Path
from typing import Any, Dict, List, Optional
from .classifier import ActionRisk


@dataclass
class AuditEntry:
    timestamp: str
    tool_name: str
    risk_level: str
    decision: str  # APPROVED, REJECTED, AUTO_DENIED, EXECUTED_SUCCESS, EXECUTED_FAILURE
    parameters_summary: str
    details: Optional[str] = None


class AuditLogger:
    """Logs security audit entries to disk in JSON-lines format."""

    def __init__(self, log_dir: Optional[Path] = None):
        self.log_dir = log_dir or (Path.home() / ".myraa" / "audit")
        try:
            self.log_dir.mkdir(parents=True, exist_ok=True)
            self.log_file = self.log_dir / "audit.jsonl"
        except Exception:
            self.log_file = None

    def log(self, tool_name: str, risk_level: ActionRisk, decision: str, parameters: Dict[str, Any], details: Optional[str] = None):
        # Scrub potentially sensitive keys in parameters
        sanitized = {}
        for k, v in parameters.items():
            if any(term in k.lower() for term in ["pass", "token", "secret", "auth", "key"]):
                sanitized[k] = "[MASKED]"
            else:
                sanitized[k] = str(v)[:200]

        entry = AuditEntry(
            timestamp=datetime.datetime.now().isoformat(),
            tool_name=tool_name,
            risk_level=risk_level.value,
            decision=decision,
            parameters_summary=json.dumps(sanitized),
            details=details
        )

        if self.log_file:
            try:
                with open(self.log_file, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry.__dict__) + "\n")
            except Exception:
                pass

    def get_recent_entries(self, limit: int = 50) -> List[Dict[str, Any]]:
        entries = []
        if self.log_file and self.log_file.exists():
            try:
                with open(self.log_file, "r", encoding="utf-8") as f:
                    lines = f.readlines()
                    for line in reversed(lines[-limit:]):
                        if line.strip():
                            entries.append(json.loads(line))
            except Exception:
                pass
        return entries


audit_logger = AuditLogger()
