"""
MYRAA Confirmation Subsystem
Enforces human-in-the-loop confirmation for Medium and High risk operations.
"""
from dataclasses import dataclass, field
import datetime
import threading
from typing import Any, Callable, Dict, Optional
from .classifier import ActionRisk


@dataclass
class ConfirmationRequest:
    request_id: str
    tool_name: str
    parameters: Dict[str, Any]
    risk_level: ActionRisk
    reason: str
    target_summary: str
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    status: str = "PENDING"  # PENDING, APPROVED, REJECTED, AUTO_DENIED


class ConfirmationManager:
    """Coordinates confirmation prompts between backend and GUI/CLI."""

    def __init__(self):
        self._pending_requests: Dict[str, ConfirmationRequest] = {}
        self._session_whitelists: set = set()
        self._prompt_callback: Optional[Callable[[ConfirmationRequest], bool]] = None
        self._lock = threading.Lock()

    def set_ui_callback(self, callback: Callable[[ConfirmationRequest], bool]):
        """Sets the UI callback that renders the confirmation modal."""
        self._prompt_callback = callback

    def request_approval(self, request: ConfirmationRequest) -> bool:
        """Evaluates whether to allow, reject, or prompt user for confirmation."""
        if request.risk_level == ActionRisk.BLOCKED:
            request.status = "AUTO_DENIED"
            return False

        if request.risk_level == ActionRisk.LOW:
            request.status = "APPROVED"
            return True

        # Check session whitelist
        session_key = f"{request.tool_name}:{str(sorted(request.parameters.items()))}"
        if session_key in self._session_whitelists:
            request.status = "APPROVED"
            return True

        with self._lock:
            self._pending_requests[request.request_id] = request

        # Invoke UI callback if registered
        if self._prompt_callback:
            approved = self._prompt_callback(request)
            request.status = "APPROVED" if approved else "REJECTED"
            return approved

        # Default fallback if no UI dialog attached: safe denial for high risk
        request.status = "REJECTED"
        return False

    def whitelist_for_session(self, tool_name: str, parameters: Dict[str, Any]):
        session_key = f"{tool_name}:{str(sorted(parameters.items()))}"
        self._session_whitelists.add(session_key)

    def clear_session_whitelists(self):
        self._session_whitelists.clear()


confirmation_manager = ConfirmationManager()
