"""
MYRAA Risk Classifier
Classifies intended actions into LOW, MEDIUM, HIGH, and BLOCKED tiers.
"""
from enum import Enum
import re
from typing import Any, Dict, Tuple


class ActionRisk(Enum):
    LOW = "LOW"
    MEDIUM = "MEDIUM"
    HIGH = "HIGH"
    BLOCKED = "BLOCKED"


class RiskClassifier:
    """Independent security classifier for tools and natural language commands."""

    BLOCKED_PATTERNS = [
        re.compile(r"\b(dump\s+sam|mimikatz|lsass|procdump|hashdump)\b", re.IGNORECASE),
        re.compile(r"(format\s+[a-zA-Z]:|diskpart|vssadmin\s+delete\s+shadows)", re.IGNORECASE),
        re.compile(r"\b(reg\s+delete|reg\s+add\s+.*run|disable\s+defender)\b", re.IGNORECASE),
        re.compile(r"(steal|grab|dump|extract)\s+.*(password|token|credential|hash)", re.IGNORECASE),
        re.compile(r"\b(browser\s+passwords?|saved\s+passwords?)\b", re.IGNORECASE),
        re.compile(r"(rmdir\s+/s\s+/q\s+[a-zA-Z]:|rm\s+-rf\s+/|del\s+/f\s+/s\s+/q\s+[a-zA-Z]:)", re.IGNORECASE),
        re.compile(r"\b(keylogger|covert\s+recording|spyware)\b", re.IGNORECASE),
    ]

    HIGH_RISK_TOOLS = {
        "delete_file",
        "overwrite_file",
        "system_shutdown",
        "system_restart",
        "install_software",
        "send_email",
        "modify_system_registry"
    }

    MEDIUM_RISK_TOOLS = {
        "read_document",
        "create_file",
        "write_note",
        "adjust_volume",
        "adjust_brightness",
        "set_clipboard",
        "capture_screen",
        "run_approved_workflow"
    }

    LOW_RISK_TOOLS = {
        "launch_approved_app",
        "open_approved_url",
        "search_files",
        "get_system_info",
        "get_datetime",
        "get_weather",
        "read_reminders",
        "read_notes"
    }

    @classmethod
    def classify_text_intent(cls, command_text: str) -> Tuple[ActionRisk, str]:
        """Examines raw text for dangerous patterns before passing to model or tools."""
        for pattern in cls.BLOCKED_PATTERNS:
            if pattern.search(command_text):
                return ActionRisk.BLOCKED, "Command matches blocked dangerous or malicious pattern."

        lower = command_text.lower()
        if any(w in lower for w in ["delete file", "erase file", "shutdown pc", "restart computer", "send email"]):
            return ActionRisk.HIGH, "Intent involves high-impact or irreversible operation."

        if any(w in lower for w in ["take screenshot", "capture screen", "create note", "write file", "change volume"]):
            return ActionRisk.MEDIUM, "Intent modifies state or accesses local files/media."

        return ActionRisk.LOW, "Intent is a standard query or read-only action."

    @classmethod
    def classify_tool_call(cls, tool_name: str, params: Dict[str, Any]) -> Tuple[ActionRisk, str]:
        """Classifies a specific tool call and its parameters."""
        # Check tool parameter values for blocked patterns
        for key, val in params.items():
            if isinstance(val, str):
                for pattern in cls.BLOCKED_PATTERNS:
                    if pattern.search(val):
                        return ActionRisk.BLOCKED, f"Parameter '{key}' contains prohibited payload."

        if tool_name in cls.HIGH_RISK_TOOLS:
            return ActionRisk.HIGH, f"Tool '{tool_name}' performs destructive, communication, or lifecycle actions."

        if tool_name in cls.MEDIUM_RISK_TOOLS:
            return ActionRisk.MEDIUM, f"Tool '{tool_name}' reads local data, modifies files, or alters system settings."

        if tool_name in cls.LOW_RISK_TOOLS:
            return ActionRisk.LOW, f"Tool '{tool_name}' is read-only or launches an allowlisted application."

        # Default fallback for unknown tools: treat as HIGH risk
        return ActionRisk.HIGH, f"Unknown tool '{tool_name}' treated with caution."
