"""
Tests for MYRAA AI Router and Offline Rule Engine
Validates offline command interpretation in English, Hindi, and Hinglish.
"""
import unittest
from MYRAA.ai.offline_rule_engine import OfflineRuleEngine
from MYRAA.ai.router import AIRouter
from MYRAA.security.confirmation import confirmation_manager


class TestAIRouter(unittest.TestCase):
    def setUp(self):
        confirmation_manager.set_ui_callback(lambda r: True)
        self.router = AIRouter()

    def test_offline_time_query_english(self):
        res = OfflineRuleEngine.process_command("What time is it right now?")
        self.assertIsNotNone(res)
        self.assertIn("The current time is", res[0])

    def test_offline_time_query_hindi(self):
        res = OfflineRuleEngine.process_command("kitne baje hain?")
        self.assertIsNotNone(res)
        self.assertIn("The current time is", res[0])

    def test_offline_date_query_hinglish(self):
        res = OfflineRuleEngine.process_command("aaj kaun sa din hai date batao")
        self.assertIsNotNone(res)
        self.assertIn("Today is", res[0])

    def test_offline_system_metrics(self):
        res = OfflineRuleEngine.process_command("system status dikhao")
        self.assertIsNotNone(res)
        self.assertIn("System Status", res[0])

    def test_offline_app_launch(self):
        res = OfflineRuleEngine.process_command("calculator kholo")
        self.assertIsNotNone(res)
        self.assertIn("Opening calculator", res[0])

    def test_forced_offline_mode_routing(self):
        resp = self.router.route_query("what time is it", force_offline=True)
        self.assertEqual(resp.model_name, "OfflineRuleEngine")
        self.assertIn("The current time is", resp.text)


if __name__ == "__main__":
    unittest.main()
