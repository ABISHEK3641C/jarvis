"""
Tests for MYRAA Tools Registry and Execution
Validates schema verification, tool allowlists, and execution outcomes.
"""
import unittest
from MYRAA.tools.registry import ToolRegistry
from MYRAA.tools.app_launcher import LaunchApprovedAppTool
from MYRAA.tools.system_info import GetSystemInfoTool
from MYRAA.tools.notes_tool import CreateNoteTool
from MYRAA.security.confirmation import confirmation_manager


class TestTools(unittest.TestCase):
    def setUp(self):
        self.registry = ToolRegistry()
        self.registry.register(LaunchApprovedAppTool())
        self.registry.register(GetSystemInfoTool())
        self.registry.register(CreateNoteTool())
        # Auto-approve for testing
        confirmation_manager.set_ui_callback(lambda r: True)

    def test_unknown_tool(self):
        res = self.registry.execute_tool("non_existent_tool", {})
        self.assertFalse(res["success"])
        self.assertIn("not registered", res["error"])

    def test_schema_validation(self):
        # Missing required 'app_name' parameter
        res = self.registry.execute_tool("launch_approved_app", {})
        self.assertFalse(res["success"])
        self.assertIn("Invalid parameters", res["error"])

    def test_system_info_tool(self):
        res = self.registry.execute_tool("get_system_info", {})
        self.assertTrue(res["success"])
        data = res["data"]
        self.assertIn("os", data)
        self.assertIn("python_version", data)

    def test_app_allowlist_enforcement(self):
        # Approved application
        res = self.registry.execute_tool("launch_approved_app", {"app_name": "calculator"})
        self.assertTrue(res["success"])

        # Unapproved / arbitrary binary execution
        res = self.registry.execute_tool("launch_approved_app", {"app_name": "unauthorized_malware.exe"})
        self.assertFalse(res["data"]["launched"])
        self.assertIn("not in the approved", res["data"]["error"])


if __name__ == "__main__":
    unittest.main()
