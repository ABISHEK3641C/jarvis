"""
Tests for MYRAA Security Subsystem
Verifies risk classification tiers, malware/credential theft blocking, and confirmation flow.
"""
import unittest
from MYRAA.security.classifier import ActionRisk, RiskClassifier
from MYRAA.security.confirmation import ConfirmationManager, ConfirmationRequest


class TestSecurityClassifier(unittest.TestCase):
    def test_blocked_intent(self):
        risk, reason = RiskClassifier.classify_text_intent("dump SAM credentials using mimikatz")
        self.assertEqual(risk, ActionRisk.BLOCKED)

        risk, reason = RiskClassifier.classify_text_intent("format C: /y")
        self.assertEqual(risk, ActionRisk.BLOCKED)

        risk, reason = RiskClassifier.classify_text_intent("steal browser passwords and token")
        self.assertEqual(risk, ActionRisk.BLOCKED)

    def test_high_risk_intent(self):
        risk, reason = RiskClassifier.classify_text_intent("delete file project.zip")
        self.assertEqual(risk, ActionRisk.HIGH)

        risk, reason = RiskClassifier.classify_text_intent("shutdown pc now")
        self.assertEqual(risk, ActionRisk.HIGH)

    def test_medium_risk_intent(self):
        risk, reason = RiskClassifier.classify_text_intent("take screenshot of current display")
        self.assertEqual(risk, ActionRisk.MEDIUM)

        risk, reason = RiskClassifier.classify_text_intent("create note buy groceries")
        self.assertEqual(risk, ActionRisk.MEDIUM)

    def test_low_risk_intent(self):
        risk, reason = RiskClassifier.classify_text_intent("what is the weather today?")
        self.assertEqual(risk, ActionRisk.LOW)

    def test_tool_call_classification(self):
        risk, _ = RiskClassifier.classify_tool_call("launch_approved_app", {"app_name": "notepad"})
        self.assertEqual(risk, ActionRisk.LOW)

        risk, _ = RiskClassifier.classify_tool_call("read_document", {"file_path": "C:\\Docs\\notes.txt"})
        self.assertEqual(risk, ActionRisk.MEDIUM)

        risk, _ = RiskClassifier.classify_tool_call("system_shutdown", {})
        self.assertEqual(risk, ActionRisk.HIGH)

        # Injected payload in parameter
        risk, _ = RiskClassifier.classify_tool_call("read_document", {"file_path": "mimikatz dump sam"})
        self.assertEqual(risk, ActionRisk.BLOCKED)


class TestConfirmationManager(unittest.TestCase):
    def setUp(self):
        self.cm = ConfirmationManager()

    def test_blocked_action_auto_denied(self):
        req = ConfirmationRequest(
            request_id="test1",
            tool_name="malicious_tool",
            parameters={},
            risk_level=ActionRisk.BLOCKED,
            reason="Dangerous",
            target_summary="Blocked target"
        )
        approved = self.cm.request_approval(req)
        self.assertFalse(approved)
        self.assertEqual(req.status, "AUTO_DENIED")

    def test_low_risk_auto_approved(self):
        req = ConfirmationRequest(
            request_id="test2",
            tool_name="get_system_info",
            parameters={},
            risk_level=ActionRisk.LOW,
            reason="Read only",
            target_summary="System status"
        )
        approved = self.cm.request_approval(req)
        self.assertTrue(approved)
        self.assertEqual(req.status, "APPROVED")

    def test_ui_callback_confirmation(self):
        # Mock user approving dialog
        self.cm.set_ui_callback(lambda r: True)
        req = ConfirmationRequest(
            request_id="test3",
            tool_name="create_note",
            parameters={"title": "Test"},
            risk_level=ActionRisk.MEDIUM,
            reason="Modifies state",
            target_summary="Create note"
        )
        approved = self.cm.request_approval(req)
        self.assertTrue(approved)
        self.assertEqual(req.status, "APPROVED")


if __name__ == "__main__":
    unittest.main()
