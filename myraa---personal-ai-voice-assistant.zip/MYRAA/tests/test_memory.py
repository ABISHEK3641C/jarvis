"""
Tests for MYRAA SQLite Memory Subsystem
Validates conversations, user long-term memories, and reminders persistence.
"""
from pathlib import Path
import tempfile
import unittest
from MYRAA.memory.database import DatabaseManager
from MYRAA.memory.conversations import ConversationStore, ChatMessage
from MYRAA.memory.memories import MemoryStore
from MYRAA.memory.reminders import RemindersStore


class TestMemorySubsystem(unittest.TestCase):
    def setUp(self):
        self.temp_dir = tempfile.TemporaryDirectory()
        self.db_path = Path(self.temp_dir.name) / "test_myraa.db"
        self.db = DatabaseManager(self.db_path)
        self.conv_store = ConversationStore(self.db)
        self.memory_store = MemoryStore(self.db)
        self.reminders_store = RemindersStore(self.db)

    def tearDown(self):
        self.db.close()
        self.temp_dir.cleanup()

    def test_conversation_persistence(self):
        msg_id = self.conv_store.add_message(ChatMessage(role="user", content="Hello MYRAA", language="en"))
        self.assertIsNotNone(msg_id)

        history = self.conv_store.get_recent_messages(limit=5)
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0].content, "Hello MYRAA")
        self.assertEqual(history[0].role, "user")

    def test_memory_crud(self):
        mem_id = self.memory_store.add_memory("preference", "Prefers dark theme", tags="ui,theme")
        self.assertIsNotNone(mem_id)

        results = self.memory_store.search_memories("dark theme")
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0].content, "Prefers dark theme")

        # Edit memory
        self.memory_store.update_memory(mem_id, "Prefers high contrast dark theme")
        updated = self.memory_store.search_memories("high contrast")
        self.assertEqual(len(updated), 1)

        # Delete memory
        self.memory_store.delete_memory(mem_id)
        self.assertEqual(len(self.memory_store.search_memories("dark")), 0)

    def test_reminders_store(self):
        rem_id = self.reminders_store.add_reminder("Team Standup", "2026-10-10 10:00:00", recurrence="daily")
        self.assertIsNotNone(rem_id)

        active = self.reminders_store.list_reminders()
        self.assertEqual(len(active), 1)
        self.assertEqual(active[0].title, "Team Standup")

        self.reminders_store.mark_completed(rem_id)
        self.assertEqual(len(self.reminders_store.list_reminders(include_completed=False)), 0)


if __name__ == "__main__":
    unittest.main()
