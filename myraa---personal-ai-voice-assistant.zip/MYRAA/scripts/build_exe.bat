@echo off
title Build MYRAA Windows Standalone Executable (.exe)
cd /d "%~dp0\.."

echo ========================================================
echo    Building MYRAA Windows Executable with PyInstaller
echo ========================================================

set PYTHON_EXE=python
if exist ".venv\Scripts\python.exe" (
    set PYTHON_EXE=".venv\Scripts\python.exe"
)

echo Installing pyinstaller...
%PYTHON_EXE% -m pip install pyinstaller

echo Packaging MYRAA into standalone executable...
%PYTHON_EXE% -m PyInstaller ^
    --name="MYRAA" ^
    --onedir ^
    --windowed ^
    --add-data "core;core" ^
    --add-data "tools;tools" ^
    --add-data "security;security" ^
    --add-data "memory;memory" ^
    --add-data "ai;ai" ^
    --add-data "voice;voice" ^
    --add-data "vision;vision" ^
    --add-data "ui;ui" ^
    app.py

if %errorlevel% == 0 (
    echo [SUCCESS] Build complete! Executable located at: dist\MYRAA\MYRAA.exe
) else (
    echo [ERROR] Build failed. Check compiler errors above.
)

pause
