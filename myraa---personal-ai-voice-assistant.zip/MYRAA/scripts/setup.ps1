# MYRAA Windows PowerShell Automated Setup Script
# Run with: powershell -ExecutionPolicy Bypass -File .\scripts\setup.ps1

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "       MYRAA Windows 10/11 Assistant Setup Wizard        " -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# 1. Check Python
$pythonCmd = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonCmd) {
    Write-Host "[ERROR] Python 3.10+ is required but not found in PATH." -ForegroundColor Red
    Write-Host "Please install Python from https://www.python.org/downloads/ and check 'Add Python to PATH'." -ForegroundColor Yellow
    Exit 1
}

$pyVersion = & python --version
Write-Host "[OK] Detected: $pyVersion" -ForegroundColor Green

# 2. Create Virtual Environment
$venvPath = Join-Path $PSScriptRoot "..\.venv"
if (-not (Test-Path $venvPath)) {
    Write-Host "[INFO] Creating Python virtual environment in .venv..." -ForegroundColor Cyan
    & python -m venv $venvPath
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] Failed to create virtual environment." -ForegroundColor Red
        Exit 1
    }
}
Write-Host "[OK] Virtual environment ready at $venvPath" -ForegroundColor Green

# 3. Upgrade pip and install requirements
$venvPython = Join-Path $venvPath "Scripts\python.exe"
$reqFile = Join-Path $PSScriptRoot "..\requirements.txt"

Write-Host "[INFO] Installing production dependencies via pip..." -ForegroundColor Cyan
& $venvPython -m pip install --upgrade pip
& $venvPython -m pip install -r $reqFile

if ($LASTEXITCODE -eq 0) {
    Write-Host "[SUCCESS] All dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "[WARNING] Some dependencies had warnings. Check output above." -ForegroundColor Yellow
}

# 4. Check for .env file
$envFile = Join-Path $PSScriptRoot "..\.env"
$envExample = Join-Path $PSScriptRoot "..\.env.example"
if (-not (Test-Path $envFile)) {
    if (Test-Path $envExample) {
        Copy-Item $envExample $envFile
        Write-Host "[INFO] Created .env from .env.example. Please add your GEMINI_API_KEY." -ForegroundColor Yellow
    }
}

Write-Host ""
Write-Host "Setup Complete!" -ForegroundColor Green
Write-Host "To launch MYRAA, run: .\scripts\run.bat" -ForegroundColor Cyan
Write-Host "Or execute directly: .\.venv\Scripts\python.exe app.py" -ForegroundColor Cyan
