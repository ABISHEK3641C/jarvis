@echo off
title MYRAA - Personal AI Voice Assistant
cd /d "%~dp0\.."

echo ========================================================
echo    Launching MYRAA Personal AI Assistant (Windows)
echo ========================================================

:: Check for virtual environment python
if exist ".venv\Scripts\python.exe" (
    echo Using Virtual Environment (.venv)...
    ".venv\Scripts\python.exe" app.py
    goto end
)

:: Check system python
python --version >nul 2>&1
if %errorlevel% == 0 (
    echo Using System Python...
    python app.py
    goto end
)

echo [ERROR] Python not found! Please run .\scripts\setup.ps1 or install Python 3.10+.
pause

:end
