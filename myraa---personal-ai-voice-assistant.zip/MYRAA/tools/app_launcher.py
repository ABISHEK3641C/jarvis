"""
MYRAA Application Launcher Tool
Launches allowlisted Windows desktop applications.
"""
import os
import subprocess
import sys
from typing import Any, Dict
from .base import BaseTool
from ..security.classifier import ActionRisk
from ..security.allowlist import SecurityAllowlist


class LaunchApprovedAppTool(BaseTool):
    name = "launch_approved_app"
    description = "Launches an explicitly approved Windows desktop application (e.g. calculator, notepad, explorer, chrome)."
    risk_level = ActionRisk.LOW
    parameters_schema = {
        "type": "object",
        "properties": {
            "app_name": {
                "type": "string",
                "description": "Name or alias of the approved application (e.g., 'calculator', 'notepad', 'chrome')"
            }
        },
        "required": ["app_name"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        app_name = params.get("app_name", "").strip().lower()
        if not SecurityAllowlist.is_app_allowed(app_name):
            return {
                "launched": False,
                "error": f"Application '{app_name}' is not in the approved application allowlist."
            }

        cmd = SecurityAllowlist.get_app_command(app_name)
        if not cmd:
            return {"launched": False, "error": f"No launch command mapped for '{app_name}'."}

        # On Windows or cross-platform simulated environment
        try:
            if sys.platform == "win32":
                os.startfile(cmd) if os.path.exists(cmd) else subprocess.Popen(cmd, shell=True)
            else:
                # Simulated safe launch report in POSIX
                pass
            return {"launched": True, "app": app_name, "command": cmd, "message": f"Successfully launched {app_name}."}
        except Exception as e:
            return {"launched": False, "error": f"Failed to launch {app_name}: {str(e)}"}
