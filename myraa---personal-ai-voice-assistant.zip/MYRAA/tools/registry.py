"""
MYRAA Tool Registry
Central catalog of tools with mandatory security validation, confirmation, and auditing.
"""
from typing import Any, Dict, List, Optional
import uuid
from .base import BaseTool
from ..security.classifier import ActionRisk, RiskClassifier
from ..security.confirmation import ConfirmationRequest, confirmation_manager
from ..security.audit import audit_logger


class ToolRegistry:
    def __init__(self):
        self._tools: Dict[str, BaseTool] = {}

    def register(self, tool: BaseTool):
        self._tools[tool.name] = tool

    def get_tool(self, name: str) -> Optional[BaseTool]:
        return self._tools.get(name)

    def list_tools(self) -> List[Dict[str, Any]]:
        return [
            {
                "name": t.name,
                "description": t.description,
                "parameters": t.parameters_schema,
                "risk_level": t.risk_level.value
            }
            for t in self._tools.values()
        ]

    def execute_tool(self, name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        tool = self.get_tool(name)
        if not tool:
            audit_logger.log(name, ActionRisk.BLOCKED, "REJECTED_UNKNOWN_TOOL", params, "Tool not found in registry")
            return {"success": False, "error": f"Tool '{name}' is not registered."}

        # 1. Parameter Schema Validation
        if not tool.validate(params):
            audit_logger.log(name, tool.risk_level, "REJECTED_INVALID_PARAMS", params, "Missing required parameters")
            return {"success": False, "error": f"Invalid parameters for tool '{name}'."}

        # 2. Security Risk Classification
        risk, reason = RiskClassifier.classify_tool_call(name, params)
        if risk == ActionRisk.BLOCKED:
            audit_logger.log(name, risk, "BLOCKED", params, reason)
            return {"success": False, "error": f"Action blocked by security policy: {reason}"}

        # 3. User Confirmation Requirement
        if risk in (ActionRisk.MEDIUM, ActionRisk.HIGH):
            req = ConfirmationRequest(
                request_id=str(uuid.uuid4())[:8],
                tool_name=name,
                parameters=params,
                risk_level=risk,
                reason=reason,
                target_summary=f"Run '{name}' with {params}"
            )
            approved = confirmation_manager.request_approval(req)
            if not approved:
                audit_logger.log(name, risk, "USER_DENIED", params, "User rejected confirmation request")
                return {"success": False, "error": f"Execution of '{name}' was declined by user or security policy."}

        # 4. Safe Tool Execution
        try:
            result = tool.execute(params)
            audit_logger.log(name, risk, "EXECUTED_SUCCESS", params, str(result.get("data", "")))
            return {"success": True, "data": result}
        except Exception as e:
            audit_logger.log(name, risk, "EXECUTED_FAILURE", params, str(e))
            return {"success": False, "error": f"Tool execution failed: {str(e)}"}


tool_registry = ToolRegistry()
