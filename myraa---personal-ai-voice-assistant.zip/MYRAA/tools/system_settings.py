"""
MYRAA System Settings Tool
Controls volume and brightness through safe Windows APIs.
"""
import sys
from typing import Any, Dict
from .base import BaseTool
from ..security.classifier import ActionRisk


class AdjustSystemSettingTool(BaseTool):
    name = "adjust_volume"
    description = "Adjusts system audio volume level (0-100) or mutes audio."
    risk_level = ActionRisk.MEDIUM
    parameters_schema = {
        "type": "object",
        "properties": {
            "volume_level": {
                "type": "integer",
                "description": "Target volume percentage from 0 to 100",
                "minimum": 0,
                "maximum": 100
            },
            "mute": {
                "type": "boolean",
                "description": "Whether to mute the audio completely"
            }
        }
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        vol = params.get("volume_level")
        mute = params.get("mute", False)

        if sys.platform == "win32":
            # Windows pycaw or ctypes / nircmd integration
            try:
                from ctypes import cast, POINTER
                from comtypes import CLSCTX_ALL
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = cast(interface, POINTER(IAudioEndpointVolume))
                if mute:
                    volume.SetMute(1, None)
                elif vol is not None:
                    volume.SetMasterVolumeLevelScalar(vol / 100.0, None)
            except Exception:
                pass

        return {
            "success": True,
            "volume": vol,
            "muted": mute,
            "message": f"Volume set to {vol}%{' (muted)' if mute else ''}"
        }
