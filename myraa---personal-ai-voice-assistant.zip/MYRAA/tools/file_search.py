"""
MYRAA File Search Tool
Searches for files strictly within user-approved directories.
"""
import os
from pathlib import Path
from typing import Any, Dict, List
from .base import BaseTool
from ..security.classifier import ActionRisk
from ..security.allowlist import SecurityAllowlist
from ..core.config import get_config


class SearchFilesTool(BaseTool):
    name = "search_files"
    description = "Searches for files matching a pattern or name within user-approved directories."
    risk_level = ActionRisk.LOW
    parameters_schema = {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Filename, keyword, or extension to search for (e.g. 'budget.xlsx', 'report', '.pdf')"
            },
            "directory": {
                "type": "string",
                "description": "Specific directory to search in (must be in approved directories). Defaults to all approved directories."
            }
        },
        "required": ["query"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        query = params.get("query", "").lower()
        custom_dir = params.get("directory")
        config = get_config()

        search_dirs: List[Path] = []
        if custom_dir:
            if not SecurityAllowlist.is_path_in_approved_directories(custom_dir):
                return {
                    "found": False,
                    "error": f"Directory '{custom_dir}' is not in the user-approved directories allowlist."
                }
            search_dirs.append(Path(custom_dir))
        else:
            for d in config.approved_directories:
                p = Path(d).expanduser()
                if p.exists():
                    search_dirs.append(p)

        matches = []
        for s_dir in search_dirs:
            try:
                for root, _, files in os.walk(s_dir):
                    for f in files:
                        if query in f.lower():
                            full_path = Path(root) / f
                            matches.append({
                                "name": f,
                                "path": str(full_path),
                                "size_bytes": full_path.stat().st_size
                            })
                            if len(matches) >= 50:
                                break
                    if len(matches) >= 50:
                        break
            except Exception:
                continue

        return {
            "query": query,
            "count": len(matches),
            "results": matches
        }
