"""
MYRAA Base Tool Interface
Defines schema, risk level, input validation, and execution contract for all tools.
"""
from abc import ABC, abstractmethod
from typing import Any, Dict
from ..security.classifier import ActionRisk


class BaseTool(ABC):
    name: str = ""
    description: str = ""
    parameters_schema: Dict[str, Any] = {}
    risk_level: ActionRisk = ActionRisk.LOW

    def validate(self, params: Dict[str, Any]) -> bool:
        """Validates that required parameters exist and match types."""
        required = self.parameters_schema.get("required", [])
        for req in required:
            if req not in params:
                return False
        return True

    @abstractmethod
    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Executes the tool safely and returns a result dict."""
        pass
