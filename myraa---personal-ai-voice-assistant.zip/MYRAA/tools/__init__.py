"""
MYRAA Tools Subsystem
Registers all approved desktop, file, system, and memory tools.
"""
from .base import BaseTool
from .registry import ToolRegistry, tool_registry
from .app_launcher import LaunchApprovedAppTool
from .system_info import GetSystemInfoTool
from .system_settings import AdjustSystemSettingTool
from .file_search import SearchFilesTool
from .file_reader import ReadDocumentTool
from .notes_tool import CreateNoteTool, SetReminderTool, ClipboardTool, OpenApprovedUrlTool, CaptureScreenTool


def register_default_tools(registry: ToolRegistry = tool_registry):
    registry.register(LaunchApprovedAppTool())
    registry.register(GetSystemInfoTool())
    registry.register(AdjustSystemSettingTool())
    registry.register(SearchFilesTool())
    registry.register(ReadDocumentTool())
    registry.register(CreateNoteTool())
    registry.register(SetReminderTool())
    registry.register(ClipboardTool())
    registry.register(OpenApprovedUrlTool())
    registry.register(CaptureScreenTool())


register_default_tools()

__all__ = [
    "BaseTool",
    "ToolRegistry",
    "tool_registry",
    "register_default_tools",
    "LaunchApprovedAppTool",
    "GetSystemInfoTool",
    "AdjustSystemSettingTool",
    "SearchFilesTool",
    "ReadDocumentTool",
    "CreateNoteTool",
    "SetReminderTool",
    "ClipboardTool",
    "OpenApprovedUrlTool",
    "CaptureScreenTool",
]
