"""
MYRAA Document Reader Tool
Reads text files, markdown, code, and PDFs with user permission in approved directories.
"""
from pathlib import Path
from typing import Any, Dict
from .base import BaseTool
from ..security.classifier import ActionRisk
from ..security.allowlist import SecurityAllowlist


class ReadDocumentTool(BaseTool):
    name = "read_document"
    description = "Reads the text content of a supported document (txt, md, py, json, pdf) in an approved directory."
    risk_level = ActionRisk.MEDIUM
    parameters_schema = {
        "type": "object",
        "properties": {
            "file_path": {
                "type": "string",
                "description": "Absolute path to the document to read."
            },
            "max_characters": {
                "type": "integer",
                "description": "Maximum number of characters to read (default 4000)."
            }
        },
        "required": ["file_path"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        file_path_str = params.get("file_path", "")
        max_chars = params.get("max_characters", 4000)

        path = Path(file_path_str).expanduser()
        if not path.exists():
            return {"success": False, "error": f"File '{file_path_str}' does not exist."}

        if not SecurityAllowlist.is_path_in_approved_directories(str(path)):
            return {
                "success": False,
                "error": f"Path '{file_path_str}' is outside approved directories."
            }

        suffix = path.suffix.lower()

        # Handle text files
        if suffix in [".txt", ".md", ".py", ".json", ".csv", ".log", ".yaml", ".yml", ".html"]:
            try:
                with open(path, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read(max_chars)
                return {
                    "success": True,
                    "file_name": path.name,
                    "content": content,
                    "truncated": len(content) >= max_chars
                }
            except Exception as e:
                return {"success": False, "error": f"Failed to read file: {str(e)}"}

        # Handle PDF files
        elif suffix == ".pdf":
            try:
                # Optional pypdf or PyPDF2 if installed
                import pypdf
                reader = pypdf.PdfReader(str(path))
                text = ""
                for page in reader.pages[:10]:
                    text += page.extract_text() or ""
                    if len(text) >= max_chars:
                        break
                return {
                    "success": True,
                    "file_name": path.name,
                    "content": text[:max_chars],
                    "truncated": len(text) >= max_chars
                }
            except ImportError:
                return {
                    "success": False,
                    "error": "pypdf library not installed for PDF reading."
                }
            except Exception as e:
                return {"success": False, "error": f"Error parsing PDF: {str(e)}"}

        return {"success": False, "error": f"Unsupported file type: {suffix}"}
