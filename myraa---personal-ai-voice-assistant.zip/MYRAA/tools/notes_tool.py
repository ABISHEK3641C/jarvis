"""
MYRAA Notes & Productivity Tools
Handles creating notes, managing reminders, clipboard, and browser allowlisted URLs.
"""
from typing import Any, Dict
from .base import BaseTool
from ..security.classifier import ActionRisk
from ..memory.notes import NotesStore
from ..memory.reminders import RemindersStore
from ..security.allowlist import SecurityAllowlist


class CreateNoteTool(BaseTool):
    name = "create_note"
    description = "Saves a new note or memo into the assistant's persistent note vault."
    risk_level = ActionRisk.MEDIUM
    parameters_schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Title of the note"},
            "body": {"type": "string", "description": "Text content of the note"},
            "tags": {"type": "string", "description": "Optional comma-separated tags"}
        },
        "required": ["title", "body"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        store = NotesStore()
        note_id = store.add_note(
            title=params["title"],
            body=params["body"],
            tags=params.get("tags", "")
        )
        return {"success": True, "note_id": note_id, "title": params["title"]}


class SetReminderTool(BaseTool):
    name = "set_reminder"
    description = "Schedules a reminder with an explicit due date/time and recurrence pattern."
    risk_level = ActionRisk.LOW
    parameters_schema = {
        "type": "object",
        "properties": {
            "title": {"type": "string", "description": "Description of the reminder task"},
            "due_time": {"type": "string", "description": "ISO timestamp or human readable due time"},
            "recurrence": {"type": "string", "enum": ["none", "daily", "weekly"], "description": "Recurrence pattern"}
        },
        "required": ["title", "due_time"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        store = RemindersStore()
        rem_id = store.add_reminder(
            title=params["title"],
            due_time=params["due_time"],
            recurrence=params.get("recurrence", "none")
        )
        return {"success": True, "reminder_id": rem_id, "title": params["title"], "due_time": params["due_time"]}


class ClipboardTool(BaseTool):
    name = "set_clipboard"
    description = "Copies text directly into the system clipboard."
    risk_level = ActionRisk.MEDIUM
    parameters_schema = {
        "type": "object",
        "properties": {
            "text": {"type": "string", "description": "Text content to copy to clipboard"}
        },
        "required": ["text"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        text = params["text"]
        try:
            import pyperclip
            pyperclip.copy(text)
            return {"success": True, "copied_length": len(text)}
        except Exception:
            return {"success": True, "simulated": True, "copied_length": len(text)}


class OpenApprovedUrlTool(BaseTool):
    name = "open_approved_url"
    description = "Opens an allowlisted web page or browser search in the default web browser."
    risk_level = ActionRisk.LOW
    parameters_schema = {
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "Approved web URL starting with https://"}
        },
        "required": ["url"]
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        url = params.get("url", "")
        if not SecurityAllowlist.is_url_allowed(url):
            return {
                "success": False,
                "error": f"URL '{url}' is not on the user-approved web allowlist."
            }
        import webbrowser
        try:
            webbrowser.open(url)
            return {"success": True, "url": url}
        except Exception as e:
            return {"success": False, "error": str(e)}


class CaptureScreenTool(BaseTool):
    name = "capture_screen"
    description = "Captures the active Windows screen for explicit vision analysis and OCR."
    risk_level = ActionRisk.MEDIUM
    parameters_schema = {
        "type": "object",
        "properties": {
            "reason": {"type": "string", "description": "User requested reason for screen capture"}
        }
    }

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        from ..vision.screen_capture import screen_capture_service
        result = screen_capture_service.capture_screen()
        return result
