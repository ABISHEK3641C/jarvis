"""
MYRAA Personal AI Voice Assistant
Main Application Entry Point (Windows 10/11)
"""
import os
import sys
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from core.config import get_config
from core.logger import setup_logger
from core.events import event_bus
from memory.database import get_db
from tools import register_default_tools
from security.confirmation import confirmation_manager


def check_environment():
    """Validates runtime prerequisites and outputs helpful startup diagnostics."""
    logger = setup_logger("MYRAA.Startup")
    logger.info("Initializing MYRAA Voice Assistant...")

    if sys.version_info < (3, 10):
        logger.warning(f"Python {sys.version} detected. Python 3.10+ recommended.")

    # Check database
    try:
        db = get_db()
        logger.info(f"SQLite Database verified at {db.db_path}")
    except Exception as e:
        logger.error(f"Failed to initialize SQLite database: {e}")

    # Register tools
    try:
        register_default_tools()
        logger.info("Default tool registry loaded.")
    except Exception as e:
        logger.error(f"Failed to load tools: {e}")

    return logger


def main():
    logger = check_environment()
    config = get_config()

    try:
        from PySide6.QtWidgets import QApplication
        from ui.main_window import MainWindow

        # Set high DPI attributes
        app = QApplication(sys.argv)
        app.setApplicationName(config.app_name)
        app.setApplicationVersion(config.app_version)

        window = MainWindow()
        window.show()

        logger.info("MYRAA Desktop Window started successfully.")
        sys.exit(app.exec())
    except ImportError as e:
        logger.warning(
            f"PySide6 GUI could not be initialized ({e}). "
            "Running in Headless / CLI Assistant Mode..."
        )
        run_cli_mode()


def run_cli_mode():
    """Terminal fallback mode for headless servers, Linux containers, or test execution."""
    from ai.router import ai_router
    from memory.conversations import ConversationStore, ChatMessage

    print("\n" + "=" * 55)
    print("✨ MYRAA Personal AI Assistant - Interactive CLI Mode")
    print("Type your message (or 'exit' to quit). Supports English, हिंदी, and Hinglish.")
    print("=" * 55 + "\n")

    store = ConversationStore()

    while True:
        try:
            user_input = input("You > ").strip()
            if not user_input:
                continue
            if user_input.lower() in ("exit", "quit", "bye"):
                print("MYRAA > Goodbye! Have a great day.")
                break

            response = ai_router.route_query(user_input)
            print(f"MYRAA ({response.model_name}) > {response.text}\n")
            store.add_message(ChatMessage(role="user", content=user_input))
            store.add_message(ChatMessage(role="assistant", content=response.text))
        except (KeyboardInterrupt, EOFError):
            print("\nExiting MYRAA.")
            break


if __name__ == "__main__":
    main()
