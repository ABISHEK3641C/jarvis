"""
core/llm_engine.py
--------------------
Wraps the Ollama chat API: streaming token generation, conversation
history, and tool/function calling. Ollama's /api/chat endpoint supports
a `tools` field (OpenAI-style function schema) for models that support
tool use (Qwen3, Llama 3.1+, etc).
"""
from __future__ import annotations

import json
from typing import Any, AsyncIterator, Callable, Optional

import httpx

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("core.llm_engine")


class ToolCall:
    def __init__(self, name: str, arguments: dict[str, Any]):
        self.name = name
        self.arguments = arguments

    def __repr__(self) -> str:
        return f"ToolCall(name={self.name!r}, arguments={self.arguments!r})"


class StreamChunk:
    """A single piece of a streamed response: either text or a completed tool call."""

    def __init__(self, text: str = "", tool_call: Optional[ToolCall] = None, done: bool = False):
        self.text = text
        self.tool_call = tool_call
        self.done = done


class LLMEngine:
    def __init__(self, host: Optional[str] = None, model: Optional[str] = None):
        self.host = (host or CONFIG.llm.host).rstrip("/")
        self.model = model or CONFIG.llm.model
        self._client = httpx.AsyncClient(timeout=120.0)

    async def close(self) -> None:
        await self._client.aclose()

    async def is_available(self) -> bool:
        try:
            resp = await self._client.get(f"{self.host}/api/tags")
            return resp.status_code == 200
        except httpx.HTTPError:
            return False

    async def stream_chat(
        self,
        messages: list[dict[str, str]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> AsyncIterator[StreamChunk]:
        """
        Stream a chat completion from Ollama.

        `messages` is a list of {"role": ..., "content": ...} dicts.
        `tools` follows the OpenAI/Ollama function-schema format:
            [{"type": "function", "function": {"name": ..., "description": ...,
              "parameters": {...JSON schema...}}}]
        """
        payload: dict[str, Any] = {
            "model": self.model,
            "messages": messages,
            "stream": True,
            "options": {
                "temperature": CONFIG.llm.temperature,
                "top_p": CONFIG.llm.top_p,
                "num_predict": CONFIG.llm.max_tokens,
            },
        }
        if tools:
            payload["tools"] = tools

        async with self._client.stream(
            "POST", f"{self.host}/api/chat", json=payload
        ) as response:
            response.raise_for_status()
            async for line in response.aiter_lines():
                if not line.strip():
                    continue
                data = json.loads(line)

                message = data.get("message", {})

                # Tool call (non-streamed, arrives as a complete block)
                tool_calls = message.get("tool_calls")
                if tool_calls:
                    for tc in tool_calls:
                        fn = tc.get("function", {})
                        args = fn.get("arguments", {})
                        if isinstance(args, str):
                            try:
                                args = json.loads(args)
                            except json.JSONDecodeError:
                                args = {}
                        yield StreamChunk(tool_call=ToolCall(fn.get("name", ""), args))

                content = message.get("content", "")
                if content:
                    yield StreamChunk(text=content)

                if data.get("done"):
                    yield StreamChunk(done=True)
                    break

    async def chat_once(
        self,
        messages: list[dict[str, str]],
        tools: Optional[list[dict[str, Any]]] = None,
    ) -> tuple[str, list[ToolCall]]:
        """Non-streaming convenience wrapper; collects the full reply and any tool calls."""
        full_text = []
        calls: list[ToolCall] = []
        async for chunk in self.stream_chat(messages, tools=tools):
            if chunk.text:
                full_text.append(chunk.text)
            if chunk.tool_call:
                calls.append(chunk.tool_call)
        return "".join(full_text), calls
