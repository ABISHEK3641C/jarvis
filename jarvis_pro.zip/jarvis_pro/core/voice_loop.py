"""
core/voice_loop.py
---------------------
Ties the audio subsystem to the orchestrator for hands-free operation:

    wake word -> VAD-trimmed recording -> STT -> Orchestrator -> TTS

Runs the wake-word listener on a background thread (it blocks on the
mic stream) and hands off to an asyncio event loop for the LLM/tooling
portion of each turn, since httpx and the orchestrator are async.
"""
from __future__ import annotations

import asyncio
import threading
from typing import Optional

import sounddevice as sd

from audio.stt import SpeechToText
from audio.tts import TextToSpeech
from audio.vad import VoiceActivityDetector
from audio.wake_word import WakeWordListener
from core.config import CONFIG
from core.logger import get_logger
from core.orchestrator import Orchestrator

log = get_logger("core.voice_loop")


class VoiceLoop:
    def __init__(self, orchestrator: Orchestrator, event_loop: Optional[asyncio.AbstractEventLoop] = None):
        self.orchestrator = orchestrator
        self.stt = SpeechToText()
        self.tts = TextToSpeech()
        self.vad = VoiceActivityDetector()
        self.wake_listener = WakeWordListener(on_wake=self._on_wake_word)
        self._loop = event_loop
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._loop = self._loop or asyncio.get_event_loop()
        self._thread = threading.Thread(target=self.wake_listener.listen_forever, daemon=True)
        self._thread.start()
        log.info("Voice loop started.")

    def stop(self) -> None:
        self.wake_listener.stop()

    # ------------------------------------------------------------------
    def _on_wake_word(self, matched: str) -> None:
        log.info("Wake word '%s' triggered; recording command.", matched)
        self.tts.interrupt()  # stop JARVIS if it was mid-sentence
        command_audio = self._record_utterance()
        text = self.stt.transcribe(command_audio)
        if not text.strip():
            log.info("No speech detected after wake word.")
            return
        log.info("User said: %s", text)

        # Hand off to the async orchestrator from this sync callback thread.
        asyncio.run_coroutine_threadsafe(self._respond(text), self._loop)

    def _record_utterance(self, max_seconds: float = 10.0) -> bytes:
        """Record from the mic until VAD detects trailing silence or max_seconds elapses."""
        sample_rate = self.vad.sample_rate
        frame_bytes = self.vad.frame_size

        recorded: list = []

        def frame_generator():
            with sd.InputStream(
                samplerate=sample_rate, channels=1, dtype="int16", blocksize=self.vad.frame_size
            ) as stream:
                total_frames = 0
                max_frames = int(max_seconds * 1000 / self.vad.frame_duration_ms)
                while total_frames < max_frames:
                    data, _ = stream.read(self.vad.frame_size)
                    frame = data.tobytes()
                    recorded.append(frame)
                    yield frame
                    total_frames += 1

        self.vad.collect_utterance(frame_generator())
        return b"".join(recorded)

    async def _respond(self, user_text: str) -> None:
        reply_parts = []
        async for chunk in self.orchestrator.handle_turn(user_text):
            reply_parts.append(chunk)
        full_reply = "".join(reply_parts)
        if full_reply.strip():
            self.tts.speak(full_reply, blocking=False)
