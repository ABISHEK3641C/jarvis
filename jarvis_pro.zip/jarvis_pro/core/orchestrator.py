"""
core/orchestrator.py
----------------------
The brain of JARVIS. Wires together the LLM engine, memory manager, and
plugin registry. Handles a full turn: build context -> stream from LLM ->
execute any requested tool calls -> feed results back -> produce the
final natural-language reply (optionally spoken via TTS).

This is intentionally the single place that other subsystems (GUI, CLI,
voice loop) call into, so JARVIS behaves identically regardless of
whether the user typed or spoke.
"""
from __future__ import annotations

from typing import AsyncIterator, Optional

from core.config import CONFIG
from core.llm_engine import LLMEngine, StreamChunk, ToolCall
from core.logger import get_logger
from memory.memory_manager import MemoryManager
from plugins.plugin_manager import PluginManager

log = get_logger("core.orchestrator")

MAX_TOOL_HOPS = 4  # guard against infinite tool-call loops


class Orchestrator:
    def __init__(
        self,
        llm: Optional[LLMEngine] = None,
        memory: Optional[MemoryManager] = None,
        plugins: Optional[PluginManager] = None,
    ):
        self.llm = llm or LLMEngine()
        self.memory = memory or MemoryManager()
        self.plugins = plugins or PluginManager()
        self._loaded = False

    async def start(self) -> None:
        if not self._loaded:
            self.plugins.load_all()
            self.plugins.enable_hot_reload()
            self._loaded = True
        available = await self.llm.is_available()
        if not available:
            log.warning(
                "Ollama at %s is not reachable. Start it with `ollama serve` "
                "and ensure model '%s' is pulled.",
                self.llm.host,
                self.llm.model,
            )

    async def shutdown(self) -> None:
        self.plugins.stop()
        await self.llm.close()

    def _build_messages(self, user_text: str) -> list[dict[str, str]]:
        messages = [{"role": "system", "content": CONFIG.llm.system_prompt}]

        recalled = self.memory.semantic_recall(user_text)
        if recalled:
            recall_text = "\n".join(f"- {r['text']}" for r in recalled)
            messages.append(
                {"role": "system", "content": f"Relevant things you remember:\n{recall_text}"}
            )

        for turn in self.memory.recent_context():
            messages.append({"role": turn["role"], "content": turn["content"]})

        messages.append({"role": "user", "content": user_text})
        return messages

    async def handle_turn(self, user_text: str) -> AsyncIterator[str]:
        """
        Process one user utterance/message end-to-end, yielding response
        text chunks as they're generated (for streaming to GUI/TTS).
        """
        self.memory.remember_turn("user", user_text)
        messages = self._build_messages(user_text)
        tool_schemas = self.plugins.ollama_schemas()

        full_reply_parts: list[str] = []
        hops = 0

        while hops < MAX_TOOL_HOPS:
            hops += 1
            pending_calls: list[ToolCall] = []

            async for chunk in self.llm.stream_chat(messages, tools=tool_schemas or None):
                if chunk.text:
                    full_reply_parts.append(chunk.text)
                    yield chunk.text
                if chunk.tool_call:
                    pending_calls.append(chunk.tool_call)

            if not pending_calls:
                break  # model produced a final answer with no tool calls

            # Execute each requested tool and feed results back to the model.
            messages.append(
                {"role": "assistant", "content": "".join(full_reply_parts) or "(using tools)"}
            )
            for call in pending_calls:
                log.info("Executing tool: %s(%s)", call.name, call.arguments)
                result = await self.plugins.execute(call.name, call.arguments)
                messages.append(
                    {"role": "tool", "content": f"{call.name} result: {result}"}
                )
            full_reply_parts = []  # next hop produces the real final reply

        final_reply = "".join(full_reply_parts) if full_reply_parts else ""
        if final_reply:
            self.memory.remember_turn("assistant", final_reply)

    async def handle_turn_complete(self, user_text: str) -> str:
        """Non-streaming convenience wrapper returning the full final reply."""
        parts = []
        async for piece in self.handle_turn(user_text):
            parts.append(piece)
        return "".join(parts)
