"""
core/config.py
---------------
Loads config.yaml, applies environment variable overrides, and exposes a
single validated, typed Config object used throughout the app.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any, List, Optional

import yaml
from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config" / "config.yaml"


class AppConfig(BaseModel):
    name: str = "JARVIS Pro"
    version: str = "1.0.0"
    startup_greeting: str = "Systems online."
    log_level: str = "INFO"
    data_dir: str = "database"
    log_dir: str = "logs"


class LLMConfig(BaseModel):
    backend: str = "ollama"
    host: str = "http://localhost:11434"
    model: str = "qwen3:4b"
    temperature: float = 0.6
    top_p: float = 0.9
    max_tokens: int = 1024
    stream: bool = True
    system_prompt: str = "You are JARVIS, a helpful local AI assistant."


class MemoryConfig(BaseModel):
    db_path: str = "database/jarvis.db"
    vector_index_path: str = "database/vector.index"
    embedding_dim: int = 384
    embedding_model: str = "all-MiniLM-L6-v2"
    max_short_term_turns: int = 20
    top_k_recall: int = 5


class STTConfig(BaseModel):
    engine: str = "faster-whisper"
    model_size: str = "small.en"
    device: str = "cpu"
    compute_type: str = "int8"


class TTSConfig(BaseModel):
    primary_engine: str = "kokoro"
    fallback_engine: str = "piper"
    optional_engine: str = "edge-tts"
    voice: str = "af_heart"
    speaking_rate: float = 1.0


class AudioConfig(BaseModel):
    wake_words: List[str] = Field(default_factory=lambda: ["jarvis"])
    wake_word_sensitivity: float = 0.5
    sample_rate: int = 16000
    frame_duration_ms: int = 30
    vad_aggressiveness: int = 2
    stt: STTConfig = STTConfig()
    tts: TTSConfig = TTSConfig()
    allow_interruption: bool = True


class GUIConfig(BaseModel):
    theme: str = "dark"
    glass_opacity: float = 0.72
    accent_color: str = "#00d9ff"
    start_minimized: bool = False
    always_on_top: bool = False
    floating_mode: bool = False
    window_width: int = 420
    window_height: int = 640


class PluginsConfig(BaseModel):
    enabled_dir: str = "plugins/builtin"
    user_dir: str = "plugins/user"
    hot_reload: bool = True
    disabled: List[str] = Field(default_factory=list)


class PerformanceConfig(BaseModel):
    target_startup_seconds: int = 3
    target_response_seconds: int = 2


class Config(BaseModel):
    app: AppConfig = AppConfig()
    llm: LLMConfig = LLMConfig()
    memory: MemoryConfig = MemoryConfig()
    audio: AudioConfig = AudioConfig()
    gui: GUIConfig = GUIConfig()
    plugins: PluginsConfig = PluginsConfig()
    performance: PerformanceConfig = PerformanceConfig()

    def resolve_path(self, relative: str) -> Path:
        """Resolve a config-relative path against the project root."""
        p = Path(relative)
        return p if p.is_absolute() else PROJECT_ROOT / p


def _apply_env_overrides(raw: dict) -> dict:
    """Allow JARVIS_LLM__MODEL style env vars to override nested yaml keys."""
    prefix = "JARVIS_"
    for key, value in os.environ.items():
        if not key.startswith(prefix):
            continue
        path = key[len(prefix):].lower().split("__")
        node = raw
        for part in path[:-1]:
            node = node.setdefault(part, {})
        node[path[-1]] = value
    return raw


def load_config(path: Optional[Path] = None) -> Config:
    path = path or DEFAULT_CONFIG_PATH
    if not path.exists():
        return Config()
    with open(path, "r", encoding="utf-8") as f:
        raw: dict[str, Any] = yaml.safe_load(f) or {}
    raw = _apply_env_overrides(raw)
    return Config(**raw)


# Singleton used across the app
CONFIG = load_config()
