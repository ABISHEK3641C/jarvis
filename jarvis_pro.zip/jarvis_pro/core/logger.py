"""
core/logger.py
---------------
Central logging configuration. Console output via `rich` for readability,
rotating file handler for persistent logs.
"""
from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from pathlib import Path

from rich.logging import RichHandler

from core.config import CONFIG

_LOGGERS: dict[str, logging.Logger] = {}


def _ensure_log_dir() -> Path:
    log_dir = CONFIG.resolve_path(CONFIG.app.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    return log_dir


def get_logger(name: str) -> logging.Logger:
    """Return a configured logger, memoized by name."""
    if name in _LOGGERS:
        return _LOGGERS[name]

    logger = logging.getLogger(name)
    level = getattr(logging, CONFIG.app.log_level.upper(), logging.INFO)
    logger.setLevel(level)
    logger.propagate = False

    if not logger.handlers:
        console_handler = RichHandler(
            rich_tracebacks=True, show_time=True, show_path=False
        )
        console_handler.setLevel(level)
        console_fmt = logging.Formatter("%(message)s")
        console_handler.setFormatter(console_fmt)
        logger.addHandler(console_handler)

        try:
            log_dir = _ensure_log_dir()
            file_handler = RotatingFileHandler(
                log_dir / "jarvis.log",
                maxBytes=5 * 1024 * 1024,
                backupCount=3,
                encoding="utf-8",
            )
            file_fmt = logging.Formatter(
                "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"
            )
            file_handler.setFormatter(file_fmt)
            file_handler.setLevel(level)
            logger.addHandler(file_handler)
        except OSError:
            # Filesystem may be read-only in some environments; console-only is fine.
            pass

    _LOGGERS[name] = logger
    return logger
