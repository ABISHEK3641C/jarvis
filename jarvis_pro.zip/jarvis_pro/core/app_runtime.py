"""
core/app_runtime.py
----------------------
PySide6 runs its own (synchronous) event loop, while the orchestrator,
LLM engine, and plugin execution are async. AppRuntime bridges the two by
running a dedicated asyncio event loop on a background thread; the GUI
submits coroutines to it and receives results via Qt signals.
"""
from __future__ import annotations

import asyncio
import threading
from typing import Callable, Coroutine, Optional

from core.logger import get_logger
from core.orchestrator import Orchestrator

log = get_logger("core.app_runtime")


class AppRuntime:
    """Owns the asyncio event loop + Orchestrator on a dedicated thread."""

    def __init__(self):
        self.orchestrator = Orchestrator()
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._ready = threading.Event()

    def start(self) -> None:
        self._thread = threading.Thread(target=self._run_loop, daemon=True)
        self._thread.start()
        self._ready.wait(timeout=10)

    def _run_loop(self) -> None:
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
        self._loop.run_until_complete(self.orchestrator.start())
        self._ready.set()
        self._loop.run_forever()

    def stop(self) -> None:
        if self._loop is None:
            return
        asyncio.run_coroutine_threadsafe(self.orchestrator.shutdown(), self._loop)
        self._loop.call_soon_threadsafe(self._loop.stop)

    def submit_turn(
        self,
        user_text: str,
        on_chunk: Callable[[str], None],
        on_done: Callable[[str], None],
        on_error: Callable[[str], None],
    ) -> None:
        """Fire off a chat turn; callbacks are invoked from the background
        thread, so callers (GUI code) must marshal them back to the Qt
        thread via signals rather than touching widgets directly."""
        if self._loop is None:
            on_error("Runtime not started.")
            return
        asyncio.run_coroutine_threadsafe(
            self._run_turn(user_text, on_chunk, on_done, on_error), self._loop
        )

    async def _run_turn(
        self,
        user_text: str,
        on_chunk: Callable[[str], None],
        on_done: Callable[[str], None],
        on_error: Callable[[str], None],
    ) -> None:
        try:
            parts = []
            async for chunk in self.orchestrator.handle_turn(user_text):
                parts.append(chunk)
                on_chunk(chunk)
            on_done("".join(parts))
        except Exception as exc:  # noqa: BLE001
            log.error("Turn failed: %s", exc)
            on_error(str(exc))
