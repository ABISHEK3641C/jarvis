"""
utils/helpers.py
------------------
Small, dependency-free helpers shared across modules.
"""
from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Iterator


@contextmanager
def timed(label: str, logger) -> Iterator[None]:  # noqa: ANN001
    """Context manager that logs how long a block took, at DEBUG level."""
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        logger.debug("%s took %.3fs", label, elapsed)


def truncate(text: str, max_len: int = 200) -> str:
    return text if len(text) <= max_len else text[: max_len - 1] + "…"


def safe_int(value, default: int = 0) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
