@echo off
setlocal

echo ============================================
echo   JARVIS Pro - Setup
echo ============================================

where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on PATH. Install Python 3.11+ and re-run.
    exit /b 1
)

echo [1/4] Creating virtual environment...
python -m venv venv
call venv\Scripts\activate.bat

echo [2/4] Upgrading pip...
python -m pip install --upgrade pip

echo [3/4] Installing dependencies (this can take a while)...
pip install -r requirements.txt

echo [4/4] Checking for Ollama...
where ollama >nul 2>&1
if errorlevel 1 (
    echo [WARNING] Ollama not found on PATH.
    echo Download it from https://ollama.com/download and re-run this script.
) else (
    echo Pulling default model: qwen3:4b
    ollama pull qwen3:4b
)

if not exist database mkdir database
if not exist logs mkdir logs
if not exist plugins\user mkdir plugins\user

echo.
echo Setup complete. Run JARVIS with run.bat
endlocal
