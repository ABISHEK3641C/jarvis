"""
plugins/plugin_manager.py
----------------------------
Discovers plugin modules in the configured directories, instantiates each
BasePlugin subclass found, and exposes a flat tool registry to the
orchestrator. Supports hot reload via `watchdog` so dropping a new plugin
file into plugins/user works without restarting JARVIS.
"""
from __future__ import annotations

import asyncio
import importlib
import importlib.util
import inspect
import sys
from pathlib import Path
from typing import Any, Optional

from core.config import CONFIG
from core.logger import get_logger
from plugins.base_plugin import BasePlugin, ToolSpec

log = get_logger("plugins.manager")


class PluginManager:
    def __init__(self):
        self.plugins: dict[str, BasePlugin] = {}
        self.tools: dict[str, ToolSpec] = {}
        self._observer = None

    # --------------------------------------------------------- discovery
    def load_all(self) -> None:
        dirs = [
            CONFIG.resolve_path(CONFIG.plugins.enabled_dir),
            CONFIG.resolve_path(CONFIG.plugins.user_dir),
        ]
        for d in dirs:
            if d.exists():
                self._load_dir(d)
        log.info(
            "Loaded %d plugin(s) exposing %d tool(s): %s",
            len(self.plugins),
            len(self.tools),
            ", ".join(sorted(self.tools)) or "none",
        )

    def _load_dir(self, directory: Path) -> None:
        for py_file in sorted(directory.glob("*.py")):
            if py_file.stem.startswith("_"):
                continue
            self._load_file(py_file)

    def _load_file(self, py_file: Path) -> None:
        module_name = f"jarvis_plugin_{py_file.stem}"
        try:
            spec = importlib.util.spec_from_file_location(module_name, py_file)
            if spec is None or spec.loader is None:
                return
            module = importlib.util.module_from_spec(spec)
            sys.modules[module_name] = module
            spec.loader.exec_module(module)

            for _, obj in inspect.getmembers(module, inspect.isclass):
                if issubclass(obj, BasePlugin) and obj is not BasePlugin:
                    if obj.name in CONFIG.plugins.disabled:
                        log.info("Skipping disabled plugin: %s", obj.name)
                        continue
                    self._register_plugin(obj())
        except Exception as exc:  # noqa: BLE001
            log.error("Failed to load plugin %s: %s", py_file.name, exc)

    def _register_plugin(self, plugin: BasePlugin) -> None:
        self.plugins[plugin.name] = plugin
        for tool_name, tool_spec in plugin.tools.items():
            if tool_name in self.tools:
                log.warning("Tool name collision: %s (overwriting)", tool_name)
            self.tools[tool_name] = tool_spec
        log.info("Registered plugin '%s' with tools: %s", plugin.name, list(plugin.tools))

    # --------------------------------------------------------- execution
    async def execute(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        if tool_name not in self.tools:
            return {"error": f"Unknown tool '{tool_name}'"}
        handler = self.tools[tool_name].handler
        try:
            if inspect.iscoroutinefunction(handler):
                return await handler(**arguments)
            loop = asyncio.get_event_loop()
            return await loop.run_in_executor(None, lambda: handler(**arguments))
        except Exception as exc:  # noqa: BLE001
            log.error("Tool '%s' raised: %s", tool_name, exc)
            return {"error": str(exc)}

    def ollama_schemas(self) -> list[dict[str, Any]]:
        return [t.to_ollama_schema() for t in self.tools.values()]

    # ------------------------------------------------------- hot reload
    def enable_hot_reload(self) -> None:
        if not CONFIG.plugins.hot_reload:
            return
        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler
        except ImportError:
            log.warning("watchdog not installed; hot reload disabled.")
            return

        manager = self

        class Handler(FileSystemEventHandler):
            def on_created(self, event):
                if event.src_path.endswith(".py"):
                    log.info("New plugin file detected: %s", event.src_path)
                    manager._load_file(Path(event.src_path))

            def on_modified(self, event):
                if event.src_path.endswith(".py"):
                    log.info("Plugin file changed, reloading: %s", event.src_path)
                    manager._load_file(Path(event.src_path))

        self._observer = Observer()
        user_dir = CONFIG.resolve_path(CONFIG.plugins.user_dir)
        user_dir.mkdir(parents=True, exist_ok=True)
        self._observer.schedule(Handler(), str(user_dir), recursive=False)
        self._observer.start()
        log.info("Hot reload watching %s", user_dir)

    def stop(self) -> None:
        if self._observer:
            self._observer.stop()
            self._observer.join()
