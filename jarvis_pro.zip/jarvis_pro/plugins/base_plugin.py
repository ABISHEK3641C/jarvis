"""
plugins/base_plugin.py
------------------------
Every JARVIS plugin subclasses BasePlugin and exposes one or more tools.
A "tool" is a single callable function the LLM can invoke; a plugin is a
grouping of related tools (e.g. "file_manager" plugin exposes search_files,
move_file, delete_file, ...).

Plugins are auto-discovered from plugins/builtin and plugins/user by the
PluginManager, so adding a new capability means dropping a new file in
one of those folders — no core code changes required.
"""
from __future__ import annotations

import inspect
from dataclasses import dataclass, field
from typing import Any, Callable, get_type_hints


@dataclass
class ToolSpec:
    name: str
    description: str
    handler: Callable[..., Any]
    parameters: dict[str, Any] = field(default_factory=dict)

    def to_ollama_schema(self) -> dict[str, Any]:
        """Convert to the OpenAI/Ollama function-calling JSON schema."""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters or {
                    "type": "object",
                    "properties": {},
                    "required": [],
                },
            },
        }


class BasePlugin:
    """Subclass this and register tools with @self.tool(...) in setup()."""

    name: str = "base_plugin"
    description: str = ""

    def __init__(self):
        self._tools: dict[str, ToolSpec] = {}
        self.setup()

    def setup(self) -> None:
        """Override in subclasses to register tools via self.register_tool(...)."""
        raise NotImplementedError

    def register_tool(
        self,
        name: str,
        description: str,
        handler: Callable[..., Any],
        parameters: dict[str, Any] | None = None,
    ) -> None:
        self._tools[name] = ToolSpec(
            name=name, description=description, handler=handler, parameters=parameters or {}
        )

    @property
    def tools(self) -> dict[str, ToolSpec]:
        return self._tools

    def ollama_schemas(self) -> list[dict[str, Any]]:
        return [t.to_ollama_schema() for t in self._tools.values()]
