"""
plugins/user/example_plugin.py
----------------------------------
Drop-in example showing how to add your own JARVIS capability. Any .py
file placed in plugins/user/ containing a BasePlugin subclass is picked
up automatically (and hot-reloaded if you edit it while JARVIS is
running) — no core code changes needed.

Delete or edit this file freely; it's just a template.
"""
from __future__ import annotations

from plugins.base_plugin import BasePlugin


class GreetingPlugin(BasePlugin):
    name = "greeting_example"
    description = "Example plugin: greets the user by name."

    def setup(self) -> None:
        self.register_tool(
            "greet_user",
            "Greet a person by name in a friendly, JARVIS-style way.",
            self.greet_user,
            {
                "type": "object",
                "properties": {"name": {"type": "string", "description": "Name of the person to greet"}},
                "required": ["name"],
            },
        )

    def greet_user(self, name: str) -> dict:
        return {"status": "ok", "message": f"Good to see you, {name}. All systems are ready."}
