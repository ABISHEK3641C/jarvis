"""
plugins/builtin/file_manager.py
----------------------------------
File-system tools: search, move, copy, rename, delete, create folders,
and zip/unzip. All destructive operations are logged.
"""
from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from typing import Optional

from core.logger import get_logger
from plugins.base_plugin import BasePlugin

log = get_logger("plugins.file_manager")


class FileManagerPlugin(BasePlugin):
    name = "file_manager"
    description = "Search, move, copy, rename, delete files and folders; zip/unzip archives."

    def setup(self) -> None:
        self.register_tool(
            "search_files",
            "Search for files matching a name pattern under a root directory.",
            self.search_files,
            {
                "type": "object",
                "properties": {
                    "pattern": {"type": "string", "description": "Glob pattern, e.g. '*.pdf' or 'report*'"},
                    "root": {"type": "string", "description": "Directory to search under"},
                },
                "required": ["pattern", "root"],
            },
        )
        self.register_tool(
            "move_file",
            "Move a file or folder from one path to another.",
            self.move_file,
            {
                "type": "object",
                "properties": {"source": {"type": "string"}, "destination": {"type": "string"}},
                "required": ["source", "destination"],
            },
        )
        self.register_tool(
            "copy_file",
            "Copy a file or folder from one path to another.",
            self.copy_file,
            {
                "type": "object",
                "properties": {"source": {"type": "string"}, "destination": {"type": "string"}},
                "required": ["source", "destination"],
            },
        )
        self.register_tool(
            "rename_file",
            "Rename a file or folder.",
            self.rename_file,
            {
                "type": "object",
                "properties": {"path": {"type": "string"}, "new_name": {"type": "string"}},
                "required": ["path", "new_name"],
            },
        )
        self.register_tool(
            "delete_file",
            "Delete a file or folder (folders are removed recursively).",
            self.delete_file,
            {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]},
        )
        self.register_tool(
            "create_folder",
            "Create a new folder, including any missing parent directories.",
            self.create_folder,
            {"type": "object", "properties": {"path": {"type": "string"}}, "required": ["path"]},
        )
        self.register_tool(
            "compress_zip",
            "Compress a file or folder into a .zip archive.",
            self.compress_zip,
            {
                "type": "object",
                "properties": {"source": {"type": "string"}, "zip_path": {"type": "string"}},
                "required": ["source", "zip_path"],
            },
        )
        self.register_tool(
            "extract_zip",
            "Extract a .zip archive to a destination folder.",
            self.extract_zip,
            {
                "type": "object",
                "properties": {"zip_path": {"type": "string"}, "destination": {"type": "string"}},
                "required": ["zip_path", "destination"],
            },
        )

    # ------------------------------------------------------------------
    def search_files(self, pattern: str, root: str) -> dict:
        root_path = Path(root).expanduser()
        if not root_path.exists():
            return {"status": "error", "message": f"Root path does not exist: {root}"}
        matches = [str(p) for p in root_path.rglob(pattern)]
        return {"status": "ok", "matches": matches[:100], "count": len(matches)}

    def move_file(self, source: str, destination: str) -> dict:
        try:
            shutil.move(source, destination)
            log.info("Moved %s -> %s", source, destination)
            return {"status": "ok", "message": f"Moved to {destination}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def copy_file(self, source: str, destination: str) -> dict:
        try:
            src_path = Path(source)
            if src_path.is_dir():
                shutil.copytree(source, destination, dirs_exist_ok=True)
            else:
                shutil.copy2(source, destination)
            log.info("Copied %s -> %s", source, destination)
            return {"status": "ok", "message": f"Copied to {destination}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def rename_file(self, path: str, new_name: str) -> dict:
        try:
            p = Path(path)
            target = p.with_name(new_name)
            p.rename(target)
            return {"status": "ok", "message": f"Renamed to {target}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def delete_file(self, path: str) -> dict:
        try:
            p = Path(path)
            if p.is_dir():
                shutil.rmtree(p)
            else:
                p.unlink()
            log.info("Deleted %s", path)
            return {"status": "ok", "message": f"Deleted {path}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def create_folder(self, path: str) -> dict:
        try:
            Path(path).mkdir(parents=True, exist_ok=True)
            return {"status": "ok", "message": f"Folder ready at {path}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def compress_zip(self, source: str, zip_path: str) -> dict:
        try:
            src = Path(source)
            with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
                if src.is_dir():
                    for file in src.rglob("*"):
                        if file.is_file():
                            zf.write(file, file.relative_to(src.parent))
                else:
                    zf.write(src, src.name)
            return {"status": "ok", "message": f"Compressed to {zip_path}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def extract_zip(self, zip_path: str, destination: str) -> dict:
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(destination)
            return {"status": "ok", "message": f"Extracted to {destination}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}
