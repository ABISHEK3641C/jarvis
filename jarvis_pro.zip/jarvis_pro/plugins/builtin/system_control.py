"""
plugins/builtin/system_control.py
------------------------------------
Desktop automation: launch/close applications, power actions, volume,
screenshots. Uses only the standard library plus `psutil` and `pyautogui`
so it works cross-platform, with Windows-specific power commands guarded
behind an OS check.
"""
from __future__ import annotations

import os
import platform
import subprocess
import time
from pathlib import Path
from typing import Optional

import psutil

from core.config import CONFIG
from core.logger import get_logger
from plugins.base_plugin import BasePlugin

log = get_logger("plugins.system_control")

# Common app-name -> launch-command aliases (extend freely).
APP_ALIASES = {
    "chrome": {"windows": "chrome", "darwin": "open -a 'Google Chrome'", "linux": "google-chrome"},
    "notepad": {"windows": "notepad", "darwin": "open -a TextEdit", "linux": "gedit"},
    "calculator": {"windows": "calc", "darwin": "open -a Calculator", "linux": "gnome-calculator"},
    "explorer": {"windows": "explorer", "darwin": "open .", "linux": "nautilus"},
    "vscode": {"windows": "code", "darwin": "open -a 'Visual Studio Code'", "linux": "code"},
    "spotify": {"windows": "spotify", "darwin": "open -a Spotify", "linux": "spotify"},
    "word": {"windows": "winword", "darwin": "open -a 'Microsoft Word'", "linux": "libreoffice --writer"},
    "excel": {"windows": "excel", "darwin": "open -a 'Microsoft Excel'", "linux": "libreoffice --calc"},
}


def _os_key() -> str:
    system = platform.system().lower()
    if system.startswith("win"):
        return "windows"
    if system == "darwin":
        return "darwin"
    return "linux"


class SystemControlPlugin(BasePlugin):
    name = "system_control"
    description = "Open/close applications and control the desktop (power, volume, screenshots)."

    def setup(self) -> None:
        self.register_tool(
            "open_application",
            "Open a desktop application by name, e.g. 'chrome', 'notepad', 'vscode'.",
            self.open_application,
            {
                "type": "object",
                "properties": {"app_name": {"type": "string", "description": "Name of the app to open"}},
                "required": ["app_name"],
            },
        )
        self.register_tool(
            "close_application",
            "Close a running application by process name, e.g. 'chrome.exe' or 'notepad'.",
            self.close_application,
            {
                "type": "object",
                "properties": {"app_name": {"type": "string", "description": "Process name to terminate"}},
                "required": ["app_name"],
            },
        )
        self.register_tool(
            "system_power_action",
            "Perform a power action on this PC: shutdown, restart, sleep, or lock.",
            self.system_power_action,
            {
                "type": "object",
                "properties": {
                    "action": {
                        "type": "string",
                        "enum": ["shutdown", "restart", "sleep", "lock"],
                    }
                },
                "required": ["action"],
            },
        )
        self.register_tool(
            "take_screenshot",
            "Capture the current screen and save it as a PNG file.",
            self.take_screenshot,
            {
                "type": "object",
                "properties": {"save_path": {"type": "string", "description": "Optional output path"}},
                "required": [],
            },
        )
        self.register_tool(
            "set_volume",
            "Set the system volume to a percentage (0-100).",
            self.set_volume,
            {
                "type": "object",
                "properties": {"level": {"type": "integer", "minimum": 0, "maximum": 100}},
                "required": ["level"],
            },
        )

    # ------------------------------------------------------------------
    def open_application(self, app_name: str) -> dict:
        key = _os_key()
        alias = APP_ALIASES.get(app_name.lower())
        command = alias[key] if alias else app_name

        try:
            if key == "windows":
                os.startfile(command)  # type: ignore[attr-defined]
            else:
                subprocess.Popen(command, shell=True)
            log.info("Opened application: %s", app_name)
            return {"status": "ok", "message": f"Opening {app_name}."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": f"Could not open {app_name}: {exc}"}

    def close_application(self, app_name: str) -> dict:
        closed = []
        target = app_name.lower().replace(".exe", "")
        for proc in psutil.process_iter(["pid", "name"]):
            proc_name = (proc.info.get("name") or "").lower().replace(".exe", "")
            if target in proc_name:
                try:
                    proc.terminate()
                    closed.append(proc.info["name"])
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        if closed:
            return {"status": "ok", "message": f"Closed: {', '.join(closed)}"}
        return {"status": "error", "message": f"No running process matched '{app_name}'."}

    def system_power_action(self, action: str) -> dict:
        key = _os_key()
        commands = {
            "windows": {
                "shutdown": "shutdown /s /t 5",
                "restart": "shutdown /r /t 5",
                "sleep": "rundll32.exe powrprof.dll,SetSuspendState 0,1,0",
                "lock": "rundll32.exe user32.dll,LockWorkStation",
            },
            "darwin": {
                "shutdown": "osascript -e 'tell app \"System Events\" to shut down'",
                "restart": "osascript -e 'tell app \"System Events\" to restart'",
                "sleep": "pmset sleepnow",
                "lock": "/System/Library/CoreServices/Menu\\ Extras/User.menu/Contents/Resources/CGSession -suspend",
            },
            "linux": {
                "shutdown": "systemctl poweroff",
                "restart": "systemctl reboot",
                "sleep": "systemctl suspend",
                "lock": "loginctl lock-session",
            },
        }
        cmd = commands.get(key, {}).get(action)
        if not cmd:
            return {"status": "error", "message": f"Unsupported action '{action}' on this OS."}
        try:
            subprocess.Popen(cmd, shell=True)
            return {"status": "ok", "message": f"{action.capitalize()} initiated."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def take_screenshot(self, save_path: Optional[str] = None) -> dict:
        try:
            import pyautogui

            shots_dir = CONFIG.resolve_path("database/screenshots")
            shots_dir.mkdir(parents=True, exist_ok=True)
            out = Path(save_path) if save_path else shots_dir / f"screenshot_{int(time.time())}.png"
            img = pyautogui.screenshot()
            img.save(out)
            return {"status": "ok", "path": str(out)}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def set_volume(self, level: int) -> dict:
        level = max(0, min(100, level))
        key = _os_key()
        try:
            if key == "windows":
                # Requires 'nircmd' or pycaw; fall back to a documented no-op with guidance.
                try:
                    from ctypes import cast, POINTER
                    from comtypes import CLSCTX_ALL
                    from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

                    devices = AudioUtilities.GetSpeakers()
                    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                    volume = cast(interface, POINTER(IAudioEndpointVolume))
                    volume.SetMasterVolumeLevelScalar(level / 100.0, None)
                except ImportError:
                    return {
                        "status": "error",
                        "message": "pycaw/comtypes not installed; run `pip install pycaw comtypes`.",
                    }
            elif key == "darwin":
                subprocess.run(["osascript", "-e", f"set volume output volume {level}"], check=True)
            else:
                subprocess.run(["amixer", "-D", "pulse", "sset", "Master", f"{level}%"], check=True)
            return {"status": "ok", "message": f"Volume set to {level}%."}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}
