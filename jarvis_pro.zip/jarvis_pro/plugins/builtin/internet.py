"""
plugins/builtin/internet.py
-------------------------------
Lightweight internet-lookup tools using free, keyless APIs where possible
(Open-Meteo for weather, exchangerate.host for currency, Wikipedia REST
API for summaries) so JARVIS works out of the box without API key setup.
"""
from __future__ import annotations

import requests

from core.logger import get_logger
from plugins.base_plugin import BasePlugin

log = get_logger("plugins.internet")


class InternetPlugin(BasePlugin):
    name = "internet"
    description = "Weather, currency conversion, and Wikipedia lookups."

    def setup(self) -> None:
        self.register_tool(
            "get_weather",
            "Get current weather for a city.",
            self.get_weather,
            {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]},
        )
        self.register_tool(
            "convert_currency",
            "Convert an amount between currencies, e.g. USD to INR.",
            self.convert_currency,
            {
                "type": "object",
                "properties": {
                    "amount": {"type": "number"},
                    "from_currency": {"type": "string"},
                    "to_currency": {"type": "string"},
                },
                "required": ["amount", "from_currency", "to_currency"],
            },
        )
        self.register_tool(
            "wikipedia_summary",
            "Get a short Wikipedia summary of a topic.",
            self.wikipedia_summary,
            {"type": "object", "properties": {"topic": {"type": "string"}}, "required": ["topic"]},
        )

    # ------------------------------------------------------------------
    def get_weather(self, city: str) -> dict:
        try:
            geo = requests.get(
                "https://geocoding-api.open-meteo.com/v1/search",
                params={"name": city, "count": 1},
                timeout=10,
            ).json()
            results = geo.get("results")
            if not results:
                return {"status": "error", "message": f"Could not find location '{city}'."}
            lat, lon = results[0]["latitude"], results[0]["longitude"]

            weather = requests.get(
                "https://api.open-meteo.com/v1/forecast",
                params={"latitude": lat, "longitude": lon, "current_weather": True},
                timeout=10,
            ).json()
            current = weather.get("current_weather", {})
            return {
                "status": "ok",
                "city": results[0]["name"],
                "temperature_c": current.get("temperature"),
                "windspeed_kmh": current.get("windspeed"),
            }
        except requests.RequestException as exc:
            return {"status": "error", "message": str(exc)}

    def convert_currency(self, amount: float, from_currency: str, to_currency: str) -> dict:
        try:
            resp = requests.get(
                f"https://api.exchangerate.host/convert",
                params={"from": from_currency.upper(), "to": to_currency.upper(), "amount": amount},
                timeout=10,
            ).json()
            return {"status": "ok", "result": resp.get("result"), "info": resp.get("info")}
        except requests.RequestException as exc:
            return {"status": "error", "message": str(exc)}

    def wikipedia_summary(self, topic: str) -> dict:
        try:
            resp = requests.get(
                f"https://en.wikipedia.org/api/rest_v1/page/summary/{topic.replace(' ', '_')}",
                timeout=10,
            )
            if resp.status_code != 200:
                return {"status": "error", "message": f"No Wikipedia page found for '{topic}'."}
            data = resp.json()
            return {"status": "ok", "title": data.get("title"), "summary": data.get("extract")}
        except requests.RequestException as exc:
            return {"status": "error", "message": str(exc)}
