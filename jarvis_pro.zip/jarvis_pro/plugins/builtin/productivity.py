"""
plugins/builtin/productivity.py
-----------------------------------
Notes, reminders, and a simple calculator/unit converter. Notes and
reminders persist via the shared MemoryManager (SQLite), so they survive
restarts and are semantically searchable.
"""
from __future__ import annotations

import time
from datetime import datetime, timedelta

from core.logger import get_logger
from memory.memory_manager import MemoryManager
from plugins.base_plugin import BasePlugin

log = get_logger("plugins.productivity")

# Minimal, safe unit conversion table (length + weight + temperature handled specially)
_LENGTH_TO_M = {"mm": 0.001, "cm": 0.01, "m": 1.0, "km": 1000.0, "in": 0.0254, "ft": 0.3048, "mi": 1609.34}
_WEIGHT_TO_KG = {"g": 0.001, "kg": 1.0, "lb": 0.453592, "oz": 0.0283495}


class ProductivityPlugin(BasePlugin):
    name = "productivity"
    description = "Notes, reminders, calculator, and unit conversion."

    def __init__(self, memory: MemoryManager | None = None):
        self.memory = memory or MemoryManager()
        super().__init__()

    def setup(self) -> None:
        self.register_tool(
            "add_note",
            "Save a note for later.",
            self.add_note,
            {
                "type": "object",
                "properties": {"content": {"type": "string"}, "title": {"type": "string"}},
                "required": ["content"],
            },
        )
        self.register_tool(
            "list_notes",
            "List saved notes, most recent first.",
            self.list_notes,
            {"type": "object", "properties": {"limit": {"type": "integer"}}, "required": []},
        )
        self.register_tool(
            "set_reminder",
            "Set a reminder that fires after a number of minutes from now.",
            self.set_reminder,
            {
                "type": "object",
                "properties": {
                    "text": {"type": "string"},
                    "minutes_from_now": {"type": "number"},
                },
                "required": ["text", "minutes_from_now"],
            },
        )
        self.register_tool(
            "check_due_reminders",
            "Check which reminders are currently due.",
            self.check_due_reminders,
            {"type": "object", "properties": {}, "required": []},
        )
        self.register_tool(
            "calculate",
            "Evaluate a basic arithmetic expression, e.g. '(12 + 4) * 3 / 2'.",
            self.calculate,
            {"type": "object", "properties": {"expression": {"type": "string"}}, "required": ["expression"]},
        )
        self.register_tool(
            "convert_units",
            "Convert a value between units of length or weight (e.g. km->mi, kg->lb).",
            self.convert_units,
            {
                "type": "object",
                "properties": {
                    "value": {"type": "number"},
                    "from_unit": {"type": "string"},
                    "to_unit": {"type": "string"},
                },
                "required": ["value", "from_unit", "to_unit"],
            },
        )

    # ------------------------------------------------------------------
    def add_note(self, content: str, title: str = "") -> dict:
        note_id = self.memory.add_note(content, title)
        return {"status": "ok", "note_id": note_id}

    def list_notes(self, limit: int = 20) -> dict:
        return {"status": "ok", "notes": self.memory.list_notes(limit)}

    def set_reminder(self, text: str, minutes_from_now: float) -> dict:
        due = time.time() + minutes_from_now * 60
        reminder_id = self.memory.add_reminder(text, due)
        due_str = (datetime.now() + timedelta(minutes=minutes_from_now)).strftime("%H:%M")
        return {"status": "ok", "reminder_id": reminder_id, "due_at": due_str}

    def check_due_reminders(self) -> dict:
        due = self.memory.due_reminders()
        for r in due:
            self.memory.complete_reminder(r["id"])
        return {"status": "ok", "due_reminders": due}

    def calculate(self, expression: str) -> dict:
        allowed = set("0123456789+-*/(). ")
        if not set(expression) <= allowed:
            return {"status": "error", "message": "Expression contains disallowed characters."}
        try:
            result = eval(expression, {"__builtins__": {}}, {})  # noqa: S307 (sandboxed charset)
            return {"status": "ok", "result": result}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}

    def convert_units(self, value: float, from_unit: str, to_unit: str) -> dict:
        f, t = from_unit.lower(), to_unit.lower()
        try:
            if f in _LENGTH_TO_M and t in _LENGTH_TO_M:
                result = value * _LENGTH_TO_M[f] / _LENGTH_TO_M[t]
            elif f in _WEIGHT_TO_KG and t in _WEIGHT_TO_KG:
                result = value * _WEIGHT_TO_KG[f] / _WEIGHT_TO_KG[t]
            elif {f, t} == {"c", "f"}:
                result = (value * 9 / 5 + 32) if f == "c" else (value - 32) * 5 / 9
            elif f == t:
                result = value
            else:
                return {"status": "error", "message": f"Unsupported unit pair: {from_unit} -> {to_unit}"}
            return {"status": "ok", "result": round(result, 4)}
        except Exception as exc:  # noqa: BLE001
            return {"status": "error", "message": str(exc)}
