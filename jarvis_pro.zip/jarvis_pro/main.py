"""
main.py
--------
JARVIS Pro entry point. Boots the async runtime (LLM + memory + plugins),
the Qt GUI, the system tray, and the background voice loop, then hands
control to Qt's event loop.

Run with:  python main.py
"""
from __future__ import annotations

import sys

from PySide6.QtWidgets import QApplication

from core.app_runtime import AppRuntime
from core.config import CONFIG
from core.logger import get_logger
from gui.main_window import MainWindow
from gui.tray import TrayIcon

log = get_logger("main")


def main() -> int:
    log.info("Starting %s v%s", CONFIG.app.name, CONFIG.app.version)

    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)  # keep running in system tray

    runtime = AppRuntime()
    runtime.start()

    window = MainWindow(runtime)
    if not CONFIG.gui.start_minimized:
        window.show()

    tray = TrayIcon(window, app)

    # Voice loop is optional at startup — mic/audio deps may not be present
    # in every environment, so failures here are logged, not fatal.
    voice_loop = None
    try:
        from core.voice_loop import VoiceLoop
        import asyncio

        voice_loop = VoiceLoop(runtime.orchestrator, event_loop=runtime._loop)  # noqa: SLF001
        voice_loop.start()
        log.info("Voice loop active — say a wake word to talk to JARVIS.")
    except Exception as exc:  # noqa: BLE001
        log.warning("Voice loop not started (%s). Text chat still works.", exc)

    exit_code = app.exec()

    if voice_loop:
        voice_loop.stop()
    runtime.stop()
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
