"""
memory/memory_manager.py
--------------------------
Public API used by the rest of the app. Combines short-term (SQLite recent
turns), long-term structured (facts/notes/reminders), and semantic
(FAISS-backed) memory into one interface.

If FAISS / sentence-transformers aren't installed, semantic recall
gracefully degrades to keyword search over recent conversation history
rather than crashing the whole assistant.
"""
from __future__ import annotations

from typing import Any, Optional

from core.config import CONFIG
from core.logger import get_logger
from memory.database import Database

log = get_logger("memory.manager")


class MemoryManager:
    def __init__(self):
        self.db = Database()
        self._vector_store = None
        self._semantic_enabled = True
        try:
            from memory.vector_store import VectorStore

            self._vector_store = VectorStore()
        except Exception as exc:  # noqa: BLE001
            log.warning("Semantic memory disabled (%s). Falling back to keyword recall.", exc)
            self._semantic_enabled = False

    # ------------------------------------------------------- conversation
    def remember_turn(self, role: str, content: str) -> None:
        source_id = self.db.add_turn(role, content)
        self._index_text(content, "conversations", source_id)

    def recent_context(self, limit: Optional[int] = None) -> list[dict[str, Any]]:
        limit = limit or CONFIG.memory.max_short_term_turns
        return self.db.recent_turns(limit)

    # -------------------------------------------------------------- facts
    def remember_fact(self, key: str, value: str, category: str = "general") -> None:
        source_id = self.db.set_fact(key, value, category)
        self._index_text(f"{key}: {value}", "facts", source_id)
        log.info("Stored fact: %s = %s", key, value)

    def recall_fact(self, key: str) -> Optional[str]:
        return self.db.get_fact(key)

    def forget_fact(self, key: str) -> bool:
        return self.db.delete_fact(key)

    def all_facts(self) -> list[dict[str, Any]]:
        return self.db.all_facts()

    # -------------------------------------------------------------- notes
    def add_note(self, content: str, title: str = "") -> int:
        note_id = self.db.add_note(content, title)
        self._index_text(content, "notes", note_id)
        return note_id

    def list_notes(self, limit: int = 50) -> list[dict[str, Any]]:
        return self.db.list_notes(limit)

    def delete_note(self, note_id: int) -> bool:
        return self.db.delete_note(note_id)

    # --------------------------------------------------------- reminders
    def add_reminder(self, text: str, due_time: float) -> int:
        return self.db.add_reminder(text, due_time)

    def due_reminders(self) -> list[dict[str, Any]]:
        return self.db.due_reminders()

    def complete_reminder(self, reminder_id: int) -> None:
        self.db.complete_reminder(reminder_id)

    # ------------------------------------------------------------ recall
    def semantic_recall(self, query: str, top_k: Optional[int] = None) -> list[dict[str, Any]]:
        """Return the most relevant remembered snippets for `query`."""
        top_k = top_k or CONFIG.memory.top_k_recall

        if self._semantic_enabled and self._vector_store is not None:
            hits = self._vector_store.search(query, top_k)
            vector_ids = [vid for vid, _ in hits]
            rows = self.db.get_vector_texts(vector_ids)
            return rows

        # Fallback: naive keyword match over recent turns
        query_terms = {t.lower() for t in query.split() if len(t) > 2}
        matches = []
        for turn in self.db.recent_turns(200):
            content_lower = turn["content"].lower()
            if any(term in content_lower for term in query_terms):
                matches.append({"text": turn["content"], "source_table": "conversations"})
        return matches[-top_k:]

    def _index_text(self, text: str, source_table: str, source_id: int) -> None:
        if not (self._semantic_enabled and self._vector_store is not None):
            return
        try:
            vector_id = self._vector_store.add(text)
            self.db.link_vector(vector_id, source_table, source_id, text)
            self._vector_store.save()
        except Exception as exc:  # noqa: BLE001
            log.warning("Failed to index text for semantic recall: %s", exc)
