"""
memory/database.py
-------------------
SQLite persistence layer. Stores conversation turns, long-term facts,
reminders, and notes. FAISS (vector_store.py) stores embeddings that
reference rows here by id for semantic recall.
"""
from __future__ import annotations

import sqlite3
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Iterator, Optional

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("memory.database")

SCHEMA = """
CREATE TABLE IF NOT EXISTS conversations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,               -- 'user' | 'assistant'
    content TEXT NOT NULL,
    timestamp REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS facts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    category TEXT DEFAULT 'general',
    timestamp REAL NOT NULL,
    UNIQUE(key)
);

CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    content TEXT NOT NULL,
    timestamp REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS reminders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    due_time REAL NOT NULL,
    completed INTEGER DEFAULT 0,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS vector_map (
    vector_id INTEGER PRIMARY KEY,    -- position in the FAISS index
    source_table TEXT NOT NULL,       -- 'conversations' | 'facts' | 'notes'
    source_id INTEGER NOT NULL,
    text TEXT NOT NULL,
    timestamp REAL NOT NULL
);
"""


class Database:
    def __init__(self, db_path: Optional[Path] = None):
        self.path = db_path or CONFIG.resolve_path(CONFIG.memory.db_path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._init_schema()

    @contextmanager
    def connect(self) -> Iterator[sqlite3.Connection]:
        conn = sqlite3.connect(str(self.path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        finally:
            conn.close()

    def _init_schema(self) -> None:
        with self.connect() as conn:
            conn.executescript(SCHEMA)
        log.info("Database schema ready at %s", self.path)

    # ---------------------------------------------------------------- turns
    def add_turn(self, role: str, content: str) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO conversations (role, content, timestamp) VALUES (?, ?, ?)",
                (role, content, time.time()),
            )
            return cur.lastrowid

    def recent_turns(self, limit: int = 20) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT role, content, timestamp FROM conversations "
                "ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in reversed(rows)]

    # ---------------------------------------------------------------- facts
    def set_fact(self, key: str, value: str, category: str = "general") -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO facts (key, value, category, timestamp) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(key) DO UPDATE SET value=excluded.value, timestamp=excluded.timestamp",
                (key, value, category, time.time()),
            )
            return cur.lastrowid

    def get_fact(self, key: str) -> Optional[str]:
        with self.connect() as conn:
            row = conn.execute("SELECT value FROM facts WHERE key = ?", (key,)).fetchone()
        return row["value"] if row else None

    def delete_fact(self, key: str) -> bool:
        with self.connect() as conn:
            cur = conn.execute("DELETE FROM facts WHERE key = ?", (key,))
        return cur.rowcount > 0

    def all_facts(self) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute("SELECT key, value, category FROM facts").fetchall()
        return [dict(r) for r in rows]

    # ---------------------------------------------------------------- notes
    def add_note(self, content: str, title: str = "") -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO notes (title, content, timestamp) VALUES (?, ?, ?)",
                (title, content, time.time()),
            )
            return cur.lastrowid

    def list_notes(self, limit: int = 50) -> list[dict[str, Any]]:
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id, title, content, timestamp FROM notes ORDER BY id DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def delete_note(self, note_id: int) -> bool:
        with self.connect() as conn:
            cur = conn.execute("DELETE FROM notes WHERE id = ?", (note_id,))
        return cur.rowcount > 0

    # ----------------------------------------------------------- reminders
    def add_reminder(self, text: str, due_time: float) -> int:
        with self.connect() as conn:
            cur = conn.execute(
                "INSERT INTO reminders (text, due_time, created_at) VALUES (?, ?, ?)",
                (text, due_time, time.time()),
            )
            return cur.lastrowid

    def due_reminders(self, now: Optional[float] = None) -> list[dict[str, Any]]:
        now = now if now is not None else time.time()
        with self.connect() as conn:
            rows = conn.execute(
                "SELECT id, text, due_time FROM reminders "
                "WHERE completed = 0 AND due_time <= ?",
                (now,),
            ).fetchall()
        return [dict(r) for r in rows]

    def complete_reminder(self, reminder_id: int) -> None:
        with self.connect() as conn:
            conn.execute(
                "UPDATE reminders SET completed = 1 WHERE id = ?", (reminder_id,)
            )

    # ------------------------------------------------------------- vectors
    def link_vector(self, vector_id: int, source_table: str, source_id: int, text: str) -> None:
        with self.connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO vector_map (vector_id, source_table, source_id, text, timestamp) "
                "VALUES (?, ?, ?, ?, ?)",
                (vector_id, source_table, source_id, text, time.time()),
            )

    def get_vector_texts(self, vector_ids: list[int]) -> list[dict[str, Any]]:
        if not vector_ids:
            return []
        placeholders = ",".join("?" * len(vector_ids))
        with self.connect() as conn:
            rows = conn.execute(
                f"SELECT vector_id, source_table, source_id, text, timestamp "
                f"FROM vector_map WHERE vector_id IN ({placeholders})",
                vector_ids,
            ).fetchall()
        by_id = {r["vector_id"]: dict(r) for r in rows}
        return [by_id[v] for v in vector_ids if v in by_id]
