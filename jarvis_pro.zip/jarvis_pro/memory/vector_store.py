"""
memory/vector_store.py
-----------------------
Thin wrapper around FAISS for storing and querying sentence embeddings.
Embeddings come from sentence-transformers (all-MiniLM-L6-v2 by default).
The index is flat L2 for simplicity and correctness at the scale a
personal-assistant memory store operates at (thousands, not millions).
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("memory.vector_store")

try:
    import faiss  # type: ignore
except ImportError:  # pragma: no cover
    faiss = None

try:
    from sentence_transformers import SentenceTransformer
except ImportError:  # pragma: no cover
    SentenceTransformer = None  # type: ignore


class VectorStore:
    def __init__(self, index_path: Optional[Path] = None, dim: Optional[int] = None):
        if faiss is None:
            raise RuntimeError(
                "faiss is not installed. Run `pip install faiss-cpu` to enable "
                "semantic memory."
            )
        self.dim = dim or CONFIG.memory.embedding_dim
        self.index_path = index_path or CONFIG.resolve_path(CONFIG.memory.vector_index_path)
        self.index_path.parent.mkdir(parents=True, exist_ok=True)

        self._embedder: Optional["SentenceTransformer"] = None
        self.index = self._load_or_create_index()

    # ------------------------------------------------------------- setup
    def _load_or_create_index(self):
        if self.index_path.exists():
            log.info("Loading existing FAISS index from %s", self.index_path)
            return faiss.read_index(str(self.index_path))
        log.info("Creating new FAISS flat-L2 index (dim=%d)", self.dim)
        return faiss.IndexFlatL2(self.dim)

    @property
    def embedder(self) -> "SentenceTransformer":
        if self._embedder is None:
            if SentenceTransformer is None:
                raise RuntimeError(
                    "sentence-transformers is not installed. "
                    "Run `pip install sentence-transformers`."
                )
            self._embedder = SentenceTransformer(CONFIG.memory.embedding_model)
        return self._embedder

    def embed(self, text: str) -> np.ndarray:
        vec = self.embedder.encode([text], normalize_embeddings=True)
        return np.asarray(vec, dtype="float32")

    # -------------------------------------------------------------- write
    def add(self, text: str) -> int:
        """Embed `text`, add to index, return the new vector's id (its row index)."""
        vec = self.embed(text)
        vector_id = self.index.ntotal
        self.index.add(vec)
        return vector_id

    def save(self) -> None:
        faiss.write_index(self.index, str(self.index_path))
        log.debug("FAISS index persisted to %s", self.index_path)

    # --------------------------------------------------------------- read
    def search(self, query: str, top_k: int = 5) -> list[tuple[int, float]]:
        """Return [(vector_id, distance), ...] sorted by similarity (closer first)."""
        if self.index.ntotal == 0:
            return []
        vec = self.embed(query)
        k = min(top_k, self.index.ntotal)
        distances, indices = self.index.search(vec, k)
        results = [
            (int(idx), float(dist))
            for idx, dist in zip(indices[0], distances[0])
            if idx != -1
        ]
        return results
