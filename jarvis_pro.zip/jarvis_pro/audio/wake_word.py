"""
audio/wake_word.py
--------------------
Continuous microphone listener that triggers on configured wake words
("jarvis", "hey jarvis", "nova"). Uses openWakeWord if installed for a
proper low-latency keyword spotter; falls back to short-window
faster-whisper transcription matching if openWakeWord isn't available.
"""
from __future__ import annotations

import queue
import time
from typing import Callable, Optional

import numpy as np
import sounddevice as sd

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("audio.wake_word")


class WakeWordListener:
    def __init__(self, on_wake: Callable[[str], None]):
        self.on_wake = on_wake
        self.sample_rate = CONFIG.audio.sample_rate
        self.wake_words = [w.lower() for w in CONFIG.audio.wake_words]
        self._audio_q: "queue.Queue[np.ndarray]" = queue.Queue()
        self._running = False
        self._oww_model = None

    def _try_load_openwakeword(self) -> bool:
        try:
            from openwakeword.model import Model

            self._oww_model = Model(wakeword_models=["hey_jarvis"])
            return True
        except Exception as exc:  # noqa: BLE001
            log.info("openWakeWord unavailable (%s); using whisper-based fallback.", exc)
            return False

    def _audio_callback(self, indata, frames, time_info, status):  # noqa: ANN001
        if status:
            log.debug("Audio stream status: %s", status)
        self._audio_q.put(indata.copy().reshape(-1))

    def listen_forever(self) -> None:
        self._running = True
        use_oww = self._try_load_openwakeword()

        with sd.InputStream(
            samplerate=self.sample_rate,
            channels=1,
            dtype="float32",
            callback=self._audio_callback,
            blocksize=int(self.sample_rate * 0.08),
        ):
            log.info("Wake word listener active. Listening for: %s", self.wake_words)
            buffer = np.zeros(0, dtype=np.float32)
            window_seconds = 1.5

            while self._running:
                try:
                    chunk = self._audio_q.get(timeout=0.5)
                except queue.Empty:
                    continue

                buffer = np.concatenate([buffer, chunk])
                max_len = int(self.sample_rate * window_seconds)
                if len(buffer) > max_len:
                    buffer = buffer[-max_len:]

                if use_oww:
                    self._check_openwakeword(buffer)
                else:
                    self._check_whisper_fallback(buffer)

    def stop(self) -> None:
        self._running = False

    # ------------------------------------------------------------------
    def _check_openwakeword(self, buffer: np.ndarray) -> None:
        pcm16 = (buffer * 32767).astype(np.int16)
        predictions = self._oww_model.predict(pcm16)
        for name, score in predictions.items():
            if score > CONFIG.audio.wake_word_sensitivity:
                log.info("Wake word detected via openWakeWord: %s (%.2f)", name, score)
                self.on_wake(name)
                time.sleep(1.0)  # debounce

    def _check_whisper_fallback(self, buffer: np.ndarray) -> None:
        # Only run the (relatively expensive) transcription every ~1.5s window,
        # and only if there's meaningful signal energy (cheap gate).
        if np.abs(buffer).mean() < 0.01:
            return
        from audio.stt import SpeechToText

        if not hasattr(self, "_stt"):
            self._stt = SpeechToText()

        text = self._stt.transcribe(buffer).lower()
        for wake_word in self.wake_words:
            if wake_word in text:
                log.info("Wake word detected via whisper fallback: '%s' in '%s'", wake_word, text)
                self.on_wake(wake_word)
                time.sleep(1.0)  # debounce
                break
