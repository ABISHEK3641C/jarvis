"""
audio/stt.py
-------------
Speech-to-text using faster-whisper (CTranslate2-based Whisper, fast on
CPU). Accepts raw PCM16 mono bytes (as produced by audio/vad.py) or a
numpy float32 array and returns transcribed text.
"""
from __future__ import annotations

import io
from typing import Optional, Union

import numpy as np

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("audio.stt")


class SpeechToText:
    def __init__(self):
        self._model = None

    def _ensure_model(self):
        if self._model is None:
            from faster_whisper import WhisperModel

            cfg = CONFIG.audio.stt
            log.info("Loading faster-whisper model '%s' (%s/%s)", cfg.model_size, cfg.device, cfg.compute_type)
            self._model = WhisperModel(
                cfg.model_size, device=cfg.device, compute_type=cfg.compute_type
            )
        return self._model

    @staticmethod
    def _pcm16_to_float32(pcm_bytes: bytes) -> np.ndarray:
        audio_i16 = np.frombuffer(pcm_bytes, dtype=np.int16)
        return audio_i16.astype(np.float32) / 32768.0

    def transcribe(self, audio: Union[bytes, np.ndarray]) -> str:
        model = self._ensure_model()

        if isinstance(audio, bytes):
            audio_array = self._pcm16_to_float32(audio)
        else:
            audio_array = audio.astype(np.float32)

        if audio_array.size == 0:
            return ""

        segments, _info = model.transcribe(
            audio_array, language="en", vad_filter=True, beam_size=1
        )
        text = " ".join(seg.text.strip() for seg in segments)
        log.debug("Transcribed: %s", text)
        return text.strip()
