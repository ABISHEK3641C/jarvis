"""
audio/vad.py
-------------
Voice Activity Detection using WebRTC VAD. Used to trim silence from mic
input before sending to STT, and to detect when the user has stopped
speaking so JARVIS knows a command is complete.
"""
from __future__ import annotations

from collections import deque
from typing import Iterator, Optional

import numpy as np
import webrtcvad

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("audio.vad")


class VoiceActivityDetector:
    def __init__(
        self,
        sample_rate: Optional[int] = None,
        frame_duration_ms: Optional[int] = None,
        aggressiveness: Optional[int] = None,
    ):
        self.sample_rate = sample_rate or CONFIG.audio.sample_rate
        self.frame_duration_ms = frame_duration_ms or CONFIG.audio.frame_duration_ms
        self.frame_size = int(self.sample_rate * self.frame_duration_ms / 1000)
        self.vad = webrtcvad.Vad(aggressiveness or CONFIG.audio.vad_aggressiveness)

    def is_speech(self, frame: bytes) -> bool:
        """`frame` must be 16-bit mono PCM at the configured sample rate/duration."""
        if len(frame) != self.frame_size * 2:  # 2 bytes per int16 sample
            return False
        return self.vad.is_speech(frame, self.sample_rate)

    def frames_from_audio(self, audio: np.ndarray) -> Iterator[bytes]:
        """Split a float32 [-1, 1] audio array into VAD-compatible int16 frames."""
        pcm16 = (audio * 32767).astype(np.int16).tobytes()
        bytes_per_frame = self.frame_size * 2
        for i in range(0, len(pcm16) - bytes_per_frame + 1, bytes_per_frame):
            yield pcm16[i : i + bytes_per_frame]

    def collect_utterance(
        self,
        frame_iterator: Iterator[bytes],
        silence_frames_to_stop: int = 25,
        padding_frames: int = 10,
    ) -> bytes:
        """
        Consume a stream of frames, buffer while speech is detected, and
        return the collected utterance once enough trailing silence is seen.
        """
        ring_buffer: deque[tuple[bytes, bool]] = deque(maxlen=padding_frames)
        voiced_frames: list[bytes] = []
        triggered = False
        silence_count = 0

        for frame in frame_iterator:
            speech = self.is_speech(frame)

            if not triggered:
                ring_buffer.append((frame, speech))
                if sum(1 for _, s in ring_buffer if s) > 0.5 * ring_buffer.maxlen:
                    triggered = True
                    voiced_frames.extend(f for f, _ in ring_buffer)
                    ring_buffer.clear()
            else:
                voiced_frames.append(frame)
                if not speech:
                    silence_count += 1
                    if silence_count >= silence_frames_to_stop:
                        break
                else:
                    silence_count = 0

        return b"".join(voiced_frames)
