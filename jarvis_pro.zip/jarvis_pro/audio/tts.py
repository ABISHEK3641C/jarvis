"""
audio/tts.py
-------------
Text-to-speech engine chain: Kokoro (primary, natural-sounding local
neural TTS) -> Piper (fast local fallback) -> edge-tts (optional cloud
fallback). Streams generated audio to the default output device via
sounddevice, and supports mid-utterance interruption.
"""
from __future__ import annotations

import asyncio
import threading
from typing import Optional

import numpy as np
import sounddevice as sd

from core.config import CONFIG
from core.logger import get_logger

log = get_logger("audio.tts")


class TextToSpeech:
    def __init__(self):
        self._kokoro = None
        self._piper_voice = None
        self._interrupt_event = threading.Event()
        self._playback_thread: Optional[threading.Thread] = None

    # ------------------------------------------------------------- setup
    def _load_kokoro(self):
        if self._kokoro is None:
            from kokoro import KPipeline

            self._kokoro = KPipeline(lang_code="a")
        return self._kokoro

    def _load_piper(self):
        if self._piper_voice is None:
            from piper import PiperVoice

            self._piper_voice = PiperVoice.load(CONFIG.audio.tts.voice)
        return self._piper_voice

    # ------------------------------------------------------------ speak
    def speak(self, text: str, blocking: bool = True) -> None:
        """Synthesize and play `text`. If `blocking` is False, runs in a
        background thread and can be stopped early via `interrupt()`."""
        if not text.strip():
            return

        self._interrupt_event.clear()

        if blocking:
            self._speak_sync(text)
        else:
            self._playback_thread = threading.Thread(
                target=self._speak_sync, args=(text,), daemon=True
            )
            self._playback_thread.start()

    def interrupt(self) -> None:
        """Stop playback immediately (used when the user starts talking over JARVIS)."""
        if not CONFIG.audio.allow_interruption:
            return
        self._interrupt_event.set()
        sd.stop()

    def _speak_sync(self, text: str) -> None:
        try:
            audio, sr = self._synthesize(text)
        except Exception as exc:  # noqa: BLE001
            log.error("TTS synthesis failed on all engines: %s", exc)
            return

        if self._interrupt_event.is_set():
            return

        self._play(audio, sr)

    def _synthesize(self, text: str) -> tuple[np.ndarray, int]:
        engine_order = [
            CONFIG.audio.tts.primary_engine,
            CONFIG.audio.tts.fallback_engine,
            CONFIG.audio.tts.optional_engine,
        ]
        last_error: Optional[Exception] = None
        for engine in engine_order:
            try:
                if engine == "kokoro":
                    return self._synth_kokoro(text)
                if engine == "piper":
                    return self._synth_piper(text)
                if engine == "edge-tts":
                    return self._synth_edge(text)
            except Exception as exc:  # noqa: BLE001
                log.warning("TTS engine '%s' failed (%s); trying next.", engine, exc)
                last_error = exc
                continue
        raise RuntimeError(f"All TTS engines failed: {last_error}")

    def _synth_kokoro(self, text: str) -> tuple[np.ndarray, int]:
        pipeline = self._load_kokoro()
        chunks = []
        for _, _, audio in pipeline(text, voice=CONFIG.audio.tts.voice, speed=CONFIG.audio.tts.speaking_rate):
            chunks.append(audio)
        full_audio = np.concatenate(chunks) if chunks else np.zeros(0, dtype=np.float32)
        return full_audio, 24000

    def _synth_piper(self, text: str) -> tuple[np.ndarray, int]:
        voice = self._load_piper()
        audio_bytes = bytearray()
        for chunk in voice.synthesize_stream_raw(text):
            audio_bytes.extend(chunk)
        audio = np.frombuffer(bytes(audio_bytes), dtype=np.int16).astype(np.float32) / 32768.0
        return audio, voice.config.sample_rate

    def _synth_edge(self, text: str) -> tuple[np.ndarray, int]:
        import edge_tts
        import io
        import soundfile as sf

        async def _generate() -> bytes:
            communicate = edge_tts.Communicate(text, voice="en-US-GuyNeural")
            buf = bytearray()
            async for chunk in communicate.stream():
                if chunk["type"] == "audio":
                    buf.extend(chunk["data"])
            return bytes(buf)

        mp3_bytes = asyncio.run(_generate())
        audio, sr = sf.read(io.BytesIO(mp3_bytes))
        return audio.astype(np.float32), sr

    def _play(self, audio: np.ndarray, sample_rate: int) -> None:
        if audio.size == 0:
            return
        chunk_size = sample_rate // 5  # ~200ms chunks so interrupt() feels immediate
        sd.default.samplerate = sample_rate
        sd.default.channels = 1
        for start in range(0, len(audio), chunk_size):
            if self._interrupt_event.is_set():
                sd.stop()
                return
            chunk = audio[start : start + chunk_size]
            sd.play(chunk, sample_rate)
            sd.wait()
