"""
gui/main_window.py
----------------------
The main JARVIS Pro window: glassmorphic frameless panel, animated orb,
scrolling chat transcript, and a text input (voice input runs
independently via core/voice_loop.py and speaks/updates through the same
AppRuntime). Supports dark/light themes, always-on-top, and a floating
compact mode.
"""
from __future__ import annotations

from PySide6.QtCore import Qt, Signal, QObject
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QFrame,
    QLabel,
    QLineEdit,
    QPushButton,
    QScrollArea,
)

from core.app_runtime import AppRuntime
from core.config import CONFIG
from gui.orb_widget import OrbWidget, OrbState
from gui.theme import current_palette, glass_stylesheet


class _Signals(QObject):
    chunk_received = Signal(str)
    turn_done = Signal(str)
    turn_error = Signal(str)


class ChatBubble(QLabel):
    def __init__(self, text: str, is_user: bool, parent=None):
        super().__init__(text, parent)
        self.setWordWrap(True)
        palette = current_palette()
        bg = palette.accent if is_user else "rgba(255,255,255,0.06)"
        color = "#051015" if is_user else palette.text_primary
        align = "right" if is_user else "left"
        self.setStyleSheet(
            f"background-color: {bg}; color: {color}; border-radius: 12px; "
            f"padding: 8px 12px; margin: 4px 40px 4px {'40px' if is_user else '0px'};"
        )
        self.setAlignment(Qt.AlignRight if is_user else Qt.AlignLeft)


class MainWindow(QWidget):
    def __init__(self, runtime: AppRuntime):
        super().__init__()
        self.runtime = runtime
        self.signals = _Signals()
        self.signals.chunk_received.connect(self._on_chunk)
        self.signals.turn_done.connect(self._on_done)
        self.signals.turn_error.connect(self._on_error)

        self._streaming_bubble: ChatBubble | None = None
        self._streaming_text = ""

        self._build_ui()
        self._apply_flags()

    # ------------------------------------------------------------- setup
    def _build_ui(self) -> None:
        self.setObjectName("GlassRoot")
        self.setWindowTitle(CONFIG.app.name)
        self.resize(CONFIG.gui.window_width, CONFIG.gui.window_height)
        self.setStyleSheet(glass_stylesheet(current_palette()))

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)

        panel = QFrame()
        panel.setObjectName("GlassPanel")
        outer.addWidget(panel)

        layout = QVBoxLayout(panel)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(10)

        # Header
        header = QHBoxLayout()
        title = QLabel(CONFIG.app.name)
        title_font = QFont()
        title_font.setPointSize(14)
        title_font.setBold(True)
        title.setFont(title_font)
        header.addWidget(title)
        header.addStretch()
        self.status_label = QLabel("Idle")
        self.status_label.setObjectName("Secondary")
        header.addWidget(self.status_label)
        layout.addLayout(header)

        # Orb
        self.orb = OrbWidget()
        layout.addWidget(self.orb, alignment=Qt.AlignCenter)

        # Chat transcript
        self.chat_scroll = QScrollArea()
        self.chat_scroll.setWidgetResizable(True)
        self.chat_container = QWidget()
        self.chat_layout = QVBoxLayout(self.chat_container)
        self.chat_layout.addStretch()
        self.chat_scroll.setWidget(self.chat_container)
        layout.addWidget(self.chat_scroll, stretch=1)

        # Input row
        input_row = QHBoxLayout()
        self.input_field = QLineEdit()
        self.input_field.setPlaceholderText("Type a command, or just say 'Jarvis'...")
        self.input_field.returnPressed.connect(self._on_submit)
        input_row.addWidget(self.input_field, stretch=1)

        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self._on_submit)
        input_row.addWidget(send_btn)
        layout.addLayout(input_row)

    def _apply_flags(self) -> None:
        flags = Qt.FramelessWindowHint | Qt.Window
        if CONFIG.gui.always_on_top:
            flags |= Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.setAttribute(Qt.WA_TranslucentBackground)

    def set_always_on_top(self, enabled: bool) -> None:
        flags = self.windowFlags()
        if enabled:
            flags |= Qt.WindowStaysOnTopHint
        else:
            flags &= ~Qt.WindowStaysOnTopHint
        self.setWindowFlags(flags)
        self.show()

    # ------------------------------------------------------------- chat
    def _add_bubble(self, text: str, is_user: bool) -> ChatBubble:
        bubble = ChatBubble(text, is_user)
        self.chat_layout.insertWidget(self.chat_layout.count() - 1, bubble)
        self.chat_scroll.verticalScrollBar().setValue(
            self.chat_scroll.verticalScrollBar().maximum()
        )
        return bubble

    def _on_submit(self) -> None:
        text = self.input_field.text().strip()
        if not text:
            return
        self.input_field.clear()
        self._add_bubble(text, is_user=True)

        self.orb.set_state(OrbState.THINKING)
        self.status_label.setText("Thinking...")

        self._streaming_text = ""
        self._streaming_bubble = self._add_bubble("", is_user=False)

        self.runtime.submit_turn(
            text,
            on_chunk=lambda c: self.signals.chunk_received.emit(c),
            on_done=lambda full: self.signals.turn_done.emit(full),
            on_error=lambda err: self.signals.turn_error.emit(err),
        )

    # ---- these run on the Qt (main) thread via signal/slot marshaling ----
    def _on_chunk(self, chunk: str) -> None:
        self.orb.set_state(OrbState.SPEAKING)
        self._streaming_text += chunk
        if self._streaming_bubble:
            self._streaming_bubble.setText(self._streaming_text)

    def _on_done(self, full_text: str) -> None:
        self.orb.set_state(OrbState.IDLE)
        self.status_label.setText("Idle")

    def _on_error(self, error: str) -> None:
        self.orb.set_state(OrbState.IDLE)
        self.status_label.setText("Error")
        if self._streaming_bubble:
            self._streaming_bubble.setText(f"⚠ {error}")
