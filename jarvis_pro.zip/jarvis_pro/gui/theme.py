"""
gui/theme.py
-------------
Centralized color palette and stylesheet fragments for the glassmorphic
dark/light themes, so every widget stays visually consistent.
"""
from __future__ import annotations

from dataclasses import dataclass

from core.config import CONFIG


@dataclass(frozen=True)
class Palette:
    background: str
    surface: str
    text_primary: str
    text_secondary: str
    accent: str
    border: str


DARK = Palette(
    background="#0b0f14",
    surface="rgba(20, 26, 34, 0.72)",
    text_primary="#eaf6ff",
    text_secondary="#8fa3b3",
    accent=CONFIG.gui.accent_color,
    border="rgba(255, 255, 255, 0.08)",
)

LIGHT = Palette(
    background="#f4f7fa",
    surface="rgba(255, 255, 255, 0.72)",
    text_primary="#101820",
    text_secondary="#5b6b78",
    accent=CONFIG.gui.accent_color,
    border="rgba(0, 0, 0, 0.08)",
)


def current_palette() -> Palette:
    return DARK if CONFIG.gui.theme == "dark" else LIGHT


def glass_stylesheet(palette: Palette) -> str:
    return f"""
    QWidget#GlassRoot {{
        background-color: {palette.background};
    }}
    QFrame#GlassPanel {{
        background-color: {palette.surface};
        border: 1px solid {palette.border};
        border-radius: 18px;
    }}
    QLabel {{
        color: {palette.text_primary};
        font-family: 'Segoe UI', sans-serif;
    }}
    QLabel#Secondary {{
        color: {palette.text_secondary};
        font-size: 12px;
    }}
    QLineEdit {{
        background-color: rgba(255, 255, 255, 0.06);
        border: 1px solid {palette.border};
        border-radius: 10px;
        padding: 8px 12px;
        color: {palette.text_primary};
        font-size: 13px;
    }}
    QPushButton {{
        background-color: {palette.accent};
        color: #051015;
        border: none;
        border-radius: 10px;
        padding: 8px 14px;
        font-weight: 600;
    }}
    QPushButton:hover {{
        background-color: {palette.accent}cc;
    }}
    QScrollArea, QScrollArea > QWidget > QWidget {{
        background: transparent;
        border: none;
    }}
    """
