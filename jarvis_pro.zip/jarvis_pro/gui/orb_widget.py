"""
gui/orb_widget.py
-------------------
The animated AI orb: a pulsing glow when idle, a rippling waveform when
listening, and a faster shimmer when speaking. Pure QPainter, no external
animation assets needed.
"""
from __future__ import annotations

import math
from enum import Enum, auto

from PySide6.QtCore import QTimer, Qt, QRectF
from PySide6.QtGui import QPainter, QRadialGradient, QColor, QPen
from PySide6.QtWidgets import QWidget

from gui.theme import current_palette


class OrbState(Enum):
    IDLE = auto()
    LISTENING = auto()
    SPEAKING = auto()
    THINKING = auto()


class OrbWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setMinimumSize(160, 160)
        self._state = OrbState.IDLE
        self._phase = 0.0
        self._level = 0.0  # 0..1 amplitude, driven externally for listening/speaking

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._tick)
        self._timer.start(33)  # ~30fps

    def set_state(self, state: OrbState) -> None:
        self._state = state

    def set_level(self, level: float) -> None:
        self._level = max(0.0, min(1.0, level))

    def _tick(self) -> None:
        speed = {
            OrbState.IDLE: 0.03,
            OrbState.LISTENING: 0.12,
            OrbState.SPEAKING: 0.18,
            OrbState.THINKING: 0.08,
        }[self._state]
        self._phase += speed
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        palette = current_palette()
        accent = QColor(palette.accent)

        w, h = self.width(), self.height()
        cx, cy = w / 2, h / 2
        base_radius = min(w, h) * 0.28

        pulse = 1.0
        if self._state == OrbState.IDLE:
            pulse = 1.0 + 0.06 * math.sin(self._phase)
        elif self._state == OrbState.LISTENING:
            pulse = 1.0 + (0.15 + 0.2 * self._level) * math.sin(self._phase * 3)
        elif self._state == OrbState.SPEAKING:
            pulse = 1.0 + (0.1 + 0.25 * self._level) * math.sin(self._phase * 5)
        elif self._state == OrbState.THINKING:
            pulse = 1.0 + 0.1 * math.sin(self._phase * 2)

        radius = base_radius * pulse

        # Outer glow
        glow = QRadialGradient(cx, cy, radius * 2.2)
        glow_color_outer = QColor(accent)
        glow_color_outer.setAlpha(0)
        glow_color_inner = QColor(accent)
        glow_color_inner.setAlpha(90)
        glow.setColorAt(0.0, glow_color_inner)
        glow.setColorAt(1.0, glow_color_outer)
        painter.setBrush(glow)
        painter.setPen(Qt.NoPen)
        painter.drawEllipse(QRectF(cx - radius * 2.2, cy - radius * 2.2, radius * 4.4, radius * 4.4))

        # Core orb
        core = QRadialGradient(cx, cy, radius)
        core.setColorAt(0.0, QColor("#ffffff"))
        core.setColorAt(0.4, accent)
        core_edge = QColor(accent)
        core_edge.setAlpha(60)
        core.setColorAt(1.0, core_edge)
        painter.setBrush(core)
        painter.drawEllipse(QRectF(cx - radius, cy - radius, radius * 2, radius * 2))

        # Rotating ring segments to suggest "AI activity"
        if self._state in (OrbState.LISTENING, OrbState.THINKING, OrbState.SPEAKING):
            pen = QPen(accent)
            pen.setWidth(2)
            painter.setPen(pen)
            painter.setBrush(Qt.NoBrush)
            ring_radius = radius * 1.5
            segments = 6
            for i in range(segments):
                angle = self._phase * 40 + i * (360 / segments)
                painter.save()
                painter.translate(cx, cy)
                painter.rotate(angle)
                painter.drawArc(
                    QRectF(-ring_radius, -ring_radius, ring_radius * 2, ring_radius * 2),
                    0,
                    25 * 16,
                )
                painter.restore()
