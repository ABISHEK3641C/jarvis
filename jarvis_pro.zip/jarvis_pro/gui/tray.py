"""
gui/tray.py
------------
System tray icon with a right-click menu: show/hide, toggle always-on-top,
and quit. Keeps JARVIS running in the background when the window is closed.
"""
from __future__ import annotations

from pathlib import Path

from PySide6.QtGui import QIcon, QAction
from PySide6.QtWidgets import QApplication, QMenu, QSystemTrayIcon

ASSETS_DIR = Path(__file__).resolve().parent.parent / "assets" / "icons"


class TrayIcon(QSystemTrayIcon):
    def __init__(self, main_window, app: QApplication):
        icon_path = ASSETS_DIR / "tray_icon.png"
        icon = QIcon(str(icon_path)) if icon_path.exists() else QIcon.fromTheme("applications-system")
        super().__init__(icon, app)
        self.main_window = main_window
        self.app = app
        self.setToolTip("JARVIS Pro")

        menu = QMenu()

        self.toggle_action = QAction("Show / Hide")
        self.toggle_action.triggered.connect(self._toggle_window)
        menu.addAction(self.toggle_action)

        self.pin_action = QAction("Always on Top")
        self.pin_action.setCheckable(True)
        self.pin_action.triggered.connect(self._toggle_pin)
        menu.addAction(self.pin_action)

        menu.addSeparator()

        quit_action = QAction("Quit JARVIS")
        quit_action.triggered.connect(self.app.quit)
        menu.addAction(quit_action)

        self.setContextMenu(menu)
        self.activated.connect(self._on_activated)
        self.show()

    def _toggle_window(self) -> None:
        if self.main_window.isVisible():
            self.main_window.hide()
        else:
            self.main_window.show()
            self.main_window.raise_()
            self.main_window.activateWindow()

    def _toggle_pin(self, checked: bool) -> None:
        self.main_window.set_always_on_top(checked)

    def _on_activated(self, reason) -> None:  # noqa: ANN001
        if reason == QSystemTrayIcon.Trigger:
            self._toggle_window()

    def notify(self, title: str, message: str) -> None:
        self.showMessage(title, message, QSystemTrayIcon.Information, 4000)
