# JARVIS Pro

A local, modular AI voice assistant: wake word → speech-to-text → a local
LLM (via Ollama) with tool calling → text-to-speech, wrapped in a
glassmorphic desktop UI with an animated orb.

This is a **working core build**, deliberately scoped: the voice pipeline,
memory system, plugin architecture, and GUI are fully implemented and
functional end-to-end. It ships with a solid set of real tools (desktop
control, file management, notes/reminders, weather/currency/Wikipedia) and
a plugin system built so you can add anything else on your original
feature list — browser automation, messaging integrations, vision, a
multi-agent orchestrator, etc. — as new plugins without touching core code.

---

## Architecture

```
jarvis_pro/
├── core/            # config, logging, LLM engine, orchestrator, async runtime, voice loop glue
├── memory/           # SQLite (facts/notes/reminders/history) + FAISS semantic recall
├── audio/            # VAD, STT (faster-whisper), TTS (Kokoro→Piper→Edge), wake word
├── gui/               # PySide6 glassmorphic window, animated orb, system tray
├── plugins/
│   ├── base_plugin.py     # BasePlugin / ToolSpec — the extension contract
│   ├── plugin_manager.py  # discovery, hot reload, execution
│   ├── builtin/            # system_control, file_manager, productivity, internet
│   └── user/                # drop your own plugins here
├── config/config.yaml
├── tests/
├── main.py
├── setup.bat / run.bat
└── requirements.txt
```

**Data flow for one turn:**
`mic → VAD → faster-whisper → Orchestrator._build_messages() (recent + semantic memory) →
Ollama /api/chat (streaming, tools attached) → PluginManager.execute() for any tool calls →
final reply → memory.remember_turn() → Kokoro/Piper TTS`

The same `Orchestrator.handle_turn()` path is used for both typed text (GUI)
and spoken commands (voice loop), so behavior is identical either way.

---

## Requirements

- Windows 10/11 (primary target; core/audio/gui code is OS-aware and mostly
  portable to macOS/Linux, but power actions and app aliases are Windows-tuned)
- Python 3.11+
- [Ollama](https://ollama.com/download) installed and running
- 8GB+ RAM (tested against `qwen3:4b` — bump to `qwen3:8b`/`llama3` if you
  have headroom)
- A working microphone/speakers for voice mode (text chat works without one)

---

## Installation

```bat
setup.bat
```

This creates a virtual environment, installs `requirements.txt`, and pulls
the default Ollama model. If Ollama isn't installed yet, the script tells
you and skips the model pull — install it and re-run.

## Running

```bat
run.bat
```

This starts Ollama (if not already running), then launches the JARVIS Pro
window. Say **"Jarvis"**, **"Hey Jarvis"**, or **"Nova"** to trigger voice
input, or just type in the chat box.

---

## Configuration

All runtime behavior lives in `config/config.yaml` — LLM model/host,
wake words, TTS voice, GUI theme/accent color, plugin directories, and
more. Any key can also be overridden via environment variable using the
pattern `JARVIS_<SECTION>__<KEY>`, e.g.:

```
JARVIS_LLM__MODEL=qwen3:8b
JARVIS_GUI__THEME=light
```

---

## Writing a Plugin

Drop a file in `plugins/user/`. Anything subclassing `BasePlugin` is
auto-discovered and hot-reloaded while JARVIS is running:

```python
from plugins.base_plugin import BasePlugin

class MyPlugin(BasePlugin):
    name = "my_plugin"
    description = "What this plugin does."

    def setup(self):
        self.register_tool(
            "my_tool",
            "What this tool does, in plain language (the LLM reads this).",
            self.my_tool,
            {"type": "object", "properties": {"arg": {"type": "string"}}, "required": ["arg"]},
        )

    def my_tool(self, arg: str) -> dict:
        return {"status": "ok", "result": f"did something with {arg}"}
```

See `plugins/user/example_plugin.py` for a working template, and
`plugins/builtin/` for larger real examples (desktop control, file
management, productivity, internet lookups).

---

## Extending Beyond the Core Build

The plugin system is the intended extension point for the rest of your
original feature list:

| Category | How to add it |
|---|---|
| Browser automation | New plugin wrapping Playwright/Selenium |
| Messaging (WhatsApp/Telegram/Discord/Slack) | New plugin per service, using each platform's official API/SDK |
| Email | New plugin using `imaplib`/`smtplib` or the Gmail API |
| Vision / OCR / screen understanding | New plugin using `opencv-python` + `pytesseract`, feeding results back as tool results |
| Multi-agent orchestration | Additional `Orchestrator` subclasses or a LangGraph graph invoked from `handle_turn()` |
| Face/voice authentication | New plugin gating sensitive tools behind a recognition check before execution |

Each of these is a real, self-contained project; building them as
plugins keeps the core stable while you add them one at a time.

---

## Tests

```bat
venv\Scripts\activate
pytest tests/
```

Tests cover the memory layer and plugin system without requiring Ollama,
FAISS, or audio hardware, so they run in any environment.

---

## Troubleshooting

- **"Ollama at ... is not reachable"** — run `ollama serve`, or install
  Ollama and re-run `setup.bat`.
- **No sound / mic not detected** — voice mode fails gracefully; text
  chat continues to work. Check `sounddevice.query_devices()` in a Python
  shell to confirm your OS sees the mic.
- **TTS silent** — Kokoro requires its model weights on first run (auto
  downloaded); if that fails, JARVIS falls back to Piper, then edge-tts.
- **Volume control fails on Windows** — install `pycaw` and `comtypes`
  (already in `requirements.txt`); some locked-down systems block
  programmatic volume control.
