"""
tests/test_memory.py
----------------------
Covers the SQLite-backed Database layer directly (no FAISS dependency
required), plus MemoryManager's graceful fallback path.
"""
from __future__ import annotations

import tempfile
import time
from pathlib import Path

import pytest

from memory.database import Database


@pytest.fixture()
def db(tmp_path: Path) -> Database:
    return Database(db_path=tmp_path / "test.db")


def test_add_and_recent_turns(db: Database):
    db.add_turn("user", "hello")
    db.add_turn("assistant", "hi there")
    turns = db.recent_turns(limit=5)
    assert len(turns) == 2
    assert turns[0]["role"] == "user"
    assert turns[1]["content"] == "hi there"


def test_fact_roundtrip(db: Database):
    db.set_fact("user_name", "Alex")
    assert db.get_fact("user_name") == "Alex"

    db.set_fact("user_name", "Alexandra")  # overwrite
    assert db.get_fact("user_name") == "Alexandra"

    assert db.delete_fact("user_name") is True
    assert db.get_fact("user_name") is None


def test_notes(db: Database):
    note_id = db.add_note("buy milk", title="shopping")
    notes = db.list_notes()
    assert any(n["id"] == note_id and n["content"] == "buy milk" for n in notes)
    assert db.delete_note(note_id) is True


def test_reminders_due(db: Database):
    past = time.time() - 10
    future = time.time() + 3600
    db.add_reminder("past reminder", past)
    db.add_reminder("future reminder", future)

    due = db.due_reminders()
    assert len(due) == 1
    assert due[0]["text"] == "past reminder"

    db.complete_reminder(due[0]["id"])
    assert db.due_reminders() == []
