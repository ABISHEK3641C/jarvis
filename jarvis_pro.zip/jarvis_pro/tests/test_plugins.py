"""
tests/test_plugins.py
------------------------
Verifies plugin discovery, tool schema generation, and async execution
without requiring Ollama, audio hardware, or FAISS to be installed.
"""
from __future__ import annotations

import asyncio

import pytest

from plugins.base_plugin import BasePlugin
from plugins.plugin_manager import PluginManager


class EchoPlugin(BasePlugin):
    name = "echo"
    description = "Test plugin"

    def setup(self) -> None:
        self.register_tool(
            "echo",
            "Echo back the given text.",
            self.echo,
            {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]},
        )

    def echo(self, text: str) -> dict:
        return {"status": "ok", "echo": text}


def test_tool_schema_shape():
    plugin = EchoPlugin()
    schemas = plugin.ollama_schemas()
    assert len(schemas) == 1
    fn = schemas[0]["function"]
    assert fn["name"] == "echo"
    assert "text" in fn["parameters"]["properties"]


def test_plugin_manager_registers_and_executes():
    manager = PluginManager()
    manager._register_plugin(EchoPlugin())  # noqa: SLF001 (direct registration for test isolation)

    assert "echo" in manager.tools

    result = asyncio.run(manager.execute("echo", {"text": "hello"}))
    assert result == {"status": "ok", "echo": "hello"}


def test_unknown_tool_returns_error():
    manager = PluginManager()
    result = asyncio.run(manager.execute("does_not_exist", {}))
    assert "error" in result
