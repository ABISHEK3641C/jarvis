@echo off
setlocal

if not exist venv (
    echo Virtual environment not found. Run setup.bat first.
    exit /b 1
)

call venv\Scripts\activate.bat

echo Checking Ollama server...
curl -s http://localhost:11434/api/tags >nul 2>&1
if errorlevel 1 (
    echo Starting Ollama server...
    start "" ollama serve
    timeout /t 3 >nul
)

echo Launching JARVIS Pro...
python main.py

endlocal
